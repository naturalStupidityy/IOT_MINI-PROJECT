"""System layer tests: LED, temperature, resources, doctor (software paths)."""

import threading
import time
from pathlib import Path

import pytest

from sentinel_rf.config import load_config
from sentinel_rf.system.doctor import (
    FAIL,
    OK,
    UNVERIFIED,
    WARN,
    format_checks,
    run_checks,
    run_doctor,
)
from sentinel_rf.system.led import FakeLed, LedError, SysfsLed
from sentinel_rf.system.resources import ResourceMonitor, total_ram_mb
from sentinel_rf.system.temperature import read_temperature


class TestSysfsLed:
    @pytest.fixture()
    def led_dir(self, tmp_path) -> Path:
        base = tmp_path / "leds" / "led0"
        base.mkdir(parents=True)
        (base / "trigger").write_text("none mmc0 [mmc0] kbd-scrolllock\n")
        (base / "brightness").write_text("0\n")
        return base

    def test_open_takes_control(self, led_dir):
        led = SysfsLed(base=led_dir)
        led.open()
        assert (led_dir / "trigger").read_text() == "none"
        led.on()
        assert (led_dir / "brightness").read_text() == "1"
        led.off()
        assert (led_dir / "brightness").read_text() == "0"

    def test_close_restores_trigger(self, led_dir):
        led = SysfsLed(base=led_dir)
        led.open()
        led.on()
        led.close()
        assert (led_dir / "trigger").read_text() == "mmc0"  # original restored
        assert (led_dir / "brightness").read_text() == "0"

    def test_context_manager_restores_on_exception(self, led_dir):
        with pytest.raises(RuntimeError), SysfsLed(base=led_dir) as led:
            led.on()
            raise RuntimeError("boom")
        assert (led_dir / "trigger").read_text() == "mmc0"

    def test_missing_sysfs_raises(self, tmp_path):
        led = SysfsLed(base=tmp_path / "nowhere")
        with pytest.raises(LedError):
            led.open()

    def test_close_without_open_is_safe(self, tmp_path):
        SysfsLed(base=tmp_path).close()  # must not raise


class TestFakeLed:
    def test_transitions_recorded(self):
        led = FakeLed()
        led.open()
        led.on()
        time.sleep(0.01)
        led.off()
        time.sleep(0.01)
        led.on()
        led.close()
        assert led.opened == 1 and led.closed == 1
        states = [state for state, _ in led.transitions]
        assert states == [True, False, True]
        assert 0.2 < led.on_fractions() < 0.8

    def test_fail_on_open(self):
        led = FakeLed()
        led.fail_on_open(True)
        with pytest.raises(LedError):
            led.open()


class TestTemperature:
    def test_returns_float_or_none(self):
        temp = read_temperature()
        assert temp is None or isinstance(temp, float)


class TestResources:
    def test_sample_once(self):
        mon = ResourceMonitor()
        sample = mon.sample_once()
        assert "rss_mb" in sample and "cpu_percent" in sample
        assert sample["rss_mb"] is None or sample["rss_mb"] > 1
        assert len(mon.samples) == 1

    def test_budget_violations(self):
        mon = ResourceMonitor()
        mon.sample_once()
        assert mon.budget_violations(max_cpu_percent=50, max_ram_mb=300) == []
        # absurdly small budget -> violation reported
        violations = mon.budget_violations(max_cpu_percent=0.0001, max_ram_mb=0.0001)
        assert violations

    def test_threaded_sampling(self):
        mon = ResourceMonitor(interval_s=0.05)
        mon.start()
        time.sleep(0.3)
        mon.stop()
        assert len(mon.samples) >= 3

    def test_total_ram(self):
        ram = total_ram_mb()
        assert ram is None or ram > 100


class TestDoctor:
    def test_checks_never_raise_and_cover_sections(self):
        results = run_checks(load_config())
        names = [r.name for r in results]
        assert "python" in names and "capture interface" in names
        statuses = {r.status for r in results}
        assert statuses <= {OK, WARN, FAIL, UNVERIFIED}
        # on a laptop with no radio tools, hardware items must be UNVERIFIED
        hardware = [r for r in results if r.section == "hardware"]
        assert hardware, "hardware section expected"

    def test_format_contains_legend(self):
        text = format_checks(run_checks(load_config()))
        assert "UNVERIFIED" in text and "doctor" in text

    def test_run_doctor_exit_code(self, capsys):
        code = run_doctor(load_config(), as_json=False)
        out = capsys.readouterr().out
        assert "doctor" in out
        assert code in (0, 1)

    def test_run_doctor_json(self, capsys):
        import json

        code = run_doctor(load_config(), as_json=True)
        payload = json.loads(capsys.readouterr().out)
        assert isinstance(payload, list) and payload[0]["name"]
        assert code in (0, 1)

    def test_fail_check_renders(self):
        from sentinel_rf.system import doctor as doctor_mod

        results = [doctor_mod.CheckResult("broken-thing", doctor_mod.FAIL, "it broke")]
        text = format_checks(results)
        assert "FAIL" in text and "broken-thing" in text


def test_resource_monitor_thread_names():
    mon = ResourceMonitor(interval_s=60)
    mon.start()
    try:
        names = [t.name for t in threading.enumerate()]
        assert "sentinel-resmon" in names
    finally:
        mon.stop()
