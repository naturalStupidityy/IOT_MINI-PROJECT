"""Privacy boundary tests, including the Phase-0 ACCEPTANCE TEST.

Phase-0 acceptance: "a test proves raw MACs never reach the store layer".
The tests below feed observations that carry a live raw_addr through the
store boundary and assert that nothing the store exposes contains the raw
address, and that raw payloads are refused outright.
"""

import json

import pytest

from sentinel_rf.crypto import mac_hash, new_salt
from sentinel_rf.parse.observation import Observation
from sentinel_rf.privacy import (
    PrivacyViolation,
    assert_no_raw_mac,
    is_locally_administered,
    looks_like_raw_mac,
)
from sentinel_rf.transport.store import InMemoryStore

RAW = "AA:BB:CC:DD:EE:FF"
RAW_LOWER = "aa:bb:cc:dd:ee:ff"


def test_looks_like_raw_mac_positive():
    assert looks_like_raw_mac(RAW)
    assert looks_like_raw_mac(RAW_LOWER)
    assert looks_like_raw_mac("aa-bb-cc-dd-ee-ff")
    assert looks_like_raw_mac("device de:ad:be:ef:00:11 seen near window")


def test_looks_like_raw_mac_negative():
    assert not looks_like_raw_mac("")
    assert not looks_like_raw_mac("aabbccddeeffab12")  # bare hex: hash form
    assert not looks_like_raw_mac("00:11:22")  # too short
    assert not looks_like_raw_mac(mac_hash(RAW, new_salt()))
    assert not looks_like_raw_mac(123)  # non-strings are never raw MACs


def test_is_locally_administered():
    assert is_locally_administered("02:00:00:00:00:00")
    assert is_locally_administered("06:11:22:33:44:55")
    assert is_locally_administered("12:34:56:78:9A:BC")
    assert not is_locally_administered("00:11:22:33:44:55")
    assert not is_locally_administered("04:5A:16:70:00:01")


def test_is_locally_administered_rejects_garbage():
    with pytest.raises(ValueError):
        is_locally_administered("nope")


def test_assert_no_raw_mac_passes_clean_payload():
    assert_no_raw_mac({"addr_hash": "ab12cd34ef56ab12", "name": "cam"}, where="test")


def test_assert_no_raw_mac_flags_values():
    with pytest.raises(PrivacyViolation, match="looks like a raw MAC"):
        assert_no_raw_mac({"note": "seen de:ad:be:ef:00:11 outside"}, where="test")


@pytest.mark.parametrize("key", ["raw_addr", "raw", "raw_mac", "mac"])
def test_assert_no_raw_mac_flags_forbidden_keys(key):
    with pytest.raises(PrivacyViolation, match="forbidden raw-address key"):
        assert_no_raw_mac({key: "ab12cd34ef56ab12"}, where="test")


# --------------------------------------------------------------------------- #
# Phase-0 acceptance: raw MACs never reach the store layer
# --------------------------------------------------------------------------- #


def test_acceptance_raw_macs_never_reach_store(salt):
    """PHASE-0 ACCEPTANCE TEST.

    An observation carrying a live raw_addr is stored without it, and
    nothing the store exposes (rows, JSON serialization) contains the raw
    address in any case variation.
    """
    obs = Observation.wifi(
        ts=1.0,
        node_id="node-1",
        rssi_dbm=-55.0,
        addr_hash=mac_hash(RAW, salt),
        length=1200,
        frame_type=2,
        frame_subtype=0,
        to_ds=True,
        raw_addr=RAW,  # live-only: present in memory, must never persist
    )
    store = InMemoryStore()
    store.add_observation(obs)

    rows = store.observations()
    assert len(store) == 1
    assert "raw_addr" not in rows[0]
    assert rows[0]["addr_hash"] == obs.addr_hash
    assert rows[0]["addr_hash"] != RAW
    # The privacy boundary itself accepts the stored row...
    assert_no_raw_mac(rows[0], where="acceptance")
    # ...and neither serialization form leaks the raw address.
    blob = json.dumps(rows)
    assert RAW not in blob
    assert RAW_LOWER not in blob


def test_acceptance_store_refuses_raw_payloads():
    store = InMemoryStore()
    with pytest.raises(PrivacyViolation):
        store.add_payload({"schema_version": 1, "raw_addr": RAW})
    with pytest.raises(PrivacyViolation):
        store.add_payload({"schema_version": 1, "note": f"target {RAW}"})
    with pytest.raises(PrivacyViolation):
        store.add_payload({"schema_version": 1, "mac": "ab12cd34ef56ab12"})
    assert len(store) == 0


def test_acceptance_to_dict_has_no_raw_addr(salt):
    obs = Observation.ble(
        ts=2.0,
        node_id="node-1",
        rssi_dbm=-70.0,
        addr_hash=mac_hash("02:00:00:11:22:33", salt),
        name="SomeCam",
        raw_addr="02:00:00:11:22:33",
    )
    d = obs.to_dict()
    assert "raw_addr" not in d
    assert_no_raw_mac(d, where="acceptance.to_dict")
    assert Observation.from_dict(d) == obs.redact()


def test_store_bounded_retention():
    store = InMemoryStore(max_observations=2)
    for i in range(3):
        store.add_payload({"schema_version": 1, "i": i})
    assert len(store) == 2
    assert [r["i"] for r in store.observations()] == [1, 2]
