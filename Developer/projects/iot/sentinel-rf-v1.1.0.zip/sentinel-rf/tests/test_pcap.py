"""PCAP reader/writer tests, including the sim -> pcap -> parse round trip."""

import struct

import pytest

from sentinel_rf.crypto import mac_hash, new_salt
from sentinel_rf.parse.observation import Role, Source
from sentinel_rf.parse.pcap import (
    PcapError,
    PcapReader,
    iter_pcap_observations,
    write_observations_pcap,
    write_pcap_header,
    write_pcap_packet,
)
from sentinel_rf.parse.radiotap import parse_radiotap
from sentinel_rf.sim.generator import RfSimulator, SimDevice


def radiotap_frame(rssi=-55, freq=2437, rate=24.0) -> bytes:
    """Minimal radiotap header (FLAGS, RATE, CHANNEL, SIGNAL) + 802.11 data."""
    presence = (1 << 1) | (1 << 2) | (1 << 3) | (1 << 5)
    hdr = struct.pack("<BBHI", 0, 0, 0, presence)
    hdr += bytes([0x10])  # FLAGS: FCS at end
    hdr += bytes([int(rate * 2)])  # RATE
    hdr += struct.pack("<HH", freq, 0x00A0)  # CHANNEL
    hdr += struct.pack("<b", rssi)  # dBm SIGNAL
    struct.pack_into("<H", hdr_bytes := bytearray(hdr), 2, len(hdr_bytes))
    # 802.11 QoS data, To-DS
    fc = (2 << 2) | (8 << 4) | 0x0100
    dot11 = struct.pack("<HH", fc, 0)
    dot11 += bytes.fromhex("b827eb112233")  # addr1 BSSID
    dot11 += bytes.fromhex("240ac4aabbcc")  # addr2 transmitter
    dot11 += bytes.fromhex("ffffffffffff")  # addr3
    dot11 += struct.pack("<HH", 0x0040, 0x0007)  # seq, qos
    return bytes(hdr_bytes) + dot11 + b"\x00" * 32 + b"\xde\xad\xbe\xef"


class TestPcapReader:
    def test_write_then_read_roundtrip(self, tmp_path):
        path = tmp_path / "cap.pcap"
        with open(path, "wb") as fh:
            write_pcap_header(fh, snaplen=128)
            write_pcap_packet(fh, 1700000000.5, radiotap_frame(), snaplen=128)
            write_pcap_packet(fh, 1700000001.25, radiotap_frame(rssi=-70), snaplen=128)
        with PcapReader(path) as reader:
            packets = list(reader)
        assert len(packets) == 2
        assert packets[0][0] == pytest.approx(1700000000.5, abs=1e-6)
        assert packets[1][0] == pytest.approx(1700000001.25, abs=1e-6)
        meta, rest = parse_radiotap(packets[0][1])
        assert meta.rssi_dbm == -55.0 and meta.freq_mhz == 2437

    def test_truncation_semantics(self, tmp_path):
        """Writer truncates to snaplen; orig_len carries the true length."""
        path = tmp_path / "cap.pcap"
        frame = radiotap_frame() + b"\x00" * 300  # pretend 300 B of body
        with open(path, "wb") as fh:
            write_pcap_header(fh, snaplen=128)
            write_pcap_packet(fh, 10.0, frame, snaplen=128)
        with PcapReader(path) as reader:
            ts, packet = next(iter(reader))
            assert len(packet) == 128  # incl_len
            assert reader.last_orig_len == len(frame)

    def test_wrong_magic_rejected(self, tmp_path):
        path = tmp_path / "bad.pcap"
        path.write_bytes(b"\x00" * 24)
        with pytest.raises(PcapError, match="magic"):
            PcapReader(path)

    def test_wrong_linktype_rejected(self, tmp_path):
        path = tmp_path / "eth.pcap"
        with open(path, "wb") as fh:
            fh.write(b"\xd4\xc3\xb2\xa1")
            fh.write(struct.pack("<HHiIII", 2, 4, 0, 0, 65535, 1))  # LINKTYPE_ETHERNET
        with pytest.raises(PcapError, match="linktype"):
            PcapReader(path)

    def test_truncated_record_raises(self, tmp_path):
        path = tmp_path / "cut.pcap"
        with open(path, "wb") as fh:
            write_pcap_header(fh)
            write_pcap_packet(fh, 1.0, radiotap_frame())
        data = bytearray(path.read_bytes())
        path.write_bytes(data[:-10])  # chop the last packet short
        with pytest.raises(PcapError):
            list(PcapReader(path))


class TestReplay:
    def test_iter_observations(self, tmp_path, salt):
        path = tmp_path / "cap.pcap"
        with open(path, "wb") as fh:
            write_pcap_header(fh)
            write_pcap_packet(fh, 100.0, radiotap_frame(rssi=-55), snaplen=128)
            write_pcap_packet(fh, 100.5, radiotap_frame(rssi=-58), snaplen=128)
            write_pcap_packet(fh, 101.0, b"\xff" * 4, snaplen=128)  # garbage
        counters: dict = {}
        obs = list(iter_pcap_observations(path, node_id="n1", salt=salt, counters=counters))
        assert len(obs) == 2
        assert counters["packets"] == 3
        assert counters["parsed"] == 2
        assert counters["radiotap_errors"] == 1
        assert obs[0].role is Role.STA and obs[0].to_ds is True
        assert obs[0].addr_hash == mac_hash("24:0a:c4:aa:bb:cc", salt)

    def test_counter_default_dict(self, tmp_path, salt):
        path = tmp_path / "cap.pcap"
        with open(path, "wb") as fh:
            write_pcap_header(fh)
            write_pcap_packet(fh, 1.0, radiotap_frame())
        obs = list(iter_pcap_observations(path, node_id="n1", salt=salt))
        assert len(obs) == 1


class TestSimPcapRoundTrip:
    def test_sim_observations_survive_pcap_roundtrip(self, tmp_path):
        """Header fields written to pcap and re-parsed must match the sim."""
        salt = new_salt()
        sim = RfSimulator(
            seed=7,
            duration_s=8.0,
            devices=[
                SimDevice(
                    device_id="cam-1",
                    kind="camera",
                    mac="24:0a:c4:00:00:01",
                    position=(2.0, 1.0),
                    is_camera=True,
                ),
                SimDevice(
                    device_id="ap-1",
                    kind="ap",
                    mac="b8:27:eb:00:00:02",
                    position=(1.0, 1.0),
                    ssid="Lab",
                ),
            ],
            node_positions={"n1": (0.3, 0.3)},
            salt=salt,
            allow_raw=True,  # writer needs raw addrs (synthetic path only)
        )
        original = list(sim.observations())
        wifi_only = [o for o in original if o.source is Source.WIFI]
        assert len(wifi_only) >= 10

        path = tmp_path / "sim.pcap"
        written = write_observations_pcap(path, wifi_only, snaplen=128)
        assert written == len(wifi_only)

        replayed = list(iter_pcap_observations(path, node_id="n1", salt=salt))
        assert len(replayed) == written

        # The writer preserves event order: compare positionally by timestamp.
        orig_sorted = sorted(wifi_only, key=lambda o: o.ts)
        replay_sorted = sorted(replayed, key=lambda o: o.ts)
        assert len(orig_sorted) == len(replay_sorted)
        for o, r in zip(orig_sorted, replay_sorted):
            assert r.addr_hash == o.addr_hash
            assert r.frame_type == o.frame_type and r.frame_subtype == o.frame_subtype
            assert r.rssi_dbm == pytest.approx(o.rssi_dbm, abs=1.0)  # 1 dBm quantisation
            assert r.channel == o.channel
            assert r.length == o.length  # orig_len carried through
            assert r.to_ds == o.to_ds and r.retry == o.retry
            assert r.role is o.role

    def test_captured_observations_refused(self, tmp_path, salt):
        """Observations without raw_addr (i.e. live captures) can't be re-serialized."""
        sim = RfSimulator(seed=1, duration_s=2.0, salt=salt, allow_raw=False)
        wifi_only = [o for o in sim.observations() if o.source is Source.WIFI]
        path = tmp_path / "none.pcap"
        assert write_observations_pcap(path, wifi_only) == 0
