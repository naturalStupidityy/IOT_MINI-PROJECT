"""Feature layer tests: window slicing + analytic statistics."""

import math

import pytest

from sentinel_rf.config import WindowsConfig
from sentinel_rf.crypto import mac_hash
from sentinel_rf.features import FEATURE_NAMES, compute_features, feature_vector
from sentinel_rf.features.windows import DeviceTracker
from sentinel_rf.parse.observation import Observation, Role, Source
from sentinel_rf.sim.generator import RfSimulator


def wifi_obs(
    ts,
    *,
    hash_="a" * 16,
    length=800,
    ftype=2,
    subtype=8,
    to_ds=True,
    retry=False,
    rssi=-55.0,
    channel=6,
    rate=65.0,
    role=Role.STA,
):
    return Observation.wifi(
        ts=ts,
        node_id="n1",
        rssi_dbm=rssi,
        addr_hash=hash_,
        length=length,
        channel=channel,
        freq_mhz=2437.0,
        bssid_hash="f" * 16,
        role=role,
        frame_type=ftype,
        frame_subtype=subtype,
        to_ds=to_ds if ftype == 2 else None,
        from_ds=False if ftype == 2 else None,
        retry=retry if ftype == 2 else None,
        rate_mbps=rate,
    )


class TestDeviceTracker:
    def test_window_slicing(self):
        tracker = DeviceTracker(WindowsConfig(short_s=1, medium_s=10, long_s=60))
        for i in range(120):
            tracker.update(wifi_obs(1000.0 + i))  # t in [1000, 1119]
        window = tracker.window("a" * 16, now=1119.0)
        assert len(window.long) == 60
        assert len(window.medium) == 10
        assert len(window.short) == 1
        assert window.first_seen == 1000.0 and window.last_seen == 1119.0

    def test_role_majority_and_sources(self):
        tracker = DeviceTracker()
        for _ in range(10):
            tracker.update(wifi_obs(1.0, role=Role.STA))
        for _ in range(3):
            tracker.update(Observation.ble(ts=2.0, node_id="n1", rssi_dbm=-60, addr_hash="a" * 16))
        window = tracker.window("a" * 16)
        assert window.role_majority is Role.STA
        assert set(window.sources) == {Source.WIFI, Source.BLE}
        assert window.has_wifi and not window.is_ble_only

    def test_unknown_device(self):
        tracker = DeviceTracker()
        assert tracker.window("nope") is None
        assert "nope" not in tracker
        assert len(tracker) == 0

    def test_max_per_device_bound(self):
        tracker = DeviceTracker(max_per_device=50)
        for i in range(200):
            tracker.update(wifi_obs(i * 0.001))
        window = tracker.window("a" * 16)
        assert len(window.long) == 50

    def test_sweep_evicts_stale(self):
        tracker = DeviceTracker()
        tracker.update(wifi_obs(100.0))
        tracker.update(wifi_obs(500.0, hash_="b" * 16))
        evicted = tracker.sweep(now=500.0, stale_s=300.0)
        assert evicted == 1
        assert "a" * 16 not in tracker
        assert "b" * 16 in tracker

    def test_raw_mac_only_when_allowed(self):
        salt = b"0123456789abcdef"
        h = mac_hash("24:0a:c4:aa:bb:cc", salt)
        obs = Observation.wifi(
            ts=1.0,
            node_id="n1",
            rssi_dbm=-55,
            addr_hash=h,
            length=100,
            raw_addr="24:0a:c4:aa:bb:cc",
        )
        strict = DeviceTracker(allow_raw=False)
        strict.update(obs)
        assert strict.raw_mac(h) is None
        permissive = DeviceTracker(allow_raw=True)
        permissive.update(obs)
        assert permissive.raw_mac(h) == "24:0a:c4:aa:bb:cc"

    def test_snapshot_skips_empty(self):
        tracker = DeviceTracker()
        assert tracker.snapshot() == {}
        tracker.update(wifi_obs(1.0))
        assert list(tracker.snapshot()) == ["a" * 16]


class TestComputeFeaturesAnalytic:
    def make_window(self, observations, config=None):
        config = config or WindowsConfig(short_s=1, medium_s=10, long_s=60)
        tracker = DeviceTracker(config)
        for obs in observations:
            tracker.update(obs)
        now = observations[-1].ts if observations else 0.0
        return tracker.window(observations[0].addr_hash if observations else "", now)

    def test_steady_rate_camera_like(self):
        # 50 uplink QoS frames/s of 900 B for 60 s -> 45 kB/s, uplink 100%
        observations = []
        for i in range(3000):
            observations.append(wifi_obs(i * 0.02, length=900, retry=(i % 10 == 0)))
        features = compute_features(self.make_window(observations))
        assert features["frames_per_s"] == pytest.approx(50, abs=2)
        assert features["bytes_per_s"] == pytest.approx(45_000, rel=0.05)
        assert features["uplink_share"] == 1.0
        assert features["qos_share"] == 1.0
        assert features["data_ratio"] == 1.0
        assert features["retry_rate"] == pytest.approx(0.1, abs=0.02)
        assert features["mean_frame_size"] == pytest.approx(900, abs=1)
        assert features["large_frame_share"] == 0.0
        assert features["iat_mean_ms"] == pytest.approx(20, rel=0.1)
        assert features["iat_cv"] == pytest.approx(0.0, abs=0.05)
        assert features["duty_cycle"] == pytest.approx(1.0, abs=0.01)
        assert features["role_ap"] == 0.0

    def test_periodic_bursts_detected(self):
        # one 1500 B burst every 2 s (keyframe-like), quiet otherwise
        observations = []
        t = 0.0
        while t < 60:
            for k in range(3):
                observations.append(wifi_obs(t + k * 0.01, length=1500))
            t += 2.0
        features = compute_features(self.make_window(observations))
        assert features["burst_periodicity"] > 0.5
        assert features["large_frame_share"] == 1.0
        assert features["duty_cycle"] < 0.2

    def test_aps_are_mgmt_heavy(self):
        observations = []
        for i in range(600):
            observations.append(
                wifi_obs(
                    i * 0.1, length=140, ftype=0, subtype=8, to_ds=False, role=Role.AP, rate=6.0
                )
            )
        features = compute_features(self.make_window(observations))
        assert features["data_ratio"] == 0.0
        assert features["role_ap"] == 1.0
        assert features["uplink_share"] == 0.0

    def test_downlink_share(self):
        observations = []
        for i in range(1000):
            up = i % 4 != 0  # 75% downlink
            observations.append(wifi_obs(i * 0.05, to_ds=not up, length=1000))
        features = compute_features(self.make_window(observations))
        assert features["uplink_share"] == pytest.approx(0.25, abs=0.02)

    def test_rssi_stats_and_drift(self):
        observations = []
        for i in range(120):
            observations.append(wifi_obs(i * 0.5, rssi=-50.0 + 0.05 * i))
        features = compute_features(self.make_window(observations))
        assert features["rssi_mean"] == pytest.approx(-47.0, abs=0.5)
        assert 0.0 < features["rssi_var"] < 5.0
        assert features["rssi_drift_db_min"] == pytest.approx(6.0, rel=0.05)

    def test_channel_diversity(self):
        observations = [wifi_obs(i * 0.1, channel=(1, 6, 11)[i % 3]) for i in range(300)]
        features = compute_features(self.make_window(observations))
        assert features["channel_changes"] == 3.0

    def test_empty_and_degenerate_windows(self):
        from sentinel_rf.features.windows import DeviceWindow

        for observations in ([], [wifi_obs(1.0)]):
            window = self.make_window(observations) if observations else DeviceWindow("x")
            features = compute_features(window)
            for name in FEATURE_NAMES:
                assert math.isfinite(features[name]), name

    def test_ble_features(self):
        observations = []
        for i in range(60):
            observations.append(
                Observation.ble(
                    ts=i * 1.0,
                    node_id="n1",
                    rssi_dbm=-70,
                    addr_hash="a" * 16,
                    name="IPC-9F2A",
                    company_id=89,
                )
            )
        features = compute_features(self.make_window(observations))
        assert features["is_ble"] == 1.0
        assert features["ble_adv_rate"] == pytest.approx(1.0, rel=0.1)
        assert features["ble_named"] == 1.0
        assert features["data_ratio"] == 0.0

    def test_feature_vector_order(self):
        observations = [wifi_obs(i * 0.1, length=900) for i in range(200)]
        window = self.make_window(observations)
        vector = feature_vector(window)
        assert vector.shape == (len(FEATURE_NAMES),)
        assert vector[0] == pytest.approx(compute_features(window)["frames_per_s"])


class TestSimFeatureSeparation:
    """Simulator devices must produce separable feature profiles (sanity)."""

    @pytest.fixture(scope="class")
    def sim_windows(self):
        sim = RfSimulator(seed=42, duration_s=90.0, salt=b"0123456789abcdef")
        labels = sim.labels()
        tracker = DeviceTracker(WindowsConfig(short_s=1, medium_s=10, long_s=60))
        for obs in sim.observations():
            tracker.update(obs)
        windows = {}
        for addr_hash, window in tracker.snapshot().items():
            label = labels.get(addr_hash, {})
            if label.get("kind") in (
                "camera",
                "laptop_bulk_upload",
                "laptop_youtube",
                "phone_video_call",
                "ap",
            ):
                windows[label["kind"]] = window
        return windows

    def test_camera_high_uplink_qos(self, sim_windows):
        camera = compute_features(sim_windows["camera"])
        assert camera["uplink_share"] > 0.9
        assert camera["qos_share"] > 0.8
        assert camera["burst_periodicity"] > 0.2

    def test_bulk_upload_high_volume_but_not_qos_periodic(self, sim_windows):
        bulk = compute_features(sim_windows["laptop_bulk_upload"])
        assert bulk["bytes_per_s"] > 100_000
        assert bulk["qos_share"] < 0.2

    def test_youtube_uplink_is_small_acks(self, sim_windows):
        tube = compute_features(sim_windows["laptop_youtube"])
        camera = compute_features(sim_windows["camera"])
        assert tube["mean_frame_size"] < 300  # ACK-sized uplink
        assert tube["bytes_per_s"] < 0.2 * camera["bytes_per_s"]

    def test_ap_is_mgmt_only(self, sim_windows):
        ap = compute_features(sim_windows["ap"])
        assert ap["data_ratio"] < 0.9
