"""Detection layer tests: rules, stimulus math, fusion, model, engine, ablation."""

import math

import numpy as np
import pytest

from sentinel_rf.config import load_config
from sentinel_rf.detect.ablation import format_ablation_table, run_ablation
from sentinel_rf.detect.dataset import build_training_data, dataset_summary
from sentinel_rf.detect.engine import Detector
from sentinel_rf.detect.fusion import BAND_IGNORE, BAND_LIKELY, BAND_WATCH, ComponentResult, fuse
from sentinel_rf.detect.model import TrafficModel, lodo_cross_validate
from sentinel_rf.detect.rules import PriorsEngine, TrafficRules
from sentinel_rf.detect.stimulus import (
    StimulusResult,
    StimulusSession,
    StimulusTracker,
    correlate,
    verdict_to_component,
)
from sentinel_rf.features.stats import compute_features
from sentinel_rf.features.windows import DeviceTracker
from sentinel_rf.intel.ble_rules import BleRuleBook
from sentinel_rf.intel.cache import DeviceIntel, IntelCache
from sentinel_rf.intel.ssid_rules import SsidRuleBook
from sentinel_rf.intel.watchlist import load_watchlist
from sentinel_rf.parse.observation import Observation
from sentinel_rf.sim.generator import RfSimulator, square_wave


def make_priors() -> PriorsEngine:
    wl = load_watchlist()
    return PriorsEngine(SsidRuleBook(wl), BleRuleBook(wl))


class TestFusion:
    def cfg(self):
        return load_config()

    def test_weights_and_bands(self):
        config = self.cfg()
        components = {
            "priors": ComponentResult("priors", True, score=40.0),
            "traffic": ComponentResult("traffic", True, score=80.0),
            "stimulus": ComponentResult("stimulus", True, score=90.0),
            "ble": ComponentResult("ble", True, score=60.0),
        }
        result = fuse(components, config)
        expected = (15 * 40 + 35 * 80 + 40 * 90 + 10 * 60) / 100.0
        assert result.score == pytest.approx(expected, abs=0.1)
        assert result.band == BAND_LIKELY
        assert result.is_alert

    def test_missing_components_renormalize(self):
        config = self.cfg()
        components = {
            "priors": ComponentResult("priors", True, score=0.0),
            "traffic": ComponentResult("traffic", True, score=80.0),
            "stimulus": ComponentResult("stimulus", False, reasons=["no test"]),
            "ble": ComponentResult("ble", False),
        }
        result = fuse(components, config)
        # weights 15+35=50 carry it: 0.3*0 + 0.7*80 = 56
        assert result.score == pytest.approx(56.0, abs=0.1)
        assert result.band == BAND_WATCH
        assert any("no test" in r for r in result.reasons)

    def test_all_unavailable(self):
        result = fuse(
            {
                "priors": ComponentResult.unavailable("priors"),
                "traffic": ComponentResult.unavailable("traffic"),
            },
            self.cfg(),
        )
        assert result.score == 0.0 and result.band == BAND_IGNORE

    def test_watch_band_boundary(self):
        config = self.cfg()
        components = {"traffic": ComponentResult("traffic", True, score=45.0)}
        assert fuse(components, config).band == BAND_WATCH
        components = {"traffic": ComponentResult("traffic", True, score=25.0)}
        assert fuse(components, config).band == BAND_IGNORE

    def test_contributions_sorted(self):
        components = {
            "priors": ComponentResult("priors", True, score=10.0),
            "traffic": ComponentResult("traffic", True, score=90.0),
        }
        result = fuse(components, self.cfg())
        assert result.contributions[0][0] == "traffic"


class TestTrafficRules:
    def test_camera_profile_scores_high(self):
        rules = TrafficRules()
        features = {
            "role_ap": 0.0,
            "data_ratio": 1.0,
            "uplink_share": 0.95,
            "qos_share": 0.9,
            "bytes_per_s": 250_000.0,
            "burst_periodicity": 0.6,
            "mean_frame_size": 900,
            "retry_rate": 0.08,
            "duty_cycle": 0.95,
            "iat_cv": 0.15,
            "frames_per_s": 40,
        }
        result = rules.score(features)
        assert result.score >= 60
        assert len(result.reasons) >= 5

    def test_ap_capped(self):
        rules = TrafficRules()
        result = rules.score({"role_ap": 1.0, "data_ratio": 0.05, "uplink_share": 0.9})
        assert result.score == 0.0
        assert "access point" in result.reasons[0]

    def test_idle_device(self):
        rules = TrafficRules()
        result = rules.score({"role_ap": 0.0, "data_ratio": 0.3, "uplink_share": 0.1})
        assert result.score == 0.0


class TestPriors:
    def test_camera_vendor_prior(self):
        priors = make_priors()
        result = priors.score(
            {"role_ap": 0.0, "is_ble": 0.0},
            DeviceIntel(vendor="Hikvision", vendor_category="camera_strong"),
        )
        assert result.score == pytest.approx(45.0)
        assert any("Hikvision" in r for r in result.reasons)

    def test_ssid_pattern_prior(self):
        priors = make_priors()
        result = priors.score({"role_ap": 1.0, "is_ble": 0.0}, DeviceIntel(ssid="V380-2F19"))
        assert result.score >= 40
        assert any("V380" in r for r in result.reasons)

    def test_clean_device_zero(self):
        priors = make_priors()
        result = priors.score(
            {"role_ap": 0.0, "is_ble": 0.0}, DeviceIntel(vendor="Apple", ssid="HomeWiFi")
        )
        assert result.score == 0.0


class TestStimulusCorrelate:
    def make_series(self, n=120, period=20, responsive=True, noise=0.05, seed=3):
        rng = np.random.default_rng(seed)
        stim = np.array([1.0 if ((i % period) < period // 2) else 0.0 for i in range(n)])
        if responsive:
            series = 100 + 80 * np.roll(stim, 1) + rng.normal(0, noise * 100, n)
        else:
            series = 100 + rng.normal(0, 25, n)
        return series, stim

    def test_responsive_detected_with_lag(self):
        series, stim = self.make_series()
        result = correlate(series, stim)
        assert result.verdict == "responsive"
        assert result.r > 0.5
        assert result.p <= 0.05
        assert result.lag_s == 1

    def test_unrelated_series_inconclusive_never_clear(self):
        series, stim = self.make_series(responsive=True)
        rng = np.random.default_rng(9)
        other = 100 + rng.normal(0, 30, len(series))
        result = correlate(other, stim)
        assert result.verdict in ("inconclusive", "insufficient")
        assert "INCONCLUSIVE" in result.reason or "insufficient" in result.reason

    def test_too_short_is_insufficient(self):
        result = correlate(np.ones(10), np.zeros(10))
        assert result.verdict == "insufficient"

    def test_unbalanced_stimulus_is_insufficient(self):
        stim = np.zeros(40)
        stim[:2] = 1.0
        result = correlate(np.random.default_rng(1).normal(100, 10, 40), stim)
        assert result.verdict == "insufficient"
        assert "on-bins" in result.reason

    def test_flat_series_inconclusive(self):
        stim = np.array([1.0 if (i % 20) < 10 else 0.0 for i in range(60)])
        result = correlate(np.full(60, 50.0), stim)
        assert result.verdict == "inconclusive"
        assert "no traffic variation" in result.reason

    def test_length_mismatch_raises(self):
        with pytest.raises(ValueError):
            correlate(np.ones(10), np.ones(11))

    def test_verdict_to_component_respects_hard_rule_7(self):
        inconclusive = StimulusResult(
            verdict="inconclusive", reason="no reliable response (inconclusive)"
        )
        component = verdict_to_component(inconclusive)
        assert component.available is False
        assert "INCONCLUSIVE" in component.reasons[0] or "inconclusive" in component.reasons[0]

        responsive = StimulusResult(
            verdict="responsive", r=0.8, p=0.001, lag_s=0, reason="responds"
        )
        component = verdict_to_component(responsive)
        assert component.available and component.score > 90

        weak = StimulusResult(verdict="weak", r=0.3, p=0.02, reason="weak")
        component = verdict_to_component(weak)
        assert component.available and component.score <= 50


class TestStimulusSession:
    def test_state_machine(self):
        session = StimulusSession()
        assert session.phase.value == "idle"
        t = 1000.0
        session.start(t)
        assert session.phase.value == "baseline"
        with pytest.raises(RuntimeError, match="baseline still running"):
            session.mark(True, t + 10)
        session.mark(False, t + 60)  # baseline done; first mark (off)
        assert session.phase.value == "stimulus"
        session.mark(True, t + 70)
        session.mark(False, t + 80)
        session.end(t + 90)
        assert session.phase.value == "done"

    def test_stimulus_vector(self):
        session = StimulusSession()
        t = 0.0
        session.start(t)
        session.mark(True, t + 60)
        session.mark(False, t + 70)
        vector = session.stimulus_vector(t, 80)
        assert vector[:60].sum() == 0
        assert vector[60:70].sum() == 10
        assert vector[70:].sum() == 0

    def test_restart_rejected(self):
        session = StimulusSession()
        session.start(1.0)
        with pytest.raises(RuntimeError):
            session.start(2.0)

    def test_tracker_end_to_end_with_sim(self):
        """Camera follows the light; the watch does not."""
        salt = b"0123456789abcdef"
        sim = RfSimulator(
            seed=77,
            duration_s=150.0,
            salt=salt,
            stimulus_signal=lambda t: square_wave(t - 60.0, period=20.0),
        )
        labels = sim.labels()
        session = StimulusSession()
        tracker = StimulusTracker(session)
        session.start(sim.t0)
        session.mark(True, sim.t0 + 60)
        session.mark(False, sim.t0 + 70)
        session.mark(True, sim.t0 + 80)
        session.mark(False, sim.t0 + 90)
        session.mark(True, sim.t0 + 100)
        session.mark(False, sim.t0 + 110)
        session.mark(True, sim.t0 + 120)
        session.mark(False, sim.t0 + 130)
        session.mark(True, sim.t0 + 140)
        for obs in sim.observations():
            tracker.update(obs)
        session.end()
        cam_hash = next(h for h, v in labels.items() if v["kind"] == "camera")
        watch_hash = next(h for h, v in labels.items() if v["kind"] == "ble_watch")
        cam_result = tracker.analyze(cam_hash)
        watch_result = tracker.analyze(watch_hash)
        assert cam_result.verdict == "responsive"
        assert cam_result.r > 0.4
        assert watch_result.verdict in ("inconclusive", "insufficient")

    def test_tracker_ignores_pre_session_frames(self):
        session = StimulusSession()
        session.start(100.0)
        tracker = StimulusTracker(session)
        obs = Observation.wifi(ts=50.0, node_id="n1", rssi_dbm=-55, addr_hash="a" * 16, length=100)
        tracker.update(obs)
        assert tracker.analyze("a" * 16).verdict == "insufficient"


class TestTrafficModelFast:
    """Small-footprint model tests (fast suite): tiny dataset, full API."""

    @pytest.fixture(scope="class")
    def tiny(self):
        return build_training_data(
            n_envs=2,
            base_seed=900,
            duration_s=90.0,
            window_step_s=30.0,
            salt=b"0123456789abcdef",
        )

    def test_dataset_builder_summary(self, tiny):
        X, y, groups, meta = tiny
        assert len(X) == len(y) == len(groups) == len(meta)
        summary = dataset_summary(meta, y)
        assert summary["n_samples"] == len(y)
        assert summary["n_environments"] == 2
        assert "camera" in str(summary["kind_counts"])

    def test_train_predict_contributions(self, tiny):
        X, y, _, meta = tiny
        model = TrafficModel.train(X, y, seed=1, dataset_info=dataset_summary(meta, y))
        features = {name: float(X[0][i]) for i, name in enumerate(model.card.feature_names)}
        p = model.predict_proba_camera(features)
        assert 0.0 <= p <= 1.0
        contributions = model.contributions(features)
        assert 1 <= len(contributions) <= 4

    def test_save_load_roundtrip(self, tiny, tmp_path):
        X, y, _, meta = tiny
        model = TrafficModel.train(X, y, seed=2, dataset_info=dataset_summary(meta, y))
        model.save(tmp_path / "m.joblib", tmp_path / "card.yaml")
        loaded = TrafficModel.load(tmp_path / "m.joblib")
        features = {name: float(X[1][i]) for i, name in enumerate(loaded.card.feature_names)}
        assert loaded.predict_proba_camera(features) == pytest.approx(
            model.predict_proba_camera(features)
        )
        assert (tmp_path / "card.yaml").exists()

    def test_requires_sklearn_error_message(self, monkeypatch):
        import builtins

        from sentinel_rf.detect.model import require_sklearn

        real_import = builtins.__import__

        def no_sklearn(name, *args, **kwargs):
            if name.startswith("sklearn"):
                raise ImportError("disabled for test")
            return real_import(name, *args, **kwargs)

        monkeypatch.setattr(builtins, "__import__", no_sklearn)
        with pytest.raises(ImportError, match=r"\.\[ml\]"):
            require_sklearn()


@pytest.mark.slow
class TestTrafficModel:
    @pytest.fixture(scope="class")
    def dataset(self):
        return build_training_data(
            n_envs=6, base_seed=500, duration_s=120.0, window_step_s=20.0, salt=b"0123456789abcdef"
        )

    def test_dataset_shape_and_labels(self, dataset):
        X, y, groups, meta = dataset
        assert len(X) == len(y) == len(groups) == len(meta)
        assert len(X) >= 100
        assert 0 < y.sum() < len(y)  # both classes present
        assert set(np.unique(y)) == {0, 1}
        assert len(np.unique(groups)) >= 15
        assert not any(math.isnan(float(v)) for row in X for v in row)

    def test_lodo_metrics_reasonable(self, dataset):
        X, y, groups, _ = dataset
        metrics = lodo_cross_validate(X, y, groups)
        assert metrics["accuracy"] >= 0.9
        assert metrics["recall"] >= 0.75
        assert metrics["precision"] >= 0.75
        assert metrics["roc_auc"] >= 0.9

    def test_train_save_load_and_contributions(self, dataset, tmp_path):
        X, y, groups, meta = dataset
        from sentinel_rf.detect.dataset import dataset_summary

        model = TrafficModel.train(X, y, seed=42, dataset_info=dataset_summary(meta, y))
        model_path = tmp_path / "model.joblib"
        card_path = tmp_path / "model_card.yaml"
        model.save(model_path, card_path)
        assert card_path.exists()

        loaded = TrafficModel.load(model_path)
        # same predictions after round trip
        features = {name: float(X[0][i]) for i, name in enumerate(loaded.card.feature_names)}
        assert loaded.predict_proba_camera(features) == pytest.approx(
            model.predict_proba_camera(features)
        )
        contributions = loaded.contributions(features)
        assert 1 <= len(contributions) <= 4
        assert all(isinstance(name, str) for name, _ in contributions)

    def test_card_contents(self, dataset, tmp_path):
        X, y, groups, meta = dataset
        model = TrafficModel.train(X, y, dataset_info=dataset_summary(meta, y))
        assert model.card.model_type == "RandomForestClassifier"
        assert "simulator" in model.card.notes
        assert model.card.dataset["n_samples"] == len(y)

    def test_feature_vocab_mismatch_detected(self, dataset, tmp_path, monkeypatch):
        X, y, _, _ = dataset
        model = TrafficModel.train(X, y)
        path = tmp_path / "m.joblib"
        model.save(path, tmp_path / "c.yaml")
        import joblib

        blob = joblib.load(path)
        blob["feature_names"] = ["other"] + blob["feature_names"][1:]
        joblib.dump(blob, path)
        with pytest.raises(ValueError, match="feature vocabulary"):
            TrafficModel.load(path)


class TestDetectorEndToEnd:
    @pytest.fixture()
    def detector(self):
        wl = load_watchlist()
        return Detector(
            load_config(),
            priors=PriorsEngine(SsidRuleBook(wl), BleRuleBook(wl)),
            ble_rules=BleRuleBook(wl),
            min_frames=50,
            cooldown_s=120.0,
        )

    def _run_sim(self, seed=42, seconds=100.0):
        salt = b"0123456789abcdef"
        sim = RfSimulator(seed=seed, duration_s=seconds, salt=salt)
        tracker = DeviceTracker()

        intel = IntelCache()
        sim.seed_intel(intel)
        for obs in sim.observations():
            tracker.update(obs)
            intel.update(obs)
        return sim, tracker, intel

    def test_camera_leads_bulk_upload_without_model(self, detector):
        sim, tracker, intel = self._run_sim()
        labels = sim.labels()
        now = sim.t0 + sim.duration_s
        scores = {}
        for addr_hash, info in labels.items():
            score = detector.evaluate(addr_hash, tracker, intel, now)
            scores[info["kind"]] = score
        camera = scores["camera"]
        assert camera.score >= 55  # watch band, just under 'likely' without ML
        assert camera.band == BAND_WATCH
        assert any("camera" in r.lower() or "video" in r.lower() for r in camera.reasons)
        bulk = scores["laptop_bulk_upload"]
        assert bulk.score < camera.score - 10
        call = scores["phone_video_call"]
        assert call.score < camera.score
        ap = scores["ap"]
        assert ap.band == BAND_IGNORE

    def _suspect_scenario(self, salt=b"0123456789abcdef"):
        """Camera-shaped traffic + strong vendor/SSID priors -> 'likely' band."""

        sim = RfSimulator(seed=42, duration_s=110.0, salt=salt)
        tracker = DeviceTracker()
        intel = IntelCache()
        sim.seed_intel(intel)
        for obs in sim.observations():
            tracker.update(obs)
        labels = sim.labels()
        cam_hash = next(h for h, v in labels.items() if v["kind"] == "camera")
        # strengthen priors: this camera's vendor is strong-surveillance and
        # its AP broadcasts a watchlist SSID (fusion stays renormalized)
        intel.seed(
            cam_hash,
            DeviceIntel(vendor="Hikvision", vendor_category="camera_strong"),
            override=True,
        )
        return tracker, intel, cam_hash, sim.t0 + 110.0

    def test_process_emits_alerts_with_cooldown(self, detector):
        tracker, intel, cam_hash, now = self._suspect_scenario()
        first = detector.process(tracker, intel, now)
        assert any(a.addr_hash == cam_hash for a in first)
        # immediate second round: cooldown suppresses (score unchanged)
        second = detector.process(tracker, intel, now + 1.0)
        assert not any(a.addr_hash == cam_hash for a in second)
        # a 10+ point jump would re-alert immediately (escalation rule)
        detector._last_alert_score[cam_hash] -= 20.0
        third = detector.process(tracker, intel, now + 2.0)
        assert any(a.addr_hash == cam_hash for a in third)
        assert any(a.escalated for a in third if a.addr_hash == cam_hash)

    def test_score_history_bounded(self, detector):
        sim, tracker, intel = self._run_sim(seconds=140.0)
        for t in range(60, 140, 5):
            detector.process(tracker, intel, sim.t0 + t)
        for history in detector.score_history.values():
            assert len(history) <= 600

    def test_device_score_dict_is_jsonable(self, detector):
        sim, tracker, intel = self._run_sim(seconds=90.0)
        labels = sim.labels()
        cam_hash = next(h for h, v in labels.items() if v["kind"] == "camera")
        score = detector.evaluate(cam_hash, tracker, intel, sim.t0 + 90.0)
        import json

        payload = json.dumps(score.to_dict())
        assert "reasons" in payload and "score" in payload

    def test_insufficient_frames_traffic_unavailable(self, detector):
        tracker = DeviceTracker()

        intel = IntelCache()
        for i in range(10):
            tracker.update(
                Observation.wifi(ts=i, node_id="n1", rssi_dbm=-55, addr_hash="a" * 16, length=100)
            )
        score = detector.evaluate("a" * 16, tracker, intel, 20.0)
        assert "traffic" in score.components
        assert score.components["traffic"].available is False
        assert "frames" in score.components["traffic"].reasons[0]


class TestAblation:
    def test_ablation_table(self):
        config = load_config()
        wl = load_watchlist()
        detector = Detector(
            config,
            priors=PriorsEngine(SsidRuleBook(wl), BleRuleBook(wl)),
            ble_rules=BleRuleBook(wl),
            min_frames=50,
        )
        salt = b"0123456789abcdef"
        sim = RfSimulator(seed=31, duration_s=110.0, salt=salt)
        tracker = DeviceTracker()

        intel = IntelCache()
        sim.seed_intel(intel)
        for obs in sim.observations():
            tracker.update(obs)
        labels = sim.labels()
        windows = []
        for addr_hash, window in tracker.snapshot(sim.t0 + 110.0).items():
            info = labels.get(addr_hash)
            if info and compute_features(window)["n_frames"] >= 50:
                windows.append(
                    {
                        "window": window,
                        "label": 1 if info["is_camera"] else 0,
                        "addr_hash": addr_hash,
                    }
                )
        assert len(windows) >= 6
        table = run_ablation(config=config, detector=detector, windows=windows, intel=intel)
        variants = {row["variant"] for row in table}
        assert "full fusion" in variants
        assert "without stimulus" in variants
        assert "without traffic" in variants
        assert "rules only (no ML)" in variants
        full = next(row for row in table if row["variant"] == "full fusion")
        no_traffic = next(row for row in table if row["variant"] == "without traffic")
        assert full["f1"] >= no_traffic["f1"]  # ablating evidence must not help
        text = format_ablation_table(table)
        assert "full fusion" in text and "precision" not in text
