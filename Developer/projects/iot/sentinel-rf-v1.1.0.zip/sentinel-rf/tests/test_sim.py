"""Simulator tests: determinism, ordering, labels, stimulus modulation."""

import math

from sentinel_rf.crypto import mac_hash
from sentinel_rf.parse.observation import Role, Source
from sentinel_rf.sim.generator import RfSimulator, SimDevice, square_wave, standard_devices


def run(sim, n=None):
    obs = list(sim.observations())
    return obs if n is None else obs[:n]


class TestDeterminism:
    def test_same_seed_same_stream(self):
        a = run(RfSimulator(seed=42, duration_s=30.0, salt=b"0123456789abcdef"))
        b = run(RfSimulator(seed=42, duration_s=30.0, salt=b"0123456789abcdef"))
        assert a == b  # dataclass equality on all fields

    def test_different_seed_differs(self):
        a = run(RfSimulator(seed=1, duration_s=30.0, salt=b"0123456789abcdef"))
        b = run(RfSimulator(seed=2, duration_s=30.0, salt=b"0123456789abcdef"))
        assert a != b

    def test_sorted_by_timestamp(self):
        ts = [o.ts for o in run(RfSimulator(seed=3, duration_s=20.0, salt=b"0123456789abcdef"))]
        assert ts == sorted(ts)


class TestStreamShape:
    def test_standard_cast_present(self):
        sim = RfSimulator(seed=5, duration_s=30.0, salt=b"0123456789abcdef")
        obs = run(sim)
        labels = sim.labels()
        assert any(v["kind"] == "camera" for v in labels.values())
        assert any(v["kind"] == "ap" for v in labels.values())
        assert any(v["kind"] == "ble_camera_companion" for v in labels.values())
        assert {o.source for o in obs} == {Source.WIFI, Source.BLE}

    def test_multi_node_copies(self):
        sim = RfSimulator(
            seed=5,
            duration_s=10.0,
            salt=b"0123456789abcdef",
            node_positions={"n1": (0.3, 0.3), "n2": (4.7, 0.3), "n3": (0.3, 3.7)},
        )
        obs = run(sim)
        counts = {}
        for o in obs:
            counts[o.node_id] = counts.get(o.node_id, 0) + 1
        assert set(counts) == {"n1", "n2", "n3"}
        # same frame seen by 3 nodes -> per-node counts near-equal
        assert max(counts.values()) - min(counts.values()) <= max(counts.values()) * 0.02 + 3

    def test_without_camera_no_positive_labels(self):
        sim = RfSimulator(
            seed=5,
            duration_s=10.0,
            salt=b"0123456789abcdef",
            devices=standard_devices(with_camera=False),
        )
        assert not any(v["is_camera"] for v in sim.labels().values())

    def test_camera_profile_is_uplink_qos_heavy(self):
        sim = RfSimulator(seed=11, duration_s=60.0, salt=b"0123456789abcdef")
        labels = sim.labels()
        cam_hash = next(h for h, v in labels.items() if v["kind"] == "camera")
        cam_obs = [o for o in run(sim) if o.addr_hash == cam_hash]
        assert len(cam_obs) > 200  # ~1.2 Mbps of ~900B frames over 60 s
        data = [o for o in cam_obs if o.frame_type == 2]
        assert len(data) > 0.9 * len(cam_obs)
        assert all(o.to_ds for o in data)
        assert sum(1 for o in data if o.frame_subtype == 8) > 0.8 * len(data)
        assert all(o.role is Role.STA for o in cam_obs)

    def test_bulk_upload_is_high_volume_negative(self):
        sim = RfSimulator(seed=11, duration_s=60.0, salt=b"0123456789abcdef")
        labels = sim.labels()
        bulk_hash = next(h for h, v in labels.items() if v["kind"] == "laptop_bulk_upload")
        bulk = [o for o in run(sim) if o.addr_hash == bulk_hash and o.frame_type == 2]
        assert len(bulk) > 500
        assert all(o.to_ds for o in bulk)  # it is uplink...
        assert not any(labels[o.addr_hash]["is_camera"] for o in bulk)  # ...but labelled negative

    def test_beacons_present_for_ap(self):
        sim = RfSimulator(seed=11, duration_s=30.0, salt=b"0123456789abcdef")
        labels = sim.labels()
        ap_hash = next(h for h, v in labels.items() if v["kind"] == "ap")
        ap_obs = [o for o in run(sim) if o.addr_hash == ap_hash]
        beacons = [o for o in ap_obs if o.frame_type == 0 and o.frame_subtype == 8]
        assert 200 <= len(beacons) <= 400  # ~102.4 ms interval over 30 s

    def test_ble_fields_carried(self):
        sim = RfSimulator(seed=11, duration_s=30.0, salt=b"0123456789abcdef")
        labels = sim.labels()
        tag_hash = next(h for h, v in labels.items() if v["kind"] == "ble_camera_companion")
        tag_obs = [o for o in run(sim) if o.addr_hash == tag_hash]
        assert tag_obs
        assert all(o.source is Source.BLE for o in tag_obs)
        assert all(o.name == "IPC-9F2A" for o in tag_obs)
        assert all(o.channel in (37, 38, 39) for o in tag_obs)
        assert all(o.company_id == 0x59 for o in tag_obs)

    def test_rssi_follows_inverse_distance(self):
        near = SimDevice("near", "camera", "24:0a:c4:00:00:10", (0.5, 0.5), is_camera=True)
        far = SimDevice("far", "camera", "24:0a:c4:00:00:11", (4.5, 3.5), is_camera=True)
        sim = RfSimulator(
            seed=2,
            duration_s=20.0,
            salt=b"0123456789abcdef",
            devices=[near, far],
            node_positions={"n1": (0.3, 0.3)},
        )
        obs = run(sim)
        near_rssi = [o.rssi_dbm for o in obs if o.addr_hash == mac_hash(near.mac, sim.salt)]
        far_rssi = [o.rssi_dbm for o in obs if o.addr_hash == mac_hash(far.mac, sim.salt)]
        assert sum(near_rssi) / len(near_rssi) > sum(far_rssi) / len(far_rssi) + 15.0


class TestStimulusModulation:
    def test_camera_bitrate_tracks_stimulus(self):
        """Uplink bytes during light-on windows must clearly exceed light-off."""
        period = 10.0
        stimulus = lambda t: square_wave(t, period=period, duty=0.5)  # noqa: E731
        sim = RfSimulator(
            seed=9,
            duration_s=120.0,
            salt=b"0123456789abcdef",
            stimulus_signal=stimulus,
        )
        labels = sim.labels()
        cam_hash = next(h for h, v in labels.items() if v["kind"] == "camera")
        obs = [o for o in run(sim) if o.addr_hash == cam_hash and o.frame_type == 2]

        def bytes_in(lo, hi):
            return sum(o.length for o in obs if lo <= (o.ts - sim.t0) < hi)

        on = sum(bytes_in(k * period, k * period + period / 2) for k in range(1, 11))
        off = sum(bytes_in(k * period + period / 2, (k + 1) * period) for k in range(1, 11))
        assert on > 1.5 * off  # activity 1.0 vs 0.0 -> bitrate ratio ~ (0.25+0.75)/(0.25)

    def test_default_activity_steady(self):
        sim = RfSimulator(seed=9, duration_s=60.0, salt=b"0123456789abcdef")
        labels = sim.labels()
        cam_hash = next(h for h, v in labels.items() if v["kind"] == "camera")
        obs = [o for o in run(sim) if o.addr_hash == cam_hash]
        by_second = {}
        for o in obs:
            by_second[int(o.ts - sim.t0)] = by_second.get(int(o.ts - sim.t0), 0) + o.length
        values = list(by_second.values())
        mean = sum(values) / len(values)
        assert all(0.3 * mean < v < 1.9 * mean for v in values)  # mild variation only


class TestLabels:
    def test_labels_keys_are_hashes(self):
        sim = RfSimulator(seed=4, duration_s=5.0, salt=b"0123456789abcdef")
        for h, v in sim.labels().items():
            assert len(h) == 16 and h == h.lower()
            assert set(v) == {"device_id", "kind", "is_camera", "position"}

    def test_summary_counts_kinds(self):
        sim = RfSimulator(seed=4, duration_s=20.0, salt=b"0123456789abcdef")
        summary = sim.summary()
        assert summary.get("ap", 0) > 100  # beacons
        assert summary.get("camera", 0) > 50


def test_square_wave():
    assert square_wave(0.0, period=10) == 1.0
    assert square_wave(4.9, period=10) == 1.0
    assert square_wave(5.0, period=10) == 0.0
    assert square_wave(9.9, period=10) == 0.0
    assert square_wave(3.0, period=10, hi=5.0, lo=1.0) == 5.0
    assert square_wave(8.0, period=10, hi=5.0, lo=1.0) == 1.0


def test_mobile_devices_stay_in_room():
    sim = RfSimulator(seed=6, duration_s=300.0, salt=b"0123456789abcdef")
    phone = next(d for d in sim.devices if d.kind == "phone_video_call")
    for t in (0.0, 50.0, 120.0, 290.0):
        x, y = sim._position_at(phone, t)
        assert 0.0 <= x <= sim.room[0] and 0.0 <= y <= sim.room[1]


def test_rssi_clamped_to_sensor_range():
    sim = RfSimulator(seed=6, duration_s=10.0, salt=b"0123456789abcdef", wifi_sigma=50.0)
    assert all(-95.0 <= o.rssi_dbm <= -25.0 for o in run(sim))


def test_no_math_domain_error_at_zero_distance():
    # device exactly at node position -> distance clamped, no log10(0)
    dev = SimDevice("on-top", "camera", "24:0a:c4:00:00:99", (0.3, 0.3), is_camera=True)
    sim = RfSimulator(
        seed=1,
        duration_s=5.0,
        salt=b"0123456789abcdef",
        devices=[dev],
        node_positions={"n1": (0.3, 0.3)},
    )
    obs = run(sim)
    assert obs and all(math.isfinite(o.rssi_dbm) for o in obs)
