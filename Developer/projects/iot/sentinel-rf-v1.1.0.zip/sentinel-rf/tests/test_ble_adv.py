"""BLE advertisement payload parser tests."""

import struct

from sentinel_rf.parse.ble_adv import (
    BleAdvInfo,
    ble_adv_frequency,
    parse_ad_structures,
    parse_ble_adv,
)


def ad(ad_type: int, value: bytes) -> bytes:
    return bytes([len(value) + 1, ad_type]) + value


class TestAdStructures:
    def test_split(self):
        data = ad(0x09, b"Cam") + ad(0x0A, b"\x04") + ad(0x03, struct.pack("<H", 0x180D))
        structs = parse_ad_structures(data)
        assert [t for t, _ in structs] == [0x09, 0x0A, 0x03]
        assert structs[0][1] == b"Cam"

    def test_zero_length_stops(self):
        data = ad(0x09, b"Cam") + b"\x00" + ad(0x0A, b"\x01")
        assert len(parse_ad_structures(data)) == 1

    def test_truncated_tail_kept(self):
        data = bytes([10, 0x09]) + b"abcdef"  # claims 9 value bytes, has 6
        structs = parse_ad_structures(data)
        assert len(structs) == 1
        assert structs[0] == (0x09, b"abcdef")

    def test_empty(self):
        assert parse_ad_structures(b"") == []


class TestParseBleAdv:
    def test_full_advertisement(self):
        adv = (
            ad(0x02, struct.pack("<H", 0x180F))
            + ad(0x09, b"IPC-9F2A")
            + ad(0x0A, struct.pack("<b", -4))
            + ad(0xFF, struct.pack("<H", 0x0059) + b"\x01\x02")
        )
        rsp = ad(0x03, struct.pack("<HH", 0x181A, 0x180D))
        info = parse_ble_adv(adv, rsp)
        assert info.name == "IPC-9F2A"
        assert info.tx_power == -4.0
        assert "180f" in info.uuids and "181a" in info.uuids and "180d" in info.uuids
        assert info.company_id == 0x0059
        assert info.adv_length == len(adv) + len(rsp)

    def test_128bit_uuid(self):
        uuid = bytes(range(16))
        info = parse_ble_adv(ad(0x07, uuid))
        assert info.uuids == (uuid.hex(),)

    def test_32bit_uuid(self):
        info = parse_ble_adv(ad(0x05, struct.pack("<I", 0xFEED1234)))
        assert info.uuids == ("feed1234",)

    def test_long_name_clamped(self):
        info = parse_ble_adv(ad(0x09, b"x" * 100))
        assert len(info.name) == 64

    def test_name_preference_complete_over_short(self):
        # first name wins; complete local name arrives first here
        info = parse_ble_adv(ad(0x09, b"Primary") + ad(0x08, b"Short"))
        assert info.name == "Primary"

    def test_short_name_alone(self):
        assert parse_ble_adv(ad(0x08, b"S")).name == "S"

    def test_empty_payload(self):
        info = parse_ble_adv(b"")
        assert isinstance(info, BleAdvInfo)
        assert info.name is None and info.company_id is None and info.uuids == ()

    def test_garbage_never_raises(self):
        for blob in (b"\xff", b"\x05", b"\x01\x02\x03", b"\xff" * 40, bytes([40, 0x09])):
            parse_ble_adv(blob)


def test_adv_frequency_mapping():
    assert ble_adv_frequency(37) == 2402.0
    assert ble_adv_frequency(38) == 2462.0
    assert ble_adv_frequency(39) == 2480.0
    assert ble_adv_frequency(None) is None
    assert ble_adv_frequency(6) is None
