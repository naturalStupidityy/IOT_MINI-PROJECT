"""802.11 header parser + Observation builder tests."""

import struct

import pytest

from sentinel_rf.crypto import mac_hash
from sentinel_rf.parse.dot11 import (
    Dot11Error,
    EphemeralWifi,
    build_observation,
    parse_dot11_header,
)
from sentinel_rf.parse.observation import Role, Source
from sentinel_rf.parse.radiotap import RadiotapMeta

AP = "b8:27:eb:11:22:33"
CAM = "24:0a:c4:aa:bb:cc"
PHONE = "f0:18:98:00:11:22"


def mac_bytes(mac: str) -> bytes:
    return bytes(int(p, 16) for p in mac.split(":"))


def fc(*, ftype=2, subtype=0, to_ds=False, from_ds=False, retry=False, protected=False):
    value = (ftype << 2) | (subtype << 4)
    if to_ds:
        value |= 0x0100
    if from_ds:
        value |= 0x0200
    if retry:
        value |= 0x0800
    if protected:
        value |= 0x4000
    return struct.pack("<H", value)


def data_frame(
    src=CAM,
    dst="ff:ff:ff:ff:ff:ff",
    bssid=AP,
    *,
    to_ds=True,
    from_ds=False,
    qos=False,
    retry=False,
    body_len=40,
):
    header = fc(to_ds=to_ds, from_ds=from_ds, retry=retry, subtype=8 if qos else 0)
    header += struct.pack("<H", 0)
    if to_ds and not from_ds:  # addr1=BSSID, addr2=SA, addr3=DA
        header += mac_bytes(bssid) + mac_bytes(src) + mac_bytes(dst)
    elif from_ds and not to_ds:  # addr1=DA, addr2=TA(AP), addr3=SA
        header += mac_bytes(dst) + mac_bytes(bssid) + mac_bytes(src)
    else:
        header += mac_bytes(dst) + mac_bytes(src) + mac_bytes(bssid)
    header += struct.pack("<H", 0x0123)
    if qos:
        header += struct.pack("<H", 0x0007)
    return header + b"\x00" * body_len


def beacon(src=AP, ssid=b"LabNet", channel=6):
    header = fc(ftype=0, subtype=8)
    header += struct.pack("<H", 0)
    header += mac_bytes("ff:ff:ff:ff:ff:ff") + mac_bytes(src) + mac_bytes(src)
    header += struct.pack("<H", 0x0040)
    body = struct.pack("<QHH", 0, 100, 0x0001)  # timestamp, interval, capab
    body += bytes([0, len(ssid)]) + ssid  # SSID IE
    body += bytes([3, 1, channel])  # DS parameter set
    body += bytes([221, 6]) + b"\x00\x50\xf2" + b"\x01\x01\x00"  # vendor IE (OUI+3)
    return header + body


def ctrl_ack(receiver=AP):
    header = fc(ftype=1, subtype=13)
    header += struct.pack("<H", 0)
    header += mac_bytes(receiver)
    return header


def meta(rssi=-55.0, freq=2437, rate=65.0):
    return RadiotapMeta(header_len=32, freq_mhz=freq, rssi_dbm=rssi, rate_mbps=rate)


class TestParseHeader:
    def test_beacon_header_fields(self):
        header, body = parse_dot11_header(beacon())
        assert header.type == 0 and header.subtype == 8
        assert header.addr2 == AP and header.addr3 == AP
        assert not header.retry and not header.protected

    def test_qos_data_uplink(self):
        header, _ = parse_dot11_header(data_frame(qos=True, retry=True))
        assert header.type == 2 and header.subtype == 8
        assert header.to_ds and not header.from_ds and header.retry
        assert header.addr1 == AP and header.addr2 == CAM

    def test_downlink_direction(self):
        header, _ = parse_dot11_header(data_frame(to_ds=False, from_ds=True))
        assert header.from_ds and not header.to_ds
        assert header.addr2 == AP  # transmitter is the AP

    def test_ctrl_ack_addr1_only(self):
        header, body = parse_dot11_header(ctrl_ack())
        assert header.type == 1 and header.subtype == 13
        assert header.addr1 == AP and header.addr2 is None
        assert body == b""

    def test_truncated_raises(self):
        with pytest.raises(Dot11Error, match="truncated"):
            parse_dot11_header(b"\x80\x00")

    def test_fcs_flag_reported(self):
        frame = data_frame() + b"\x00\x00\x00\x00"
        header, body = parse_dot11_header(frame, radiotap_flags=0x10)
        assert header.fcs_at_end


class TestBuildObservation:
    def test_uplink_qos_data(self, salt):
        obs, eps = build_observation(
            data_frame(qos=True, retry=True), meta(), ts=100.0, node_id="n1", salt=salt
        )
        assert obs is not None and eps is None
        assert obs.source is Source.WIFI
        assert obs.role is Role.STA
        assert obs.addr_hash == mac_hash(CAM, salt)
        assert obs.bssid_hash == mac_hash(AP, salt)
        assert obs.frame_type == 2 and obs.frame_subtype == 8
        assert obs.to_ds is True and obs.from_ds is False and obs.retry is True
        assert obs.channel == 6 and obs.freq_mhz == 2437
        assert obs.rate_mbps == 65.0 and obs.rssi_dbm == -55.0
        assert obs.raw_addr is None  # privacy default: raw never carried

    def test_beacon_yields_ephemeral_intel(self, salt):
        obs, eps = build_observation(
            beacon(ssid=b"IPCAM-7", channel=11), meta(freq=2452), ts=1.0, node_id="n1", salt=salt
        )
        assert obs.role is Role.AP
        assert obs.bssid_hash == mac_hash(AP, salt)
        assert isinstance(eps, EphemeralWifi)
        assert eps.ssid == "IPCAM-7"
        assert eps.channel_from_ie == 11
        assert eps.vendor_ouis == ("00:50:f2",)
        # the SSID (payload) must not leak into the Observation or its dict
        assert "IPCAM" not in str(obs.to_dict())

    def test_hidden_ssid_empty_string(self, salt):
        obs, eps = build_observation(beacon(ssid=b""), meta(), ts=1.0, node_id="n1", salt=salt)
        assert eps is not None and eps.ssid == ""
        assert obs is not None

    def test_downlink_attributed_to_ap(self, salt):
        obs, _ = build_observation(
            data_frame(to_ds=False, from_ds=True), meta(), ts=1.0, node_id="n1", salt=salt
        )
        assert obs.role is Role.AP
        assert obs.addr_hash == mac_hash(AP, salt)
        assert obs.from_ds is True

    def test_ack_attributed_to_receiver(self, salt):
        obs, _ = build_observation(ctrl_ack(), meta(), ts=1.0, node_id="n1", salt=salt)
        assert obs.addr_hash == mac_hash(AP, salt)
        assert obs.role is Role.UNKNOWN
        assert obs.frame_type == 1 and obs.frame_subtype == 13

    def test_raw_addr_only_when_allowed(self, salt):
        obs_allow, _ = build_observation(
            data_frame(), meta(), ts=1.0, node_id="n1", salt=salt, allow_raw=True
        )
        assert obs_allow.raw_addr == CAM
        obs_deny, _ = build_observation(
            data_frame(), meta(), ts=1.0, node_id="n1", salt=salt, allow_raw=False
        )
        assert obs_deny.raw_addr is None

    def test_wire_length_uses_orig_len(self, salt):
        frame = data_frame(body_len=200)
        obs, _ = build_observation(frame, meta(), ts=1.0, node_id="n1", salt=salt, wire_length=1500)
        assert obs.length == 1500  # on-air length, not the snaplen-truncated buffer

    def test_garbage_returns_none(self, salt):
        obs, eps = build_observation(b"\xff" * 10, meta(), ts=1.0, node_id="n1", salt=salt)
        assert obs is None and eps is None

    def test_locally_administered_flag(self, salt):
        randomized = "02:11:22:33:44:55"
        obs, _ = build_observation(
            data_frame(src=randomized), meta(), ts=1.0, node_id="n1", salt=salt
        )
        assert obs.addr_is_random is True
        obs2, _ = build_observation(data_frame(src=CAM), meta(), ts=1.0, node_id="n1", salt=salt)
        assert obs2.addr_is_random is False


class TestPrivacyOfEphemeral:
    def test_ephemeral_to_intel_dict_has_no_raw(self, salt):
        _, eps = build_observation(beacon(), meta(), ts=1.0, node_id="n1", salt=salt)
        d = eps.to_intel_dict()
        assert set(d) == {"ssid", "channel"}
        assert eps.raw_transmitter is None  # never populated by the builder
