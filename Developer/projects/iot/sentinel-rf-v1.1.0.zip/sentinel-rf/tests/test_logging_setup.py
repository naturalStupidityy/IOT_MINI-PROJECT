"""Logging setup tests."""

import logging

from sentinel_rf.config import LoggingConfig
from sentinel_rf.logging_setup import setup_logging


def reset():
    setup_logging(LoggingConfig())


def test_sets_level():
    setup_logging(LoggingConfig(level="DEBUG"))
    assert logging.getLogger("sentinel_rf").level == logging.DEBUG
    reset()


def test_idempotent_handlers(tmp_path):
    log_file = tmp_path / "run.log"
    setup_logging(LoggingConfig(level="INFO", file=log_file))
    count = len(logging.getLogger("sentinel_rf").handlers)
    setup_logging(LoggingConfig(level="INFO", file=log_file))
    assert len(logging.getLogger("sentinel_rf").handlers) == count
    reset()


def test_file_handler_writes(tmp_path):
    log_file = tmp_path / "run.log"
    setup_logging(LoggingConfig(level="DEBUG", file=log_file))
    logging.getLogger("sentinel_rf.core").debug("marker-42")
    for handler in logging.getLogger("sentinel_rf").handlers:
        handler.flush()
    assert "marker-42" in log_file.read_text(encoding="utf-8")
    reset()


def test_records_propagate_to_caplog(caplog):
    setup_logging(LoggingConfig(level="INFO"))
    with caplog.at_level(logging.INFO, logger="sentinel_rf"):
        logging.getLogger("sentinel_rf.child").info("hello-caplog")
    assert any(rec.message == "hello-caplog" for rec in caplog.records)
    reset()
