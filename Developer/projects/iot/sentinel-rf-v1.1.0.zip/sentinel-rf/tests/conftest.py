"""Shared pytest fixtures."""

import pytest

from sentinel_rf.crypto import new_salt


@pytest.fixture()
def salt() -> bytes:
    """A fresh per-test session salt."""
    return new_salt()
