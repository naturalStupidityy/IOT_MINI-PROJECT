"""Intel layer tests: OUI, watchlist, SSID/BLE rules, intel cache."""

import pytest

from sentinel_rf.intel.ble_rules import BleRuleBook
from sentinel_rf.intel.cache import DeviceIntel, IntelCache
from sentinel_rf.intel.oui import import_ieee_csv, load_packaged_oui
from sentinel_rf.intel.ssid_rules import SsidRuleBook
from sentinel_rf.intel.watchlist import DEFAULT_WATCHLIST, Watchlist, load_watchlist
from sentinel_rf.parse.observation import Observation


class TestOuiDb:
    # Module-level constant: formatting is identical under black 25 and 26
    # (the nested textwrap.dedent call inside write_text was not).
    _IEEE_CSV = "\n".join(
        [
            "Registry,Assignment,Organization Name",
            "MA-L,AA11BB,Some Camera Corp Hikvision Partner",
            "MA-L,CC22DD,Generic Gadgets Ltd",
            "MA-L,240AC4,Espressif Systems",
            "",
        ]
    )

    def test_packaged_loads_and_looks_up(self):
        db = load_packaged_oui()
        assert len(db) >= 20
        info = db.lookup("24:0a:c4:aa:bb:cc")
        assert info is not None and info.vendor == "Espressif"
        assert info.category == "camera_weak"
        assert 0 < info.prior_score < 1

        hik = db.lookup("44:19:B6:00:00:01")
        assert hik.category == "camera_strong" and hik.prior_score == 1.0

        assert db.lookup("00:00:00:00:00:00") is None

    def test_lookup_tolerates_case_and_bare_form(self):
        db = load_packaged_oui()
        assert db.lookup("B8:27:EB:11:22:33").vendor == "Raspberry Pi Foundation"
        assert db.lookup("b8:27:eb:11:22:33").vendor == "Raspberry Pi Foundation"

    def test_bad_prefix_shapes(self):
        db = load_packaged_oui()
        assert db.lookup("") is None
        assert db.lookup("no") is None

    def test_categories_counted(self):
        db = load_packaged_oui()
        cats = db.categories()
        assert cats.get("camera_strong", 0) >= 3
        assert cats.get("client", 0) >= 5

    def test_import_ieee_csv(self, tmp_path):
        ieee = tmp_path / "oui.csv"
        ieee.write_text(self._IEEE_CSV)
        db, added = import_ieee_csv(ieee)
        assert added == 3
        strong = db.lookup("aa:11:bb:00:00:01")
        assert strong.category == "camera_strong"
        assert db.lookup("cc:22:dd:00:00:01").category == "client"
        # packaged entries still present (user file may refine the name)
        assert db.lookup("24:0a:c4:00:00:01").vendor.startswith("Espressif")


class TestWatchlist:
    def test_default_watchlist_loads(self):
        wl = load_watchlist()
        assert wl.ssid_patterns and wl.ble_name_patterns
        assert wl.ble_company_ids[89]["vendor"] == "Nordic Semiconductor"

    def test_yaml_file_matches_code_default(self):
        """configs/watchlist.yaml must equal the built-in default (D011 pattern)."""
        import yaml

        with open("configs/watchlist.yaml", encoding="utf-8") as fh:
            on_disk = yaml.safe_load(fh)
        # compare through the same normalization (Watchlist.from_dict)
        assert (
            Watchlist.from_dict(on_disk).ssid_patterns
            == Watchlist.from_dict(DEFAULT_WATCHLIST).ssid_patterns
        )
        assert (
            Watchlist.from_dict(on_disk).ble_name_patterns
            == Watchlist.from_dict(DEFAULT_WATCHLIST).ble_name_patterns
        )
        assert (
            Watchlist.from_dict(on_disk).empty_ssid_score
            == Watchlist.from_dict(DEFAULT_WATCHLIST).empty_ssid_score
        )

    def test_explicit_path(self, tmp_path):
        custom = tmp_path / "wl.yaml"
        custom.write_text(
            "wifi:\n  ssid_patterns:\n    - {pattern: '(?i)xyzzy', score: 5, reason: test}\n"
            "  empty_ssid_score: 0\nble: {}\n"
        )
        wl = load_watchlist(custom)
        assert len(wl.ssid_patterns) == 1
        assert wl.empty_ssid_score == 0.0

    def test_invalid_regex_rejected(self, tmp_path):
        bad = tmp_path / "wl.yaml"
        bad.write_text("wifi:\n  ssid_patterns:\n    - {pattern: '[', score: 5}\nble: {}\n")
        with pytest.raises(ValueError, match="invalid SSID pattern"):
            load_watchlist(bad)

    def test_env_override(self, tmp_path, monkeypatch):
        custom = tmp_path / "wl.yaml"
        custom.write_text("wifi: {}\nble: {}\n")
        monkeypatch.setenv("SENTINEL_RF_WATCHLIST", str(custom))
        wl = load_watchlist()
        assert wl.ssid_patterns == []


class TestSsidRules:
    @pytest.fixture()
    def book(self):
        return SsidRuleBook(load_watchlist())

    def test_camera_hotspot_scores_high(self, book):
        result = book.score("V380-IPCAM")
        assert result.score >= 80
        assert any("IPCAM" in r for r in result.reasons)
        assert result.matched

    def test_normal_ssid_scores_zero(self, book):
        assert book.score("HomeWiFi-2G").score == 0.0
        assert book.score("eduroam").reasons == []

    def test_hidden_ssid(self, book):
        result = book.score("")
        assert result.score == 15.0
        assert any("hidden" in r.lower() for r in result.reasons)

    def test_none_ssid(self, book):
        assert book.score(None).score == 0.0

    def test_score_capped_at_100(self, book):
        result = book.score("IPCAM spy camera V380")
        assert result.score <= 100.0
        assert result.score == 100.0

    def test_match_text_included_in_reason(self, book):
        result = book.score("My YCC365 cam")
        assert "matched 'YCC365'" in " ".join(result.reasons)


class TestBleRules:
    @pytest.fixture()
    def book(self):
        return BleRuleBook(load_watchlist())

    def test_camera_name_scores(self, book):
        result = book.score(name="IPC-9F2A", company_id=89)
        assert result.score >= 45
        assert any("IPC" in r for r in result.reasons)

    def test_watch_name_not_flagged(self, book):
        result = book.score(name="Fit Watch 3", service_uuids=("180d",), company_id=135)
        assert result.score == 0.0

    def test_company_id_alone_small(self, book):
        result = book.score(name=None, company_id=89)
        assert result.score == 10.0
        assert any("Nordic" in r for r in result.reasons)

    def test_random_mac_small_bonus(self, book):
        assert book.score(name=None, addr_is_random=True).score == 5.0
        assert book.score(name=None, addr_is_random=False).score == 0.0

    def test_from_observation_fields(self, salt):
        book = BleRuleBook(load_watchlist())
        from sentinel_rf.crypto import mac_hash

        obs = Observation.ble(
            ts=1.0,
            node_id="n1",
            rssi_dbm=-60,
            addr_hash=mac_hash("24:0A:C4:AA:BB:CC", salt),
            name="IPC-9F2A",
            company_id=89,
        )
        result = book.score_observation_fields(obs)
        assert result.score >= 45


class TestIntelCache:
    def test_vendor_and_ssid_accumulate(self):
        cache = IntelCache()
        obs = Observation.wifi(
            ts=1.0,
            node_id="n1",
            rssi_dbm=-55,
            addr_hash="a" * 16,
            length=100,
        )

        class Ephemeral:
            vendor = "Espressif"
            vendor_category = "camera_weak"
            ssid = "LabNet"

        cache.update(obs, Ephemeral())
        intel = cache.get("a" * 16)
        assert intel.vendor == "Espressif"
        assert intel.ssid == "LabNet"
        assert cache.devices() == 1

    def test_ble_name_recorded(self):
        cache = IntelCache()
        obs = Observation.ble(ts=1.0, node_id="n1", rssi_dbm=-60, addr_hash="b" * 16, name="IPC-1")
        cache.update(obs)
        assert cache.get("b" * 16).ble_name == "IPC-1"

    def test_vendor_of_raw_mac(self):
        cache = IntelCache()
        info = cache.vendor_of("44:19:b6:12:34:56")
        assert info.vendor == "Hikvision"

    def test_seed_merges(self):
        cache = IntelCache()
        cache.seed("c" * 16, DeviceIntel(vendor="Espressif", ssid="X"))
        cache.seed("c" * 16, DeviceIntel(vendor=None, ble_name="IPC-2"))
        intel = cache.get("c" * 16)
        assert intel.vendor == "Espressif" and intel.ble_name == "IPC-2"

    def test_unknown_device_empty_intel(self):
        cache = IntelCache()
        assert cache.get("unknown").as_dict() == {
            "vendor": None,
            "ssid": None,
            "ble_name": None,
        }
