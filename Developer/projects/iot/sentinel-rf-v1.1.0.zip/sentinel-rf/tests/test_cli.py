"""CLI tests (Phase 0: --version only)."""

import pytest

import sentinel_rf
from sentinel_rf.ui.cli import build_parser, main


def test_no_args_returns_zero():
    assert main([]) == 0


def test_version_flag_exits_zero(capsys):
    with pytest.raises(SystemExit) as excinfo:
        main(["--version"])
    assert excinfo.value.code == 0
    out = capsys.readouterr().out
    assert sentinel_rf.__version__ in out
    assert "sentinel-rf" in out


def test_parser_identity():
    assert build_parser().prog == "sentinel"
