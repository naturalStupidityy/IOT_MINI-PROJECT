"""Phase 7 tests: pipeline, FastAPI + WebSocket, CLI commands."""

import json
import time

import pytest

from sentinel_rf.capture.manager import CaptureManager
from sentinel_rf.capture.wifi_monitor import IteratorWifiSource
from sentinel_rf.config import SentinelConfig, load_config
from sentinel_rf.detect.engine import Detector
from sentinel_rf.detect.rules import PriorsEngine
from sentinel_rf.intel.ble_rules import BleRuleBook
from sentinel_rf.intel.cache import IntelCache
from sentinel_rf.intel.ssid_rules import SsidRuleBook
from sentinel_rf.intel.watchlist import load_watchlist
from sentinel_rf.locate.anchors import Anchor, AnchorSet, RoomProfile
from sentinel_rf.locate.pathloss import PathLossModel
from sentinel_rf.pipeline import Pipeline
from sentinel_rf.sim.generator import RfSimulator
from sentinel_rf.transport.store import SqliteStore
from sentinel_rf.ui.cli import main as cli_main

SALT = b"0123456789abcdef"


def make_detector(config: SentinelConfig) -> Detector:
    watchlist = load_watchlist()
    return Detector(
        config,
        priors=PriorsEngine(SsidRuleBook(watchlist), BleRuleBook(watchlist)),
        ble_rules=BleRuleBook(watchlist),
        min_frames=50,
    )


def make_pipeline(tmp_path=None, seed=42, seconds=110.0, stimulus=None, config=None):
    config = config or load_config()
    salt = SALT
    sim = RfSimulator(seed=seed, duration_s=seconds, salt=salt, stimulus_signal=stimulus)
    manager = CaptureManager(queue_size=200_000)
    manager.wifi = IteratorWifiSource(
        manager.queue, observations_factory=sim.observations, node_id="sim"
    )
    intel = IntelCache()
    sim.seed_intel(intel)
    store = SqliteStore(tmp_path / "p.sqlite3", batch_size=500) if tmp_path else None
    profile = RoomProfile(
        width_m=5.0,
        height_m=4.0,
        pathloss=PathLossModel(),
        anchors=AnchorSet.from_list([Anchor("node-1", 0.3, 0.3)]),
    )
    pipeline = Pipeline(
        config,
        manager=manager,
        detector=make_detector(config),
        intel=intel,
        store=store,
        room_profile=profile,
        detect_interval_s=10.0,
    )
    return pipeline, sim, store


class TestPipeline:
    def test_run_processes_everything_and_alerts_camera(self, tmp_path):
        pipeline, sim, store = make_pipeline(tmp_path, seconds=110.0)
        pipeline.run()
        assert pipeline.counters["processed"] == len(list(sim.observations()))
        assert pipeline.counters["store_errors"] == 0
        labels = sim.labels()
        camera_hash = next(h for h, v in labels.items() if v["kind"] == "camera")
        assert camera_hash in pipeline.detector.latest
        camera_score = pipeline.detector.latest[camera_hash]
        # rules + priors alone land the camera in watch/likely (the ML model
        # and stimulus add the margin to a confident 'likely')
        assert camera_score.score > 50
        assert camera_score.band in ("watch", "likely")
        if camera_score.band == "likely":
            assert any(a.addr_hash == camera_hash for a in pipeline.alerts)
        if store is not None:
            store.flush()
            assert store.counts()["observations"] > 500
            store.close()

    def test_state_document_shape(self, tmp_path):
        pipeline, _, store = make_pipeline(tmp_path, seconds=60.0)
        pipeline.run()
        state = pipeline.state()
        for key in (
            "version",
            "uptime_s",
            "counters",
            "capture",
            "resources",
            "privacy",
            "stimulus",
            "devices",
            "alerts",
            "n_devices",
        ):
            assert key in state
        device = state["devices"][0]
        for key in ("addr_hash", "score", "band", "reasons", "n_frames"):
            assert key in device
        assert state["privacy"]["allow_raw_mac_live"] is False
        assert all(d["raw_addr"] is None for d in state["devices"])
        if store is not None:
            store.close()

    def test_stimulus_actions_flow(self, tmp_path):
        pipeline, _, store = make_pipeline(tmp_path, seconds=10.0)
        result = pipeline.stimulus_action("start")
        assert result["ok"] and result["phase"] == "baseline"
        result = pipeline.stimulus_action("mark_on")
        assert not result["ok"]  # baseline still running
        # fast-forward past the baseline
        pipeline.stimulus_session.started_at -= 120.0
        result = pipeline.stimulus_action("mark_on")
        assert result["ok"]
        result = pipeline.stimulus_action("mark_off")
        assert result["ok"]
        result = pipeline.stimulus_action("end")
        assert result["ok"] and result["phase"] == "done"
        result = pipeline.stimulus_action("bogus")
        assert not result["ok"]
        if store is not None:
            store.close()

    def test_locate_single_and_multi_node(self, tmp_path):
        import math

        profile = RoomProfile(
            width_m=5.0,
            height_m=4.0,
            pathloss=PathLossModel(),
            anchors=AnchorSet.from_list(
                [
                    Anchor("n1", 0.3, 0.3),
                    Anchor("n2", 4.7, 0.3),
                    Anchor("n3", 0.3, 3.7),
                    Anchor("n4", 4.7, 3.7),
                ]
            ),
        )
        config = load_config()
        sim = RfSimulator(
            seed=42,
            duration_s=90.0,
            salt=SALT,
            node_positions={"n1": (0.3, 0.3), "n2": (4.7, 0.3), "n3": (0.3, 3.7), "n4": (4.7, 3.7)},
        )
        manager = CaptureManager(queue_size=200_000)
        manager.wifi = IteratorWifiSource(
            manager.queue, observations_factory=sim.observations, node_id="n1"
        )
        pipeline = Pipeline(
            config,
            manager=manager,
            detector=make_detector(config),
            intel=IntelCache(),
            room_profile=profile,
            detect_interval_s=30.0,
        )
        pipeline.run()
        labels = sim.labels()
        camera_hash = next(h for h, v in labels.items() if v["kind"] == "camera")
        truth = labels[camera_hash]["position"]
        result = pipeline.locate(camera_hash)
        assert "grid" in result and "heatmap" in result
        estimate = result["grid"]
        assert set(estimate["node_ids"]) == {"n1", "n2", "n3", "n4"}
        error = math.hypot(estimate["x"] - truth[0], estimate["y"] - truth[1])
        assert error < 1.0, f"got {estimate}, truth {truth}"
        assert result["wls"] is not None

    def test_locate_unknown_device(self, tmp_path):
        pipeline, _, _ = make_pipeline(tmp_path, seconds=5.0)
        assert "error" in pipeline.locate("unknown-hash")

    def test_pipeline_never_leaks_raw_mac_in_state(self, tmp_path):
        pipeline, _, store = make_pipeline(tmp_path, seconds=20.0)
        pipeline.run()
        blob = json.dumps(pipeline.state())
        for device in RfSimulator(seed=42, duration_s=1.0, salt=SALT).devices:
            assert device.mac not in blob
        if store is not None:
            store.close()


class TestApi:
    @pytest.fixture()
    def app(self, tmp_path):
        from sentinel_rf.ui.api import create_app

        pipeline, sim, store = make_pipeline(tmp_path, seconds=90.0)
        app = create_app(pipeline, pipeline.config)
        app.state.sim = sim
        app.state.store = store
        return app

    @pytest.fixture()
    def client(self, app):
        from fastapi.testclient import TestClient

        with TestClient(app) as client:
            # let the pipeline thread chew through the sim for a moment
            deadline = time.time() + 30
            while time.time() < deadline:
                if app.state.pipeline.detector.latest:
                    break
                time.sleep(0.2)
            yield client
        app.state.store.close()

    def test_status_endpoint(self, client):
        payload = client.get("/api/status").json()
        assert payload["version"]
        assert "devices" in payload and "capture" in payload

    def test_devices_endpoint_privacy(self, client, app):
        payload = client.get("/api/devices").json()
        assert payload["privacy_allows_raw"] is False
        assert all(d["raw_addr"] is None for d in payload["devices"])
        revealed = client.get("/api/devices?reveal=1").json()
        assert all(d["raw_addr"] is None for d in revealed["devices"])

    def test_evidence_endpoint(self, client, app):
        addr_hash = next(iter(app.state.pipeline.detector.latest))
        payload = client.get(f"/api/devices/{addr_hash}/evidence").json()
        assert payload["addr_hash"] == addr_hash
        assert "reasons" in payload and "components_detail" in payload
        missing = client.get("/api/devices/unknown/evidence")
        assert missing.status_code == 404

    def test_alerts_and_observations(self, client, app):
        assert client.get("/api/alerts").json()["alerts"] is not None
        payload = client.get("/api/observations?limit=5").json()
        assert len(payload["observations"]) <= 5

    def test_stimulus_endpoint_conflict(self, client):
        response = client.post("/api/stimulus/mark_on")
        assert response.status_code == 409  # no session started yet

    def test_stimulus_endpoint_flow(self, client, app):
        assert client.post("/api/stimulus/start").json()["ok"]
        app.state.pipeline.stimulus_session.started_at -= 120.0
        assert client.post("/api/stimulus/mark_on").json()["ok"]
        assert client.post("/api/stimulus/mark_off").json()["ok"]
        assert client.post("/api/stimulus/end").json()["phase"] == "done"

    def test_locate_endpoint(self, client, app):
        addr_hash = next(iter(app.state.pipeline.detector.latest))
        payload = client.get(f"/api/locate/{addr_hash}").json()
        assert "grid" in payload or "single_node" in payload or "error" in payload

    def test_websocket_stream(self, client):
        with client.websocket_connect("/ws") as ws:
            message = json.loads(ws.receive_text())
            assert "devices" in message and "capture" in message

    def test_dashboard_served(self, client):
        response = client.get("/")
        assert response.status_code == 200
        assert "SENTINEL-RF" in response.text

    def test_static_assets(self, client):
        assert client.get("/app.js").status_code == 200
        assert client.get("/style.css").status_code == 200


class TestCli:
    def test_version(self, capsys):
        with pytest.raises(SystemExit) as exc:
            cli_main(["--version"])
        assert exc.value.code == 0
        assert "sentinel-rf" in capsys.readouterr().out

    def test_no_command_prints_help(self, capsys):
        assert cli_main([]) == 0
        assert "usage" in capsys.readouterr().out.lower()

    def test_doctor_json(self, capsys):
        assert cli_main(["doctor", "--json"]) in (0, 1)
        payload = json.loads(capsys.readouterr().out)
        assert isinstance(payload, list)

    def test_demo_short_run(self, capsys, tmp_path):
        db = tmp_path / "demo.sqlite3"
        code = cli_main(
            ["demo", "--seconds", "40", "--interval", "10", "--speed", "0", "--db", str(db)]
        )
        assert code == 0
        out = capsys.readouterr().out
        assert "final state" in out
        store = SqliteStore(db)
        assert store.counts()["observations"] > 100
        store.close()

    def test_replay_missing_file(self, capsys):
        assert cli_main(["replay", "/nonexistent.pcap"]) == 0  # counted, not fatal
        assert "packets=0" in capsys.readouterr().out

    def test_stimulus_needs_server(self, capsys):
        assert cli_main(["stimulus", "--url", "http://127.0.0.1:1", "start"]) == 1

    def test_locate_needs_store(self, capsys):
        assert cli_main(["locate", "--db", "/nonexistent.sqlite3", "--target", "a" * 16]) == 1

    def test_report_needs_store(self, capsys):
        assert cli_main(["report", "--db", "/nonexistent.sqlite3"]) == 1

    def test_report_from_demo_db(self, capsys, tmp_path):
        db = tmp_path / "demo.sqlite3"
        cli_main(["demo", "--seconds", "40", "--interval", "10", "--speed", "0", "--db", str(db)])
        capsys.readouterr()
        out_path = tmp_path / "report.md"
        assert cli_main(["report", "--db", str(db), "--out", str(out_path)]) == 0
        text = out_path.read_text()
        assert "session report" in text
        assert "Most recently active devices" in text
        # either honest outcome is valid: alerts with reasons, or the explicit
        # "no alerts is not proof" disclaimer
        store = SqliteStore(db)
        n_alerts = store.counts()["alerts"]
        store.close()
        if n_alerts == 0:
            assert "NOT evidence that no cameras" in text
        else:
            assert "## Alerts" in text

    def test_serve_requires_demo_flag(self, capsys):
        assert cli_main(["serve"]) == 2

    def test_hotcold_simulate(self, capsys):
        assert cli_main(["hotcold", "--target", "a" * 16, "--simulate"]) == 0
        assert "proximity" in capsys.readouterr().out

    def test_monitor_no_wifi_short_run(self, capsys, tmp_path):
        # BLE-only node wiring (macOS path): NullWifiMonitor + no real radio,
        # hardware-free end to end. Also proves old-pip editable installs can
        # run the full pipeline on a fresh venv.
        db = tmp_path / "ble-node.sqlite3"
        code = cli_main(["monitor", "--no-wifi", "--duration", "2", "--db", str(db)])
        assert code == 0
        out = capsys.readouterr().out
        assert "BLE-only node" in out
        store = SqliteStore(db)
        assert store.counts()["observations"] == 0  # no radio: no data, no crash
        store.close()
