"""Fuzz tests (Phase 8): garbage must never crash the capture path.

Random and adversarial buffers are pushed through every byte-level parser
and the store boundary. Expected behaviour: errors are counted or skipped;
exceptions never escape into the capture loop (quality bar: a malformed
frame must never stop sensing).
"""

import contextlib
import random

import pytest

from sentinel_rf.parse.ble_adv import parse_ad_structures, parse_ble_adv
from sentinel_rf.parse.dot11 import build_observation, parse_dot11_header
from sentinel_rf.parse.radiotap import RadiotapError, parse_radiotap
from sentinel_rf.privacy import PrivacyViolation
from sentinel_rf.transport.store import InMemoryStore

SALT = b"0123456789abcdef"


def _meta():
    import struct

    presence = (1 << 2) | (1 << 5)
    header = struct.pack("<BBHI", 0, 0, 0, presence)
    header += bytes([12]) + bytes([0xC7])  # rate 6 Mbps, signal -57 dBm
    struct.pack_into("<H", hdr := bytearray(header), 2, len(hdr))
    meta, _ = parse_radiotap(bytes(hdr))
    return meta


class TestFuzzRadiotap:
    def test_random_buffers_never_raise(self):
        rng = random.Random(1234)
        for _ in range(2000):
            blob = bytes(rng.getrandbits(8) for _ in range(rng.randint(0, 64)))
            with contextlib.suppress(RadiotapError):
                parse_radiotap(blob)  # errors are counted by the capture loop

    def test_mutated_valid_headers(self):
        import struct

        rng = random.Random(99)
        base = bytearray(
            struct.pack("<BBHI", 0, 0, 0, (1 << 2) | (1 << 3) | (1 << 5))
            + bytes([12])
            + struct.pack("<HH", 2437, 0)
            + bytes([0xC7])
        )
        for _ in range(2000):
            mutated = bytearray(base)
            for _ in range(rng.randint(1, 3)):
                mutated[rng.randrange(len(mutated))] = rng.getrandbits(8)
            with contextlib.suppress(RadiotapError):
                parse_radiotap(bytes(mutated))


class TestFuzzDot11:
    def test_random_frames_counted_not_raised(self):
        rng = random.Random(4321)
        for _ in range(2000):
            blob = bytes(rng.getrandbits(8) for _ in range(rng.randint(0, 80)))
            try:
                parse_dot11_header(blob)
            except Exception as exc:  # only our ValueError may escape
                assert type(exc).__name__ == "Dot11Error"

    def test_build_observation_survives_garbage(self):
        rng = random.Random(777)
        meta = _meta()
        parsed = unsupported = 0
        for _ in range(2000):
            blob = bytes(rng.getrandbits(8) for _ in range(rng.randint(0, 60)))
            obs, _eps = build_observation(blob, meta, ts=1.0, node_id="fuzz", salt=SALT)
            if obs is None:
                unsupported += 1
            else:
                parsed += 1
        assert parsed + unsupported == 2000

    def test_truncated_valid_frame(self):
        # A valid-ish 24-byte header chopped at every length.
        frame = bytes.fromhex("8841") + b"\x00\x00" + b"\xff" * 6 + b"\x24" * 6 + b"\x00" * 6
        for cut in range(len(frame)):
            try:
                parse_dot11_header(frame[:cut])
            except Exception as exc:
                assert type(exc).__name__ == "Dot11Error"


class TestFuzzBleAdv:
    def test_random_advertisements(self):
        rng = random.Random(2468)
        for _ in range(3000):
            blob = bytes(rng.getrandbits(8) for _ in range(rng.randint(0, 64)))
            info = parse_ble_adv(blob)  # never raises
            assert info.adv_length == len(blob)
        for _ in range(1000):
            adv = bytes(rng.getrandbits(8) for _ in range(rng.randint(0, 31)))
            rsp = bytes(rng.getrandbits(8) for _ in range(rng.randint(0, 31)))
            parse_ble_adv(adv, rsp)

    def test_ad_structures_terminate(self):
        rng = random.Random(1357)
        for _ in range(2000):
            blob = bytes(rng.getrandbits(8) for _ in range(rng.randint(0, 40)))
            structs = parse_ad_structures(blob)
            assert len(structs) <= len(blob)


class TestFuzzStoreBoundary:
    def test_hostile_payloads_rejected_cleanly(self):
        store = InMemoryStore(max_observations=10)
        hostile = [
            {"mac": "24:0a:c4:aa:bb:cc"},
            {"raw_addr": "24:0a:c4:aa:bb:cc"},
            {"note": "found 24-0a-c4-aa-bb-cc device"},
            {"deep": ["nested", "aa:bb:cc:dd:ee:ff"]},
        ]
        for payload in hostile:
            with pytest.raises(PrivacyViolation):
                store.add_payload(payload)
        assert len(store) == 0

    def test_valid_observation_through_fuzz_meta(self):
        meta = _meta()
        obs, _ = build_observation(
            bytes.fromhex("8841")
            + b"\x00\x00"
            + b"\xb8\x27\xeb\x11\x22\x33"
            + b"\x24\x0a\xc4\xaa\xbb\xcc"
            + b"\xff" * 6
            + b"\x00" * 8,
            meta,
            ts=1.0,
            node_id="fuzz",
            salt=SALT,
        )
        assert obs is not None
        store = InMemoryStore()
        store.add_observation(obs)
        assert len(store) == 1
        assert "24:0a:c4" not in str(store.observations()[0])
