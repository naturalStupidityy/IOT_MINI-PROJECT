"""Soak test (Phase 8): the full pipeline under sustained load.

Runs the pipeline over 60 simulated seconds (fast playback) and enforces
the operating budget from the spec: no crash, drop rate < 2%, RSS under
300 MB, every observation accounted for. This is the laptop stand-in for
the Pi soak procedure (docs/DEPLOYMENT.md documents the on-Pi variant).
"""

import resource
import time

import pytest

from sentinel_rf.capture.manager import CaptureManager
from sentinel_rf.capture.wifi_monitor import IteratorWifiSource
from sentinel_rf.config import load_config
from sentinel_rf.intel.cache import IntelCache
from sentinel_rf.pipeline import Pipeline
from sentinel_rf.sim.generator import RfSimulator
from tests.test_ui import make_detector


@pytest.mark.slow
class TestSoak:
    def test_60s_pipeline_soak(self, tmp_path):
        from sentinel_rf.transport.store import SqliteStore

        salt = b"0123456789abcdef"
        config = load_config()
        sim = RfSimulator(seed=1234, duration_s=60.0, salt=salt)
        total = sum(1 for _ in sim.observations())  # consume once for the count

        manager = CaptureManager(queue_size=config.capture.queue_size)
        # Paced playback (8x): a realistic sustained rate the consumer must
        # absorb with <2% drops. The unpaced flood variant lives below.
        manager.wifi = IteratorWifiSource(
            manager.queue,
            observations_factory=lambda: RfSimulator(
                seed=1234, duration_s=60.0, salt=salt
            ).observations(),
            node_id="soak",
            speed=8.0,
        )
        intel = IntelCache()
        sim.seed_intel(intel)
        store = SqliteStore(tmp_path / "soak.sqlite3", batch_size=500)
        pipeline = Pipeline(
            config,
            manager=manager,
            detector=make_detector(config),
            intel=intel,
            store=store,
            detect_interval_s=5.0,
        )
        t0 = time.monotonic()
        pipeline.run()
        elapsed = time.monotonic() - t0

        capture = pipeline.manager.stats()
        rss_mb = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss / 1024.0
        store.flush()
        counts = store.counts()
        store.close()

        # every observation processed exactly once, nothing lost silently
        assert pipeline.counters["processed"] == total
        assert pipeline.counters["store_errors"] == 0
        assert counts["observations"] + (capture["dropped"] or 0) >= total - 1
        # budget: <2% drops (queue sized for this load), <300 MB RSS
        assert capture["drop_pct"] < 2.0, f"drop rate {capture['drop_pct']}%"
        assert rss_mb < 300.0, f"RSS {rss_mb:.0f} MB over budget"
        # detection kept up: scores exist for the main cast
        assert len(pipeline.detector.latest) >= 8
        # wall-time sanity: fast playback of 60 event-seconds
        assert elapsed < 120.0

    def test_flood_is_accounted_not_silent(self):
        """Unpaced flood: drops must be counted, never silently discarded."""
        salt = b"0123456789abcdef"
        config = load_config()
        sim = RfSimulator(seed=1234, duration_s=60.0, salt=salt)
        total = sum(1 for _ in sim.observations())
        manager = CaptureManager(queue_size=1024)
        manager.wifi = IteratorWifiSource(
            manager.queue,
            observations_factory=lambda: RfSimulator(
                seed=1234, duration_s=60.0, salt=salt
            ).observations(),
            node_id="flood",
            speed=0.0,
        )
        pipeline = Pipeline(
            config,
            manager=manager,
            detector=make_detector(config),
            intel=IntelCache(),
            detect_interval_s=5.0,
        )
        pipeline.run()
        capture = pipeline.manager.stats()
        emitted_plus_dropped = capture["emitted"] + capture["dropped"]
        assert emitted_plus_dropped >= total * 0.99  # nothing vanishes uncounted
        assert capture["dropped"] > 0  # a flood this size SHOULD trip the budget

    def test_idle_live_path_uses_wall_clock_ticks(self):
        """A quiet live source must still get detection ticks (wall clock)."""

        from sentinel_rf.capture.wifi_monitor import NullWifiMonitor

        config = load_config()
        manager = CaptureManager(queue_size=64)
        manager.wifi = NullWifiMonitor(manager.queue, node_id="quiet")
        pipeline = Pipeline(
            config,
            manager=manager,
            detector=make_detector(config),
            intel=IntelCache(),
            detect_interval_s=0.4,
        )
        ticks = []
        original = pipeline._detect_tick

        def counting_tick(now):
            ticks.append(now)
            original(now)

        pipeline._detect_tick = counting_tick
        manager.start()
        deadline = time.time() + 2.0
        while time.time() < deadline and len(ticks) < 3:
            if pipeline.idle_tick():
                continue
            time.sleep(0.05)
        manager.stop()
        assert len(ticks) >= 3
