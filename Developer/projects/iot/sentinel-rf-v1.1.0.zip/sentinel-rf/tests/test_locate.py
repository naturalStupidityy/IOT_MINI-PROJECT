"""Localization tests: pathloss fit, grid, WLS, survey, hot-cold."""

import math
import time

import numpy as np
import pytest

from sentinel_rf.crypto import mac_hash
from sentinel_rf.locate.anchors import Anchor, AnchorSet, RoomProfile
from sentinel_rf.locate.grid import GridLocator
from sentinel_rf.locate.hotcold import HotColdGuide, score_from_rssi
from sentinel_rf.locate.lsq import wls_estimate
from sentinel_rf.locate.pathloss import (
    PathLossModel,
    fit,
    median_rssi,
    residual_db,
    trimmed_mean,
)
from sentinel_rf.locate.survey import SurveyRunner, collect_measurements
from sentinel_rf.parse.observation import Observation
from sentinel_rf.sim.generator import RfSimulator
from sentinel_rf.system.led import FakeLed

SALT = b"0123456789abcdef"


def four_corner_profile(sigma=3.0, p0=-40.0, n=2.5) -> RoomProfile:
    return RoomProfile(
        name="test-room",
        width_m=5.0,
        height_m=4.0,
        pathloss=PathLossModel(p0_dbm=p0, n=n, sigma_db=sigma),
        anchors=AnchorSet.from_list(
            [
                Anchor("n1", 0.3, 0.3),
                Anchor("n2", 4.7, 0.3),
                Anchor("n3", 0.3, 3.7),
                Anchor("n4", 4.7, 3.7),
            ]
        ),
    )


def rssi_at(model, distance):
    return model.p0_dbm - 10.0 * model.n * math.log10(max(distance, 0.25))


class TestPathLoss:
    def test_roundtrip(self):
        model = PathLossModel(p0_dbm=-42.0, n=3.0)
        for d in (0.5, 1.0, 2.0, 5.0):
            assert model.distance_from(model.rssi_at(d)) == pytest.approx(d, rel=1e-9)

    def test_fit_recovers_parameters(self):
        truth = PathLossModel(p0_dbm=-38.5, n=3.2)
        data = [(d, truth.rssi_at(d)) for d in (1.0, 2.0, 4.0, 8.0)]
        fitted = fit(data)
        assert fitted.p0_dbm == pytest.approx(-38.5, abs=0.2)
        assert fitted.n == pytest.approx(3.2, abs=0.05)

    def test_fit_with_noise_still_close(self):
        rng = np.random.default_rng(5)
        truth = PathLossModel(p0_dbm=-45.0, n=2.8)
        data = [(d, truth.rssi_at(d) + rng.normal(0, 1.0)) for d in (1, 1.5, 2, 3, 5, 7)]
        fitted = fit(data)
        assert fitted.p0_dbm == pytest.approx(-45.0, abs=1.5)
        assert fitted.n == pytest.approx(2.8, abs=0.25)

    def test_fit_rejects_degenerate_input(self):
        with pytest.raises(ValueError):
            fit([(1.0, -40.0)])
        with pytest.raises(ValueError):
            fit([(1.0, -40.0), (1.0, -41.0)])

    def test_fit_rejects_implausible_exponent(self):
        # RSSI increasing with distance -> negative n
        with pytest.raises(ValueError, match="path-loss exponent"):
            fit([(1.0, -80.0), (4.0, -40.0)])

    def test_residual_and_aggregates(self):
        model = PathLossModel()
        assert residual_db(model, model.rssi_at(2.0) + 1.0, 2.0) == pytest.approx(1.0)
        assert median_rssi([-60, -62, -58]) == -60.0
        assert median_rssi([-60, -62]) == -61.0
        assert trimmed_mean([1, 2, 3, 4, 100], trim=0.2) == pytest.approx(3.0)
        with pytest.raises(ValueError):
            median_rssi([])


class TestRoomProfile:
    def test_yaml_roundtrip(self, tmp_path):
        profile = four_corner_profile()
        path = tmp_path / "room.yaml"
        profile.save(path)
        loaded = RoomProfile.load(path)
        assert loaded.name == "test-room"
        assert len(loaded.anchors) == 4
        assert loaded.pathloss.n == pytest.approx(2.5)
        assert loaded.anchors.get("n3").x == pytest.approx(0.3)

    def test_anchor_outside_room_rejected(self):
        with pytest.raises(ValueError, match="outside"):
            RoomProfile(
                width_m=5.0,
                height_m=4.0,
                anchors=AnchorSet.from_list([Anchor("n1", 9.0, 9.0)]),
            )

    def test_duplicate_anchor_ids_rejected(self):
        with pytest.raises(ValueError, match="duplicate"):
            AnchorSet.from_list([Anchor("n1", 0, 0), Anchor("n1", 1, 1)])

    def test_shipped_lab_profile_loads(self):
        profile = RoomProfile.load("configs/rooms/lab.yaml")
        assert profile.name == "lab-demo"
        assert len(profile.anchors) >= 1


class TestGridLocator:
    def test_exact_readings_pin_location(self):
        profile = four_corner_profile()
        locator = GridLocator(profile, grid_resolution_m=0.1)
        truth = (3.2, 2.6)
        measurements = {
            a.node_id: rssi_at(profile.pathloss, a.distance_to(*truth)) for a in profile.anchors
        }
        estimate = locator.estimate(measurements)
        assert estimate.x == pytest.approx(truth[0], abs=0.15)
        assert estimate.y == pytest.approx(truth[1], abs=0.15)
        assert estimate.sigma_m < 1.0  # ~0.8 m spread is honest at sigma_db=3
        assert estimate.method == "grid"

    def test_noisy_readings_still_close(self):
        profile = four_corner_profile(sigma=3.0)
        locator = GridLocator(profile, grid_resolution_m=0.25)
        rng = np.random.default_rng(11)
        truth = (1.4, 3.1)
        measurements = {
            a.node_id: rssi_at(profile.pathloss, a.distance_to(*truth)) + rng.normal(0, 2.0)
            for a in profile.anchors
        }
        estimate = locator.estimate(measurements)
        error = math.hypot(estimate.x - truth[0], estimate.y - truth[1])
        assert error < 1.0
        assert 0.0 <= estimate.sigma_m <= 3.0

    def test_unknown_nodes_ignored(self):
        profile = four_corner_profile()
        locator = GridLocator(profile)
        truth = (2.5, 2.0)
        measurements = {
            a.node_id: rssi_at(profile.pathloss, a.distance_to(*truth)) for a in profile.anchors
        }
        measurements["ghost-node"] = -50.0
        estimate = locator.estimate(measurements)
        assert estimate.x == pytest.approx(truth[0], abs=0.2)

    def test_no_usable_measurements_raises(self):
        locator = GridLocator(four_corner_profile())
        with pytest.raises(ValueError):
            locator.estimate({"nothing": -50.0})

    def test_invalid_resolution_rejected(self):
        with pytest.raises(ValueError):
            GridLocator(four_corner_profile(), grid_resolution_m=0.0)

    def test_heatmap_structure(self):
        profile = four_corner_profile()
        locator = GridLocator(profile, grid_resolution_m=0.5)
        payload = locator.heatmap({"n1": -50.0, "n2": -60.0, "n3": -55.0, "n4": -58.0})
        assert payload["shape"] == [8, 10]  # 4m/0.5 x 5m/0.5
        assert payload["extent"] == [0.0, 5.0, 0.0, 4.0]
        posterior = np.array(payload["posterior"])
        assert pytest.approx(posterior.sum(), abs=1e-9) == 1.0

    def test_single_anchor_distance_estimate(self):
        profile = four_corner_profile()
        locator = GridLocator(profile)
        estimate = locator.single_node_estimate("n1", profile.pathloss.rssi_at(2.0))
        assert estimate.method == "single-anchor-distance"
        assert estimate.node_ids == ("n1",)
        assert estimate.sigma_m >= 1.0  # honest: a ring, not a point


class TestWLS:
    def test_matches_grid_on_clean_data(self):
        profile = four_corner_profile()
        locator = GridLocator(profile, grid_resolution_m=0.25)
        truth = (2.0, 1.0)
        measurements = {
            a.node_id: rssi_at(profile.pathloss, a.distance_to(*truth)) for a in profile.anchors
        }
        grid_est = locator.estimate(measurements)
        wls_est = wls_estimate(measurements, profile)
        assert math.hypot(wls_est.x - truth[0], wls_est.y - truth[1]) < 0.3
        assert math.hypot(grid_est.x - wls_est.x, grid_est.y - wls_est.y) < 0.5
        assert wls_est.method == "wls"

    def test_needs_two_anchors(self):
        profile = four_corner_profile()
        with pytest.raises(ValueError, match="two anchors"):
            wls_estimate({"n1": -50.0}, profile)

    def test_robust_to_one_bad_anchor(self):
        profile = four_corner_profile()
        truth = (3.5, 0.8)
        measurements = {
            a.node_id: rssi_at(profile.pathloss, a.distance_to(*truth)) for a in profile.anchors
        }
        measurements["n3"] = measurements["n3"] + 15.0  # one bad reading
        estimate = wls_estimate(measurements, profile)
        error = math.hypot(estimate.x - truth[0], estimate.y - truth[1])
        assert error < 1.2  # soft_l1 keeps it in the neighbourhood


class TestSurvey:
    def _sim_with_target(self, position=(2.5, 2.0), seed=13):
        from sentinel_rf.sim.generator import SimDevice, standard_devices

        target = SimDevice(
            device_id="target-cam",
            kind="camera",
            mac="24:0a:c4:77:88:99",
            position=position,
            is_camera=True,
        )
        profile = four_corner_profile()
        sim = RfSimulator(
            seed=seed,
            duration_s=40.0,
            salt=SALT,
            devices=standard_devices((5.0, 4.0)) + [target],
            node_positions={a.node_id: (a.x, a.y) for a in profile.anchors},
        )
        return sim, profile, mac_hash("24:0a:c4:77:88:99", SALT)

    def test_survey_recovers_position(self):
        sim, profile, target_hash = self._sim_with_target(position=(2.5, 2.0))
        runner = SurveyRunner(target_hash=target_hash, profile=profile, min_waypoints=2)
        observations = list(sim.observations())
        # Two pseudo-waypoints (same data, different labels): enough nodes see
        # the target for a merged measurement set.
        runner.begin_waypoint(1.0, 1.0)
        for obs in observations:
            runner.update(obs)
        runner.end_waypoint()
        measurements = runner.measurement_set()
        assert len(measurements) == 4
        locator = GridLocator(profile, grid_resolution_m=0.25)
        estimate = runner.estimate(locator)
        error = math.hypot(estimate.x - 2.5, estimate.y - 2.0)
        assert error < 1.2, f"estimate {estimate.x:.2f},{estimate.y:.2f}"

    def test_waypoint_lifecycle_errors(self):
        runner = SurveyRunner(target_hash="a" * 16, profile=four_corner_profile())
        with pytest.raises(RuntimeError, match="no waypoint"):
            runner.end_waypoint()
        runner.begin_waypoint(0, 0)
        with pytest.raises(RuntimeError, match="before beginning"):
            runner.begin_waypoint(1, 1)
        runner.end_waypoint()
        assert runner.summary()["waypoints"][0]["n"] == 0

    def test_only_target_recorded(self):
        sim, profile, target_hash = self._sim_with_target()
        runner = SurveyRunner(target_hash=target_hash, profile=profile)
        runner.begin_waypoint(0, 0)
        for obs in list(sim.observations())[:2000]:
            runner.update(obs)
        result = runner.end_waypoint()
        nodes_with_data = {n for n, v in result.samples.items() if v}
        assert nodes_with_data
        assert all(len(v) <= 5000 for v in result.samples.values())

    def test_bad_aggregate_rejected(self):
        with pytest.raises(ValueError):
            SurveyRunner(target_hash="a", profile=four_corner_profile(), aggregate="mean")

    def test_collect_measurements_helper(self):
        sim, profile, target_hash = self._sim_with_target()
        measurements = collect_measurements(list(sim.observations()), target_hash)
        assert set(measurements) == {"n1", "n2", "n3", "n4"}


class TestHotCold:
    def test_score_mapping(self):
        assert score_from_rssi(-40.0) == 100.0
        assert score_from_rssi(-35.0) == 100.0
        assert score_from_rssi(-85.0) == 0.0
        assert score_from_rssi(-95.0) == 0.0
        assert 40 < score_from_rssi(-60.0) < 70

    def test_guide_tracks_rssi_and_blinks_faster_when_closer(self):
        led = FakeLed()
        with HotColdGuide(led) as guide:
            for rssi in (-84, -83, -83, -84):
                guide.update(rssi)
            far_score = guide.score
            time.sleep(0.7)  # let the LED thread blink at the slow rate
            far_transitions = len(led.transitions)
            for rssi in (-42, -41, -43, -42):
                guide.update(rssi)
            near_score = guide.score
            time.sleep(0.7)
            near_transitions = len(led.transitions)
        assert near_score > far_score + 40
        assert near_transitions > far_transitions  # faster blinking when closer
        assert led.closed == 1  # context manager restored the LED

    def test_update_accepts_observations(self):
        guide = HotColdGuide(None)
        obs = Observation.wifi(ts=1.0, node_id="n1", rssi_dbm=-50.0, addr_hash="a" * 16, length=100)
        score = guide.update(obs)
        assert score == score_from_rssi(-50.0)

    def test_median_window_robust_to_fade(self):
        guide = HotColdGuide(None, window_s=10.0)
        for i, rssi in enumerate([-60, -60, -60, -100, -60]):
            guide.update(rssi, ts=float(i))
        # median over the window ignores the single deep fade
        assert guide.score == score_from_rssi(-60.0)

    def test_solid_on_when_very_close(self):
        led = FakeLed()
        with HotColdGuide(led) as guide:
            for rssi in (-38, -37, -39):
                guide.update(rssi)
            assert guide.score >= 80
            time.sleep(0.5)
            assert led.state is True  # solid, not blinking
            toggles = len(led.transitions)
            time.sleep(0.3)
            assert len(led.transitions) == toggles  # no further toggling

    def test_render_callback_invoked(self):
        seen = []
        with HotColdGuide(None, render=seen.append) as guide:
            guide.update(-50.0)
            time.sleep(0.6)
        assert seen and 30 <= seen[-1] <= 100

    def test_console_blink_renders_bar(self, capsys):
        from sentinel_rf.locate.hotcold import console_blink

        console_blink(50.0)
        out = capsys.readouterr().out
        assert "proximity [" in out and "50.0" in out

    def test_led_failure_is_contained(self):
        led = FakeLed()
        led.fail_on_open(True)
        guide = HotColdGuide(led)
        guide.start()
        guide.stop()  # must not raise despite the failing LED
        assert guide._thread is None
