"""Transport tests: SQLite store, MQTT message formats + mesh merge, ThingSpeak."""

import json
import time

import pytest

from sentinel_rf.config import MqttConfig
from sentinel_rf.crypto import mac_hash
from sentinel_rf.parse.observation import Observation
from sentinel_rf.privacy import PrivacyViolation
from sentinel_rf.sim.generator import RfSimulator
from sentinel_rf.transport.mqtt import (
    MeshCollector,
    MqttError,
    MqttTransport,
    decode_node_message,
    devices_topic,
    encode_node_message,
)
from sentinel_rf.transport.store import SqliteStore
from sentinel_rf.transport.thingspeak import ThingSpeakPublisher

SALT = b"0123456789abcdef"


def sample_obs(ts=100.0, hash_="a" * 16, rssi=-55.0, name=None, ble=False):
    if ble:
        return Observation.ble(ts=ts, node_id="n1", rssi_dbm=rssi, addr_hash=hash_, name=name)
    return Observation.wifi(
        ts=ts,
        node_id="n1",
        rssi_dbm=rssi,
        addr_hash=hash_,
        length=900,
        channel=6,
        role="sta",
        frame_type=2,
        frame_subtype=8,
        to_ds=True,
    )


class TestSqliteStore:
    def test_schema_and_roundtrip(self, tmp_path):
        store = SqliteStore(tmp_path / "s.sqlite3", batch_size=5)
        for i in range(12):
            store.add_observation(sample_obs(ts=100.0 + i))
        store.flush()
        rows = store.observations(limit=20)
        assert len(rows) == 12
        assert rows[-1]["ts"] == 100.0  # DESC order
        assert rows[-1]["addr_hash"] == "a" * 16
        assert set(rows[0]) >= {"ts", "source", "node_id", "rssi", "addr_hash", "length"}
        store.close()

    def test_batching_spares_disk(self, tmp_path):
        store = SqliteStore(tmp_path / "s.sqlite3", batch_size=100)
        for i in range(50):
            store.add_observation(sample_obs(ts=i))
        # buffered below the batch threshold: nothing written yet
        assert len(store._buffer) == 50
        with store._lock:  # a raw read must not trigger the flush
            raw = store._db.execute("SELECT COUNT(*) FROM observations").fetchone()[0]
        assert raw == 0
        store.flush()
        assert store.counts()["observations"] == 50
        store.close()

    def test_autoflush_at_batch_threshold(self, tmp_path):
        store = SqliteStore(tmp_path / "s.sqlite3", batch_size=10)
        for i in range(25):
            store.add_observation(sample_obs(ts=i))
        # 25 inserts -> two full batches (20 rows) committed automatically,
        # 5 still buffered (checked without triggering counts()' flush)
        with store._lock:
            committed = store._db.execute("SELECT COUNT(*) FROM observations").fetchone()[0]
        assert committed == 20
        assert len(store._buffer) == 5
        store.close()

    def test_raw_mac_never_reaches_database_file(self, tmp_path):
        """The Phase-6 acceptance test: raw bytes must not appear in the DB file."""
        raw = "24:0a:c4:aa:bb:cc"
        path = tmp_path / "s.sqlite3"
        store = SqliteStore(path)
        obs = Observation.wifi(
            ts=1.0,
            node_id="n1",
            rssi_dbm=-55.0,
            addr_hash=mac_hash(raw, SALT),
            length=100,
            raw_addr=raw,
        )
        store.add_observation(obs)  # to_dict drops raw_addr silently
        store.flush()
        store.close()
        blob = path.read_bytes()
        assert raw.encode() not in blob
        assert raw.replace(":", "").encode() not in blob

    def test_privacy_boundary_raises(self, tmp_path):
        store = SqliteStore(tmp_path / "s.sqlite3")
        with pytest.raises(PrivacyViolation):
            store.add_payload({"mac": "24:0a:c4:aa:bb:cc"})
        with pytest.raises(PrivacyViolation):
            store.add_event("bad", {"note": "saw 24:0a:c4:aa:bb:cc nearby"})
        store.close()

    def test_devices_alerts_events(self, tmp_path):
        store = SqliteStore(tmp_path / "s.sqlite3")
        store.upsert_device(
            "a" * 16,
            first_ts=1.0,
            last_ts=2.0,
            n_frames=10,
            role="sta",
            last_score=72.5,
            last_verdict="likely",
        )
        store.add_alert(
            {
                "ts": 2.0,
                "addr_hash": "a" * 16,
                "score": 72.5,
                "band": "likely",
                "reasons": ["r1", "r2"],
                "components": {},
            }
        )
        store.add_event("stimulus", {"action": "mark_on"})
        devices = store.devices()
        assert devices[0]["addr_hash"] == "a" * 16
        assert devices[0]["last_score"] == 72.5
        alerts = store.alerts()
        assert alerts[0]["reasons"] == ["r1", "r2"]
        assert store.events()[0]["kind"] == "stimulus"
        assert store.counts()["alerts"] == 1
        store.close()

    def test_query_by_hash_and_since(self, tmp_path):
        store = SqliteStore(tmp_path / "s.sqlite3")
        store.add_observation(sample_obs(ts=1.0, hash_="a" * 16))
        store.add_observation(sample_obs(ts=2.0, hash_="b" * 16))
        store.flush()
        only_a = store.observations(addr_hash="a" * 16)
        assert len(only_a) == 1 and only_a[0]["addr_hash"] == "a" * 16
        assert store.alerts(since=100.0) == []
        store.close()

    def test_retention_purge(self, tmp_path):
        store = SqliteStore(tmp_path / "s.sqlite3")
        old_ts = time.time() - 10 * 86400
        store.add_observation(sample_obs(ts=old_ts))
        store.add_observation(sample_obs(ts=time.time()))
        store.flush()
        removed = store.purge_older_than(days=7)
        assert removed == 1
        assert store.counts()["observations"] == 1
        store.close()

    def test_memory_db_and_context_manager(self):
        with SqliteStore(":memory:") as store:
            store.add_observation(sample_obs())
            store.flush()
            assert len(store) == 1

    def test_thread_safety(self, tmp_path):
        import threading

        store = SqliteStore(tmp_path / "s.sqlite3", batch_size=10)

        def writer(n):
            for i in range(40):
                store.add_observation(sample_obs(ts=n * 100 + i))

        threads = [threading.Thread(target=writer, args=(n,)) for n in range(4)]
        for t in threads:
            t.start()
        for t in threads:
            t.join()
        store.flush()
        assert store.counts()["observations"] == 160
        store.close()


class TestMqttMessages:
    def test_topic_scheme(self):
        config = MqttConfig(site="lab", node_id="node-1")
        assert devices_topic(config, "node-1") == "sentinel/lab/node-1/devices"
        assert devices_topic(config) == "sentinel/lab/+/devices"
        assert devices_topic(config, "node-2") == "sentinel/lab/node-2/devices"

    def test_encode_decode_roundtrip(self):
        message = {
            "node_id": "node-1",
            "ts": 123.0,
            "devices": [{"addr_hash": "a" * 16, "rssi_median": -55.0, "score": 61.0}],
        }
        text = encode_node_message(message)
        assert "addr_hash" in text
        assert decode_node_message(text) == message

    def test_encode_refuses_raw_macs(self):
        with pytest.raises(PrivacyViolation):
            encode_node_message({"node_id": "n", "mac": "24:0a:c4:aa:bb:cc"})
        with pytest.raises(PrivacyViolation):
            encode_node_message({"node_id": "n", "note": "device 24:0a:c4:aa:bb:cc seen"})

    def test_decode_rejects_malformed(self):
        with pytest.raises(ValueError):
            decode_node_message("not json")
        with pytest.raises(ValueError):
            decode_node_message(json.dumps([1, 2]))
        with pytest.raises(ValueError):
            decode_node_message(json.dumps({"node_id": "n"}))

    def test_transport_without_paho_reports_cleanly(self, monkeypatch):
        import builtins

        real_import = builtins.__import__

        def no_paho(name, *args, **kwargs):
            if name.startswith("paho"):
                raise ImportError("paho disabled for test")
            return real_import(name, *args, **kwargs)

        monkeypatch.setattr(builtins, "__import__", no_paho)
        transport = MqttTransport(MqttConfig())
        with pytest.raises(MqttError, match="paho-mqtt"):
            transport.connect()
        assert transport.publish_devices({"node_id": "n", "devices": []}) is False

    def test_publish_requires_connection(self):
        transport = MqttTransport(MqttConfig())
        assert transport.publish_devices({"node_id": "n", "devices": []}) is False


class TestMeshCollector:
    def test_merge_two_nodes(self):
        collector = MeshCollector()
        collector.ingest(
            {
                "node_id": "node-1",
                "ts": time.time(),
                "devices": [{"addr_hash": "a" * 16, "rssi_median": -50.0, "score": 61.0}],
            }
        )
        # one node alone is not enough for multilateration
        assert collector.measurement_sets() == {}
        collector.ingest(
            {
                "node_id": "node-2",
                "ts": time.time(),
                "devices": [{"addr_hash": "a" * 16, "rssi_median": -60.0, "score": 58.0}],
            }
        )
        sets = collector.measurement_sets()
        assert sets == {"a" * 16: {"node-1": -50.0, "node-2": -60.0}}

    def test_stale_entries_evicted(self):
        collector = MeshCollector(max_age_s=0.05)
        collector.ingest(
            {
                "node_id": "node-1",
                "ts": time.time() - 10,
                "devices": [{"addr_hash": "a" * 16, "rssi_median": -50.0}],
            }
        )
        collector.ingest(
            {
                "node_id": "node-2",
                "ts": time.time(),
                "devices": [{"addr_hash": "a" * 16, "rssi_median": -60.0}],
            }
        )
        # node-1's entry is too old: only node-2 remains -> no measurement set
        assert collector.measurement_sets() == {}

    def test_device_summaries(self):
        collector = MeshCollector()
        collector.ingest(
            {
                "node_id": "n1",
                "ts": time.time(),
                "devices": [{"addr_hash": "a" * 16, "rssi_median": -50.0, "score": 61.0}],
            }
        )
        collector.ingest(
            {
                "node_id": "n2",
                "ts": time.time(),
                "devices": [{"addr_hash": "a" * 16, "rssi_median": -60.0, "score": 58.0}],
            }
        )
        summaries = collector.device_summaries()
        assert summaries[0]["nodes"] == 2
        assert summaries[0]["best_score"] == 61.0

    def test_mesh_feeds_grid_locator(self):
        import math

        from sentinel_rf.locate.anchors import Anchor, AnchorSet, RoomProfile
        from sentinel_rf.locate.grid import GridLocator
        from sentinel_rf.locate.pathloss import PathLossModel

        profile = RoomProfile(
            width_m=5.0,
            height_m=4.0,
            pathloss=PathLossModel(p0_dbm=-40.0, n=2.5),
            anchors=AnchorSet.from_list(
                [
                    Anchor("n1", 0.3, 0.3),
                    Anchor("n2", 4.7, 0.3),
                    Anchor("n3", 0.3, 3.7),
                    Anchor("n4", 4.7, 3.7),
                ]
            ),
        )
        truth = (2.5, 2.0)
        collector = MeshCollector()
        now = time.time()
        for anchor in profile.anchors:
            d = anchor.distance_to(*truth)
            rssi = profile.pathloss.p0_dbm - 10 * profile.pathloss.n * math.log10(d)
            collector.ingest(
                {
                    "node_id": anchor.node_id,
                    "ts": now,
                    "devices": [{"addr_hash": "a" * 16, "rssi_median": rssi}],
                }
            )
        locator = GridLocator(profile, grid_resolution_m=0.25)
        estimate = locator.estimate(collector.measurement_sets()["a" * 16])
        assert estimate.x == pytest.approx(2.5, abs=0.2)
        assert estimate.y == pytest.approx(2.0, abs=0.2)


class TestThingSpeak:
    def test_disabled_without_key(self, monkeypatch):
        monkeypatch.delenv("SENTINEL_THINGSPEAK_KEY", raising=False)
        publisher = ThingSpeakPublisher()
        assert publisher.enabled is False
        assert publisher.send({"field1": 42}) is False
        assert publisher.stats["skipped"] == 1

    def test_field_validation(self):
        publisher = ThingSpeakPublisher()
        assert publisher.build_payload({"field1": 5, "field2": "abc"}) == {
            "field1": "5",
            "field2": "abc",
        }
        with pytest.raises(ValueError, match="field1"):
            publisher.build_payload({"fieldX": 1})

    def test_none_fields_skipped(self):
        publisher = ThingSpeakPublisher()
        assert publisher.build_payload({"field1": None, "field2": 7}) == {"field2": "7"}

    def test_send_failure_contained(self, monkeypatch):
        monkeypatch.setenv("SENTINEL_THINGSPEAK_KEY", "TESTKEY123")

        class Boom:
            def urlopen(self, *a, **k):
                raise OSError("network down")

        publisher = ThingSpeakPublisher()
        monkeypatch.setattr(
            "sentinel_rf.transport.thingspeak.urllib.request.urlopen",
            lambda *a, **k: (_ for _ in ()).throw(OSError("network down")),
        )
        assert publisher.send({"field1": 1}) is False
        assert publisher.stats["errors"] == 1


class TestSimToStorePipeline:
    def test_full_sim_persists_privately(self, tmp_path):
        sim = RfSimulator(seed=9, duration_s=10.0, salt=SALT)
        store = SqliteStore(tmp_path / "sim.sqlite3", batch_size=64)
        for obs in sim.observations():
            store.add_observation(obs)
        store.flush()
        counts = store.counts()
        assert counts["observations"] > 500
        # every stored row uses hashes; no raw macs anywhere in the file
        for row in store.observations(limit=1000):
            assert len(row["addr_hash"]) == 16
        blob = (tmp_path / "sim.sqlite3").read_bytes()
        for device in sim.devices:
            assert device.mac.encode() not in blob
        store.close()
