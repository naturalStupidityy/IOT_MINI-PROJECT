"""Unit tests for the Observation data model."""

import dataclasses
import json

import pytest

from sentinel_rf.crypto import mac_hash
from sentinel_rf.parse.observation import (
    OBSERVATION_SCHEMA_VERSION,
    Observation,
    Role,
    Source,
)
from sentinel_rf.privacy import PrivacyViolation


def make_wifi(**overrides):
    base = dict(
        ts=100.0,
        node_id="node-1",
        rssi_dbm=-55.0,
        addr_hash="ab12cd34ef56ab12",
        length=1123,
        channel=6,
        freq_mhz=2437.0,
        bssid_hash="0011223344556677",
        addr_is_random=False,
        role="sta",
        frame_type=2,
        frame_subtype=0,
        to_ds=True,
        from_ds=False,
        retry=False,
        rate_mbps=65.0,
    )
    base.update(overrides)
    return Observation.wifi(**base)


def test_defaults_and_enums():
    obs = make_wifi()
    assert obs.source is Source.WIFI
    assert obs.role is Role.STA
    assert obs.addr_is_random is False
    assert obs.raw_addr is None


def test_source_and_role_coercion_from_str():
    obs = Observation(
        ts=1.0, source="wifi", node_id="n", rssi_dbm=-60.0, addr_hash="ff" * 8, length=100
    )
    assert obs.source is Source.WIFI
    obs2 = Observation(
        ts=1.0,
        source="ble",
        node_id="n",
        rssi_dbm=-60.0,
        addr_hash="ff" * 8,
        length=0,
        role="unknown",
    )
    assert obs2.source is Source.BLE
    assert obs2.role is Role.UNKNOWN


def test_frozen():
    obs = make_wifi()
    with pytest.raises(dataclasses.FrozenInstanceError):
        obs.ts = 5.0


def test_to_dict_from_dict_roundtrip():
    obs = make_wifi()
    d = obs.to_dict()
    assert d["schema_version"] == OBSERVATION_SCHEMA_VERSION
    assert Observation.from_dict(d) == obs


def test_ble_roundtrip():
    obs = Observation.ble(
        ts=3.0,
        node_id="n",
        rssi_dbm=-75.0,
        addr_hash="ab" * 8,
        adv_type="adv_ind",
        tx_power=-4.0,
        name="Cam-Setup",
        service_uuids=["180f", "180a"],
        company_id=6,
        channel=39,
        freq_mhz=2480.0,
    )
    d = obs.to_dict()
    assert d["source"] == "ble"
    assert d["service_uuids"] == ["180f", "180a"]
    rt = Observation.from_dict(d)
    assert rt == obs
    assert rt.service_uuids == ("180f", "180a")


def test_to_dict_excludes_raw_addr():
    obs = make_wifi(raw_addr="AA:BB:CC:DD:EE:FF")
    d = obs.to_dict()
    assert "raw_addr" not in d
    blob = json.dumps(d).lower()
    assert "aa:bb:cc:dd:ee:ff" not in blob
    assert Observation.from_dict(d) == obs.redact()


def test_from_dict_refuses_raw_addr():
    d = make_wifi().to_dict()
    d["raw_addr"] = "AA:BB:CC:DD:EE:FF"
    with pytest.raises(PrivacyViolation):
        Observation.from_dict(d)


def test_from_dict_accepts_none_raw_addr():
    d = make_wifi().to_dict()
    d["raw_addr"] = None
    assert Observation.from_dict(d) == make_wifi()


def test_from_dict_rejects_bad_version():
    d = make_wifi().to_dict()
    d["schema_version"] = 99
    with pytest.raises(ValueError, match="schema_version"):
        Observation.from_dict(d)


def test_from_dict_rejects_unknown_field():
    d = make_wifi().to_dict()
    d["bogus"] = 1
    with pytest.raises(ValueError, match="bogus"):
        Observation.from_dict(d)


def test_from_dict_rejects_non_mapping():
    with pytest.raises(TypeError):
        Observation.from_dict([("ts", 1.0)])


@pytest.mark.parametrize(
    "field,value",
    [
        ("rssi_dbm", 50.0),
        ("rssi_dbm", -200.0),
        ("length", -1),
        ("length", 70000),
        ("frame_type", 9),
        ("frame_subtype", 16),
        ("channel", 300),
        ("node_id", ""),
        ("addr_hash", "aa:bb:cc:dd:ee:ff"),
        ("addr_hash", "zz12"),
        ("raw_addr", "not-a-mac"),
        ("rate_mbps", 99999.0),
    ],
)
def test_validation_rejects(field, value):
    with pytest.raises(ValueError):
        make_wifi(**{field: value})


def test_wifi_rejects_ble_fields():
    with pytest.raises(ValueError, match="BLE-only"):
        Observation(
            ts=1.0,
            source="wifi",
            node_id="n",
            rssi_dbm=-60.0,
            addr_hash="ab" * 8,
            length=100,
            name="Cam",
        )
    with pytest.raises(ValueError, match="BLE-only"):
        Observation(
            ts=1.0,
            source=Source.WIFI,
            node_id="n",
            rssi_dbm=-60.0,
            addr_hash="ab" * 8,
            length=100,
            service_uuids=["180f"],
        )


def test_ble_rejects_wifi_fields():
    with pytest.raises(ValueError, match="Wi-Fi frame"):
        Observation(
            ts=1.0,
            source="ble",
            node_id="n",
            rssi_dbm=-60.0,
            addr_hash="ab" * 8,
            length=0,
            to_ds=True,
        )
    with pytest.raises(ValueError, match="Wi-Fi frame"):
        Observation(
            ts=1.0,
            source=Source.BLE,
            node_id="n",
            rssi_dbm=-60.0,
            addr_hash="ab" * 8,
            length=0,
            bssid_hash="cd" * 8,
        )


def test_service_uuids_coerced_to_tuple():
    obs = Observation.ble(
        ts=1.0, node_id="n", rssi_dbm=-60.0, addr_hash="ab" * 8, service_uuids=["180f"]
    )
    assert obs.service_uuids == ("180f",)
    with pytest.raises(ValueError):
        Observation.ble(
            ts=1.0, node_id="n", rssi_dbm=-60.0, addr_hash="ab" * 8, service_uuids=["x" * 40]
        )


def test_redact():
    obs = make_wifi(raw_addr="AA:BB:CC:DD:EE:FF")
    red = obs.redact()
    assert red.raw_addr is None
    assert red.addr_hash == obs.addr_hash
    assert red == make_wifi()
    assert obs.raw_addr == "AA:BB:CC:DD:EE:FF"  # original untouched


def test_hashed_addresses_are_usable(salt):
    obs = make_wifi(
        addr_hash=mac_hash("AA:BB:CC:DD:EE:FF", salt),
        bssid_hash=mac_hash("00:11:22:33:44:55", salt),
        raw_addr="AA:BB:CC:DD:EE:FF",
    )
    assert obs.addr_hash != obs.bssid_hash
    assert ":" not in obs.addr_hash
