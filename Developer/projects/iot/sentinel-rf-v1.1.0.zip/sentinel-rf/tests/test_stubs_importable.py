"""Import smoke tests: the full planned package layout exists and imports."""

import importlib
import pkgutil
import re

import sentinel_rf


def iter_modules():
    return list(pkgutil.walk_packages(sentinel_rf.__path__, prefix="sentinel_rf."))


def test_all_modules_import():
    mods = iter_modules()
    assert len(mods) > 15  # sanity: the full planned layout exists
    for info in mods:
        importlib.import_module(info.name)


def test_all_modules_have_docstrings():
    for info in iter_modules():
        mod = importlib.import_module(info.name)
        assert mod.__doc__ and mod.__doc__.strip(), f"{info.name} is missing a docstring"


def test_version_is_semver():
    assert re.fullmatch(r"\d+\.\d+\.\d+", sentinel_rf.__version__)
