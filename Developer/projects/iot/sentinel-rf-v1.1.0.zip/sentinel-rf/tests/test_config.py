"""Configuration loader tests: defaults, validation, resolution order."""

from pathlib import Path

import pytest

from sentinel_rf.config import ConfigError, load_config
from sentinel_rf.defaults import default_config

REPO = Path(__file__).resolve().parents[1]
DEFAULT_YAML = REPO / "configs" / "default.yaml"


def write_yaml(tmp_path, text, name="config.yaml"):
    path = tmp_path / name
    path.write_text(text, encoding="utf-8")
    return path


def test_default_yaml_loads_with_expected_snapshot():
    cfg = load_config(DEFAULT_YAML)
    assert cfg.schema_version == 1
    assert cfg.capture.snaplen == 128
    assert cfg.capture.iface == "mon0"
    assert cfg.capture.channel_plan.channels_2g[:3] == (1, 6, 11)
    assert cfg.capture.channel_plan.bands == ("2g",)
    assert cfg.privacy.allow_raw_mac_live is False
    assert cfg.privacy.hash_truncate == 16
    weights = cfg.detect.fusion.weights
    assert (weights.priors, weights.traffic, weights.stimulus, weights.ble) == (
        15.0,
        35.0,
        40.0,
        10.0,
    )
    assert weights.priors + weights.traffic + weights.stimulus + weights.ble == 100.0
    assert cfg.detect.fusion.bands.likely_above == 60.0
    assert cfg.locate.grid_resolution_m == 0.25
    assert cfg.store.retention_days == 7
    assert cfg.mqtt.enabled is False
    assert cfg.logging.level == "INFO"


def test_defaults_match_yaml_no_drift():
    assert load_config(DEFAULT_YAML) == default_config()


def test_load_from_explicit_path_beats_env(tmp_path, monkeypatch):
    explicit = write_yaml(tmp_path, "schema_version: 1\ncapture:\n  snaplen: 96\n", "explicit.yaml")
    env_file = write_yaml(tmp_path, "schema_version: 1\ncapture:\n  snaplen: 200\n", "env.yaml")
    monkeypatch.setenv("SENTINEL_RF_CONFIG", str(env_file))
    assert load_config(explicit).capture.snaplen == 96


def test_load_from_env_var(tmp_path, monkeypatch):
    env_file = write_yaml(tmp_path, "schema_version: 1\ncapture:\n  snaplen: 200\n")
    monkeypatch.setenv("SENTINEL_RF_CONFIG", str(env_file))
    assert load_config().capture.snaplen == 200


def test_load_falls_back_to_builtin_defaults(tmp_path, monkeypatch):
    monkeypatch.delenv("SENTINEL_RF_CONFIG", raising=False)
    monkeypatch.chdir(tmp_path)  # no ./configs/default.yaml here
    assert load_config() == default_config()


def test_missing_file_is_a_clear_error(tmp_path):
    with pytest.raises(ConfigError, match="not found"):
        load_config(tmp_path / "nope.yaml")


def test_unknown_key_rejected(tmp_path):
    path = write_yaml(tmp_path, "schema_version: 1\nprivacy:\n  alow_raw_mac_live: true\n")
    with pytest.raises(ConfigError) as excinfo:
        load_config(path)
    msg = str(excinfo.value)
    assert "alow_raw_mac_live" in msg
    assert "privacy" in msg


def test_unknown_root_key_rejected(tmp_path):
    path = write_yaml(tmp_path, "schema_version: 1\nbogus_section: {}\n")
    with pytest.raises(ConfigError, match="bogus_section"):
        load_config(path)


def test_snaplen_hard_bounded(tmp_path):
    path = write_yaml(tmp_path, "schema_version: 1\ncapture:\n  snaplen: 4096\n")
    with pytest.raises(ConfigError) as excinfo:
        load_config(path)
    msg = str(excinfo.value)
    assert "snaplen" in msg
    assert "256" in msg
    assert "HARD RULE 2" in msg


def test_bad_type_rejected_with_key_path(tmp_path):
    path = write_yaml(
        tmp_path, "schema_version: 1\ncapture:\n  channel_plan:\n    dwell_ms: fast\n"
    )
    with pytest.raises(ConfigError) as excinfo:
        load_config(path)
    msg = str(excinfo.value)
    assert "dwell_ms" in msg
    assert "channel_plan" in msg


def test_hash_truncate_floor(tmp_path):
    path = write_yaml(tmp_path, "schema_version: 1\nprivacy:\n  hash_truncate: 12\n")
    with pytest.raises(ConfigError, match="hash_truncate"):
        load_config(path)


def test_invalid_band_rejected(tmp_path):
    path = write_yaml(tmp_path, 'schema_version: 1\ncapture:\n  channel_plan:\n    bands: ["6g"]\n')
    with pytest.raises(ConfigError, match="6g"):
        load_config(path)


def test_window_ordering_enforced(tmp_path):
    path = write_yaml(
        tmp_path, "schema_version: 1\nwindows:\n  short_s: 100\n  medium_s: 10\n  long_s: 60\n"
    )
    with pytest.raises(ConfigError, match="short_s"):
        load_config(path)


def test_section_must_be_mapping(tmp_path):
    path = write_yaml(tmp_path, "schema_version: 1\nprivacy: [1, 2]\n")
    with pytest.raises(ConfigError, match="mapping"):
        load_config(path)


def test_root_must_be_mapping(tmp_path):
    path = write_yaml(tmp_path, "42\n")
    with pytest.raises(ConfigError, match="top level must be a mapping"):
        load_config(path)


def test_bad_schema_version(tmp_path):
    path = write_yaml(tmp_path, "schema_version: 2\n")
    with pytest.raises(ConfigError, match="schema_version"):
        load_config(path)


def test_invalid_yaml(tmp_path):
    path = write_yaml(tmp_path, "privacy: [unclosed\n")
    with pytest.raises(ConfigError, match="invalid YAML"):
        load_config(path)
