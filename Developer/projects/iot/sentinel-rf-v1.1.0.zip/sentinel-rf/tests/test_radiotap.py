"""Radiotap parser unit tests (hand-made fixtures)."""

import struct

import pytest

from sentinel_rf.parse.radiotap import (
    RadiotapError,
    RadiotapMeta,
    freq_to_channel,
    parse_radiotap,
)


def header(presence_bits, body: bytes, version: int = 0, it_len: int = None) -> bytes:
    """Assemble a radiotap header; body must already include padding."""
    presence = 0
    for bit in presence_bits:
        presence |= 1 << bit
    total = 8 + len(body)
    if it_len is None:
        it_len = total
    return struct.pack("<BBHI", version, 0, it_len, presence) + body


class TestParseRadiotap:
    def test_rate_channel_signal(self):
        # fields in bit order: RATE(1B@8), pad(1), CHANNEL(4B aligned@10), SIGNAL(1B@14)
        body = bytes([12]) + b"\x00" + struct.pack("<HH", 2437, 0x00A0) + struct.pack("<b", -55)
        meta, rest = parse_radiotap(header([2, 3, 5], body))
        assert meta.rate_mbps == 6.0  # 12 * 0.5
        assert meta.freq_mhz == 2437
        assert meta.rssi_dbm == -55.0
        assert meta.channel == 6
        assert meta.header_len == 8 + len(body)
        assert rest == b""

    def test_tsft_alignment_pads(self):
        # TSFT(8B, align 8) starts at offset 8 (already aligned), SIGNAL at 16
        body = struct.pack("<Q", 123456) + struct.pack("<b", -42)
        meta, _ = parse_radiotap(header([0, 5], body))
        assert meta.tsft_us == 123456
        assert meta.rssi_dbm == -42.0

    def test_extended_presence_word_consumed(self):
        # bit31 of word0 set -> one extra presence word before the fields.
        word0 = (1 << 2) | (1 << 31)  # RATE present + extension
        word1 = 1 << 26  # MCS in the extension word (unknown to us)
        body = bytes([24])
        data = struct.pack("<BBHI", 0, 0, 12 + len(body), word0) + struct.pack("<I", word1) + body
        meta, rest = parse_radiotap(data)
        assert meta.rate_mbps == 12.0
        assert rest == b""

    def test_unknown_higher_fields_do_not_break_low_fields(self):
        # presence with bits 2,3,5 plus MCS (26): fields for 0..14 come first.
        presence = (1 << 2) | (1 << 3) | (1 << 5) | (1 << 26)
        body = (
            bytes([12])
            + b"\x00"
            + struct.pack("<HH", 2412, 0)
            + struct.pack("<b", -60)
            + b"\x01\x02\x03"
        )
        data = struct.pack("<BBHI", 0, 0, 8 + len(body), presence) + body
        meta, _ = parse_radiotap(data)
        assert meta.freq_mhz == 2412
        assert meta.channel == 1

    def test_antenna_and_missing_fields(self):
        body = bytes([2])
        meta, _ = parse_radiotap(header([11], body))
        assert meta.antenna == 2
        assert meta.rssi_dbm is None
        assert meta.freq_mhz is None
        assert meta.channel is None

    def test_version_nonzero_raises(self):
        with pytest.raises(RadiotapError, match="version"):
            parse_radiotap(header([2], bytes([12]), version=1))

    def test_truncated_buffer_raises(self):
        with pytest.raises(RadiotapError, match="truncated"):
            parse_radiotap(b"\x00\x00")

    def test_length_field_larger_than_buffer_raises(self):
        body = bytes([12])
        with pytest.raises(RadiotapError, match="it_len"):
            parse_radiotap(header([2], body, it_len=999))

    def test_field_overrun_raises(self):
        # claim CHANNEL (4 bytes) but provide only 1 byte of body
        with pytest.raises(RadiotapError, match="overruns"):
            parse_radiotap(header([3], b"\x01"))

    def test_frame_bytes_after_header_returned(self):
        body = struct.pack("<b", -55)
        tail = b"\x80\x00\x00\x00" + b"\xff" * 6
        data = header([5], body) + tail
        meta, rest = parse_radiotap(data)
        assert meta.rssi_dbm == -55.0
        assert rest == tail


class TestFreqToChannel:
    @pytest.mark.parametrize(
        "freq,expected",
        [
            (2412, 1),
            (2437, 6),
            (2472, 13),
            (2484, 14),
            (2422, 3),
            (5180, 36),
            (5745, 149),
            (5885, 177),
            (2400, None),
            (None, None),
        ],
    )
    def test_mapping(self, freq, expected):
        assert freq_to_channel(freq) == expected


def test_meta_defaults():
    meta = RadiotapMeta()
    assert meta.header_len == 0
    assert meta.channel is None
