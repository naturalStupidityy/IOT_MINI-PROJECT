"""Capture backends + manager tests (all software paths; no hardware)."""

import queue
import threading
import time

import pytest

from sentinel_rf.capture.ble_scanner import FakeBleScanner
from sentinel_rf.capture.channel_hopper import (
    FakeChannelHopper,
    IwChannelHopper,
    LockChannel,
    ensure_monitor_interface,
    iw_set_channel,
)
from sentinel_rf.capture.fakes import FakeWifiMonitor
from sentinel_rf.capture.manager import CaptureManager
from sentinel_rf.capture.pcap_replay import ReplayWifiSource
from sentinel_rf.capture.wifi_monitor import (
    IteratorWifiSource,
    NullWifiMonitor,
    TcpdumpWifiMonitor,
)
from sentinel_rf.parse.observation import Observation, Source
from sentinel_rf.sim.generator import RfSimulator


@pytest.fixture()
def sim_observations(salt):
    sim = RfSimulator(seed=21, duration_s=6.0, salt=salt)
    return list(sim.observations())


class TestFakeWifiMonitor:
    def test_emits_script_then_finishes(self, sim_observations):
        q: "queue.Queue" = queue.Queue(maxsize=100_000)
        mon = FakeWifiMonitor(q, observations=sim_observations, node_id="n1")
        mon.start()
        assert mon.finished.wait(10), "fake monitor did not finish its script"
        mon.stop(timeout=5)
        drained = list(q.queue)
        assert len(drained) == len(sim_observations)
        assert all(isinstance(o, Observation) for o in drained)
        assert mon.counters.snapshot()["emitted"] == len(sim_observations)

    def test_stop_mid_stream(self, sim_observations):
        q: "queue.Queue" = queue.Queue(maxsize=10)
        mon = FakeWifiMonitor(q, observations=sim_observations, node_id="n1", idle_s=30)
        mon.start()
        time.sleep(0.05)
        mon.stop(timeout=5)
        assert not mon.running
        assert mon.counters.snapshot()["emitted"] <= len(sim_observations)

    def test_drop_accounting_when_queue_full(self):
        q: "queue.Queue" = queue.Queue(maxsize=2)
        obs = RfSimulator(seed=1, duration_s=4.0, salt=b"0123456789abcdef").observations()
        mon = FakeWifiMonitor(q, observations=obs, node_id="n1")
        mon.start()
        mon.stop(timeout=5)
        stats = mon.counters.snapshot()
        assert stats["dropped"] > 0
        assert stats["emitted"] == 2  # queue capacity only


class TestIteratorSource:
    def test_fast_replay(self, sim_observations):
        q: "queue.Queue" = queue.Queue(maxsize=100_000)
        src = IteratorWifiSource(
            q, observations_factory=lambda: sim_observations, node_id="n1", speed=0.0
        )
        src.start()
        assert src.finished.wait(15), "source did not finish"
        src.stop(timeout=10)
        assert src.counters.snapshot()["emitted"] == len(sim_observations)

    def test_realtime_pacing_slows_stream(self, sim_observations):
        q: "queue.Queue" = queue.Queue(maxsize=100_000)
        paced = sim_observations[:: max(1, len(sim_observations) // 40)]  # spans the sim window
        src = IteratorWifiSource(q, observations_factory=lambda: paced, node_id="n1", speed=1.0)
        t0 = time.monotonic()
        src.start()
        assert src.finished.wait(30), "paced source did not finish"
        src.stop(timeout=30)
        elapsed = time.monotonic() - t0
        # 50 observations over ~6 simulated seconds -> at least 3s wall time
        assert elapsed >= 3.0

    def test_null_monitor(self):
        q: "queue.Queue" = queue.Queue(maxsize=10)
        mon = NullWifiMonitor(q, node_id="n1")
        mon.start()
        time.sleep(0.05)
        assert mon.running
        mon.stop()
        assert not mon.running


class TestTcpdumpMonitor:
    def test_drain_pcap_stream(self, salt, tmp_path):
        """The pcap-stream parsing core of the tcpdump backend (no hardware)."""
        from sentinel_rf.parse.pcap import PcapReader, write_observations_pcap

        sim = RfSimulator(seed=21, duration_s=6.0, salt=salt, allow_raw=True)
        sim_observations = list(sim.observations())
        path = tmp_path / "sim.pcap"
        write_observations_pcap(path, sim_observations, snaplen=128)
        q: "queue.Queue" = queue.Queue(maxsize=100_000)
        mon = TcpdumpWifiMonitor(q, iface="mon0", snaplen=128, node_id="n1", salt=salt)
        with open(path, "rb") as fh:
            mon._drain_pcap_stream(PcapReader(fh), salt=salt, truncate=16, allow_raw=False)
        stats = mon.counters.snapshot()
        assert stats["emitted"] > 100
        assert stats["parse_errors"] == 0

    def test_missing_binary_reported_not_raised(self):
        q: "queue.Queue" = queue.Queue(maxsize=10)
        mon = TcpdumpWifiMonitor(
            q,
            iface="mon0",
            snaplen=128,
            node_id="n1",
            salt=b"0123456789abcdef",
            tcpdump_bin="definitely-not-a-real-binary",
        )
        mon.start()
        mon.stop(timeout=5)
        assert mon.counters.snapshot()["errors"]

    def test_snaplen_enforced_in_command(self):
        q: "queue.Queue" = queue.Queue(maxsize=10)
        mon = TcpdumpWifiMonitor(
            q, iface="mon0", snaplen=96, node_id="n1", salt=b"0123456789abcdef"
        )
        # The command is built inside _capture_loop; assert the stored config.
        assert mon.snaplen == 96
        assert mon.iface == "mon0"


class TestChannelHopper:
    def test_fake_hopper_visits_channels(self):
        hopper = FakeChannelHopper([1, 6, 11], dwell_ms=5)
        hopper.start()
        time.sleep(0.2)
        hopper.stop()
        channels = [ch for _, ch in hopper.visited]
        assert len(channels) >= 10
        assert set(channels) == {1, 6, 11}
        # order follows the plan
        assert channels[0] == 1 and channels[1] == 6 and channels[2] == 11

    def test_empty_plan_rejected(self):
        with pytest.raises(ValueError):
            FakeChannelHopper([], dwell_ms=10)

    def test_iw_hopper_records_failures(self):
        hopper = IwChannelHopper([1], dwell_ms=5, iface="mon0", iw_bin="not-a-tool")
        hopper.start()
        time.sleep(0.05)
        hopper.stop()
        assert hopper.errors

    def test_iw_set_channel_missing_binary(self):
        ok, err = iw_set_channel("mon0", 6, iw_bin="not-a-tool")
        assert ok is False and "not found" in err

    def test_lock_channel(self):
        lock = LockChannel(6, iface="mon0", iw_bin="not-a-tool")
        assert lock.start() is False  # iw missing on laptop -> reported, not raised
        assert lock.visited == [(0.0, 6)]
        lock.stop()

    def test_ensure_monitor_interface_missing_tools(self):
        ok, message = ensure_monitor_interface(iw_bin="not-a-tool", ip_bin="not-a-tool")
        assert ok is False
        assert "not found" in message


class TestBleScanner:
    def test_fake_ble_scanner_emits(self, sim_observations):
        ble_obs = [o for o in sim_observations if o.source is Source.BLE][:10]
        q: "queue.Queue" = queue.Queue(maxsize=100)
        scanner = FakeBleScanner(q, node_id="n1", salt=b"0123456789abcdef", scripted=ble_obs)
        scanner.start()
        scanner.stop(timeout=5)
        drained = list(q.queue)
        assert len(drained) == 10
        assert scanner.counters["emitted"] == 10

    def test_observation_from_advert(self):
        q: "queue.Queue" = queue.Queue(maxsize=10)
        scanner = FakeBleScanner(q, node_id="n1", salt=b"0123456789abcdef")
        obs = scanner.observation_from_advert(
            ts=1.0,
            address="24:0A:C4:AA:BB:CC",
            rssi_dbm=-67.5,
            name="IPC-1",
            tx_power=-4.0,
            service_uuids=["180d", "181a"],
            company_id=0x59,
            adv_type="adv_ind",
        )
        assert obs is not None
        assert obs.source is Source.BLE
        assert obs.name == "IPC-1"
        assert obs.tx_power == -4.0
        assert obs.service_uuids == ("180d", "181a")
        assert obs.addr_is_random is False
        assert obs.raw_addr is None

    def test_bad_advert_returns_none(self):
        q: "queue.Queue" = queue.Queue(maxsize=10)
        scanner = FakeBleScanner(q, node_id="n1", salt=b"0123456789abcdef")
        assert scanner.observation_from_advert(ts=1.0, address="not-a-mac", rssi_dbm=-60) is None


class TestCaptureManager:
    def test_end_to_end_drain(self, sim_observations):
        manager = CaptureManager(queue_size=100_000)
        wifi_obs = [o for o in sim_observations if o.source is Source.WIFI]
        ble_obs = [o for o in sim_observations if o.source is Source.BLE]
        manager.wifi = FakeWifiMonitor(manager.queue, observations=wifi_obs, node_id="n1")
        manager.ble = FakeBleScanner(
            manager.queue,
            node_id="n1",
            salt=b"0123456789abcdef",
            scripted=ble_obs,
        )
        manager.hopper = FakeChannelHopper([1, 6], dwell_ms=5)
        manager.start()
        drained = list(manager.observations())
        manager.stop()
        assert len(drained) == len(sim_observations)
        stats = manager.stats()
        assert stats["emitted"] == len(sim_observations)
        assert stats["drop_pct"] == 0.0
        assert stats["hopper"]["visited"] > 0

    def test_stop_terminates_iterator(self, sim_observations):
        manager = CaptureManager(queue_size=100_000)
        manager.wifi = FakeWifiMonitor(
            manager.queue, observations=sim_observations, node_id="n1", idle_s=60
        )
        manager.start()

        got = []

        def consume():
            for obs in manager.observations():
                got.append(obs)
                if len(got) >= 100:
                    manager.stop()

        thread = threading.Thread(target=consume)
        thread.start()
        thread.join(timeout=10)
        assert not thread.is_alive()
        assert len(got) >= 100

    def test_context_manager(self, sim_observations):
        manager = CaptureManager(queue_size=100_000)
        manager.wifi = FakeWifiMonitor(manager.queue, observations=sim_observations, node_id="n1")
        with manager:
            time.sleep(0.1)
        assert manager.stats()["started"] is False


def _make_queue(size):
    return queue.Queue(maxsize=size)


class TestReplaySource:
    def test_replay_via_manager(self, tmp_path, salt):
        from sentinel_rf.parse.pcap import write_observations_pcap

        sim = RfSimulator(seed=21, duration_s=6.0, salt=salt, allow_raw=True)
        sim_observations = list(sim.observations())
        path = tmp_path / "cap.pcap"
        wifi_obs = [o for o in sim_observations if o.source is Source.WIFI]
        write_observations_pcap(path, wifi_obs, snaplen=128)

        manager = CaptureManager(queue_size=100_000)
        counters: dict = {}
        manager.wifi = ReplayWifiSource(
            manager.queue,
            pcaps=[path],
            node_id="replay-1",
            salt=salt,
            counters=counters,
        )
        manager.start()
        drained = list(manager.observations())
        manager.stop()
        assert len(drained) == len(wifi_obs)
        assert counters["parsed"] == len(wifi_obs)
