"""Unit tests for sentinel_rf.crypto: salted MAC hashing."""

import stat

import pytest

from sentinel_rf.crypto import load_or_create_salt, mac_hash, new_salt, normalize_mac


@pytest.mark.parametrize(
    "mac",
    ["AA:BB:CC:DD:EE:FF", "aa-bb-cc-dd-ee-ff", "  Aa:Bb:cC:dD:eE:fF ", "aabbccddeeff"],
)
def test_normalize_mac_variants(mac):
    assert normalize_mac(mac) == "aabbccddeeff"


@pytest.mark.parametrize(
    "bad",
    ["", "aabbccddeef", "aabbccddeefff", "zz:bb:cc:dd:ee:ff", "hello", "aa:bb:cc:dd:ee", 123, None],
)
def test_normalize_mac_rejects(bad):
    with pytest.raises(ValueError):
        normalize_mac(bad)


def test_new_salt_length_and_uniqueness():
    a, b = new_salt(), new_salt()
    assert len(a) == 16
    assert len(b) == 16
    assert a != b


@pytest.mark.parametrize("bad", [4, 0, 7, -8])
def test_new_salt_rejects_short(bad):
    with pytest.raises(ValueError):
        new_salt(bad)


def test_mac_hash_deterministic_and_format_insensitive(salt):
    h1 = mac_hash("AA:BB:CC:DD:EE:FF", salt)
    h2 = mac_hash("aa:bb:cc:dd:ee:ff", salt)
    assert h1 == h2
    assert len(h1) == 16
    assert ":" not in h1 and "-" not in h1
    assert all(c in "0123456789abcdef" for c in h1)


def test_mac_hash_depends_on_salt(salt):
    other = new_salt()
    assert mac_hash("00:11:22:33:44:55", salt) != mac_hash("00:11:22:33:44:55", other)


def test_mac_hash_truncation(salt):
    assert len(mac_hash("00:11:22:33:44:55", salt, truncate=32)) == 32
    assert len(mac_hash("00:11:22:33:44:55", salt, truncate=64)) == 64


@pytest.mark.parametrize("bad", [12, 13, 10, 66, 0, -4])
def test_mac_hash_rejects_bad_truncate(salt, bad):
    with pytest.raises(ValueError):
        mac_hash("00:11:22:33:44:55", salt, truncate=bad)


def test_mac_hash_rejects_bad_salt():
    with pytest.raises(ValueError):
        mac_hash("00:11:22:33:44:55", b"short")


def test_load_or_create_salt_roundtrip(tmp_path):
    path = tmp_path / "session.salt"
    s1 = load_or_create_salt(path)
    assert path.exists()
    assert load_or_create_salt(path) == s1
    assert stat.S_IMODE(path.stat().st_mode) == 0o600


def test_load_or_create_salt_rejects_garbage(tmp_path):
    path = tmp_path / "bad.salt"
    path.write_text("not-hex!", encoding="ascii")
    with pytest.raises(ValueError):
        load_or_create_salt(path)
