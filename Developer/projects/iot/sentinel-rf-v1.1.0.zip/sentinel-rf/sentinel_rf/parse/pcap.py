"""PCAP file reader and headers-only writer (Phase 1, pure stdlib).

Reads classic pcap files (both endiannesses, usec and nsec timestamps) with
LINKTYPE_IEEE802_11_RADIOTAP (105) - exactly what ``tcpdump -i mon0 -s 128
-w ...`` produces on the Pi (UNVERIFIED on hardware until Phase 2 evidence
lands in docs/verification-log.md).

The writer exists so the simulator can emit replayable captures on a laptop
and so the round-trip property (sim -> pcap -> parse -> same headers) is
unit-testable. It writes frames **truncated to the snaplen** with
``orig_len`` carrying the true on-air length - byte-identical semantics to
``tcpdump -s``: payload bytes never reach disk (HARD RULE 2).
"""

from __future__ import annotations

import struct
from pathlib import Path
from typing import BinaryIO, Iterable, Iterator, Optional, Tuple, Union

from sentinel_rf.crypto import mac_hash
from sentinel_rf.parse.dot11 import build_observation
from sentinel_rf.parse.observation import Observation, Role, Source
from sentinel_rf.parse.radiotap import RadiotapError, parse_radiotap

__all__ = ["LINKTYPE_RADIOTAP", "PcapError", "PcapReader", "read_pcap"]

LINKTYPE_RADIOTAP = 105
_USEC_LE = b"\xd4\xc3\xb2\xa1"
_USEC_BE = b"\xa1\xb2\xc3\xd4"
_NSEC_LE = b"\x4d\x3c\xb2\xa1"
_NSEC_BE = b"\xa1\xb2\x3c\x4d"


class PcapError(ValueError):
    """Raised for files that are not classic pcap with a usable linktype."""


class PcapReader:
    """Iterate (ts, packet_bytes) from a classic pcap file or file object."""

    def __init__(self, source: Union[str, Path, BinaryIO]) -> None:
        self._close_after = False
        if isinstance(source, (str, Path)):
            self._fh: BinaryIO = open(source, "rb")  # noqa: SIM115 - closed in close()
            self._close_after = True
        else:
            self._fh = source
        header = self._fh.read(24)
        if len(header) < 24:
            raise PcapError("file too short for a pcap global header")
        magic = header[:4]
        if magic == _USEC_LE:
            self._endian, self._nsec = "<", False
        elif magic == _USEC_BE:
            self._endian, self._nsec = ">", False
        elif magic == _NSEC_LE:
            self._endian, self._nsec = "<", True
        elif magic == _NSEC_BE:
            self._endian, self._nsec = ">", True
        else:
            raise PcapError(f"not a classic pcap file (magic {magic.hex()})")
        _ver_major, _ver_minor, _zone, _sigfigs, _snaplen, network = struct.unpack(
            self._endian + "HHiIII", header[4:]
        )
        if network != LINKTYPE_RADIOTAP:
            raise PcapError(
                f"linktype {network} is not LINKTYPE_IEEE802_11_RADIOTAP (105); "
                "re-capture with a monitor interface (see docs/DEPLOYMENT.md)"
            )
        self.snaplen = int(_snaplen)
        self.linktype = int(network)

    def __iter__(self) -> Iterator[Tuple[float, bytes]]:
        while True:
            record = self._fh.read(16)
            if not record:
                return
            if len(record) < 16:
                raise PcapError("truncated pcap record header")
            ts_sec, ts_frac, incl_len, orig_len = struct.unpack(self._endian + "IIII", record)
            packet = self._fh.read(incl_len)
            if len(packet) < incl_len:
                raise PcapError("truncated pcap packet data")
            ts = float(ts_sec) + (float(ts_frac) / 1e9 if self._nsec else float(ts_frac) / 1e6)
            self.last_orig_len = int(orig_len)
            yield ts, packet

    def close(self) -> None:
        if self._close_after:
            self._fh.close()
            self._close_after = False

    def __enter__(self) -> "PcapReader":
        return self

    def __exit__(self, *exc: object) -> None:
        self.close()

    last_orig_len: int = 0


def read_pcap(path: Union[str, Path]) -> Iterator[Tuple[float, bytes]]:
    """Convenience iterator over (ts, packet) of a pcap file."""
    with PcapReader(path) as reader:
        yield from reader


def iter_pcap_observations(
    path: Union[str, Path],
    *,
    node_id: str,
    salt: bytes,
    truncate: int = 16,
    allow_raw: bool = False,
    counters: Optional[dict] = None,
) -> Iterator[Observation]:
    """Stream Observations out of a radiotap pcap file (replay path).

    Malformed frames are counted (``counters['errors']``) and skipped, never
    raised: a capture full of oddities must still replay (quality bar).
    """
    if counters is None:
        counters = {}
    with PcapReader(path) as reader:
        for ts, packet in reader:
            counters["packets"] = counters.get("packets", 0) + 1
            try:
                meta, dot11_bytes = parse_radiotap(packet)
            except RadiotapError:
                counters["radiotap_errors"] = counters.get("radiotap_errors", 0) + 1
                continue
            obs, _ephemeral = build_observation(
                dot11_bytes,
                meta,
                ts=ts,
                node_id=node_id,
                salt=salt,
                truncate=truncate,
                wire_length=reader.last_orig_len,
                allow_raw=allow_raw,
            )
            if obs is None:
                counters["unsupported"] = counters.get("unsupported", 0) + 1
                continue
            counters["parsed"] = counters.get("parsed", 0) + 1
            yield obs


# --------------------------------------------------------------------------- #
# Writer (simulator -> replayable pcap; headers only)
# --------------------------------------------------------------------------- #


def write_pcap_header(fh: BinaryIO, snaplen: int = 128) -> None:
    """Write a little-endian usec pcap global header for radiotap linktype."""
    fh.write(_USEC_LE)
    fh.write(struct.pack("<HHiIII", 2, 4, 0, 0, snaplen, LINKTYPE_RADIOTAP))


def write_pcap_packet(
    fh: BinaryIO, ts: float, frame: bytes, snaplen: int = 128, orig_len: Optional[int] = None
) -> None:
    """Append one packet record, truncating to *snaplen* (tcpdump -s semantics).

    *orig_len* is the true on-air frame length when known (defaults to
    len(frame)); readers use it as the wire length so truncation never
    corrupts traffic statistics.
    """
    ts_sec = int(ts // 1)
    ts_usec = int(round((ts - ts_sec) * 1_000_000))
    incl = min(len(frame), snaplen)
    total = orig_len if orig_len is not None else len(frame)
    fh.write(struct.pack("<IIII", ts_sec, ts_usec, incl, total))
    fh.write(frame[:incl])


def _radiotap_bytes(*, freq_mhz: int, rssi_dbm: int, rate_mbps: float, flags: int = 0x10) -> bytes:
    """Build a minimal Radiotap header: FLAGS, RATE, CHANNEL, dBm SIGNAL."""
    # presence: bit1 FLAGS, bit2 RATE, bit3 CHANNEL, bit5 dBm ANTENNA SIGNAL
    presence = (1 << 1) | (1 << 2) | (1 << 3) | (1 << 5)
    header = bytearray()
    header += struct.pack("<BBHI", 0, 0, 0, presence)  # it_len patched below
    header += struct.pack("<B", flags)  # FLAGS (FCS at end)
    header += struct.pack("<B", int(round(rate_mbps * 2)))  # RATE (500 kbps units)
    header += struct.pack("<HH", freq_mhz, 0x00A0)  # CHANNEL: freq + flags (2 GHz)
    header += struct.pack("<b", int(round(rssi_dbm)))  # dBm ANTENNA SIGNAL
    struct.pack_into("<H", header, 2, len(header))
    return bytes(header)


def _mac_bytes(mac: str) -> bytes:
    return bytes(int(part, 16) for part in mac.split(":"))


def observation_to_frame(obs: Observation) -> bytes:
    """Serialize a Wi-Fi Observation back to radiotap + 802.11 header bytes.

    The 802.11 body is zero padding only (the sensor never held payloads);
    ``orig_len`` in the pcap record carries the true on-air length. Only
    fields the reader can round-trip are populated; BLE observations are
    rejected (they do not belong in a radiotap capture).
    """
    if obs.source is not Source.WIFI:
        raise PcapError("only Wi-Fi observations can be written to a radiotap pcap")
    freq = int(obs.freq_mhz) if obs.freq_mhz else (2407 + 5 * (obs.channel or 6))
    rssi = int(round(obs.rssi_dbm))
    rate = obs.rate_mbps if obs.rate_mbps is not None else 6.0
    frame = bytearray(_radiotap_bytes(freq_mhz=freq, rssi_dbm=rssi, rate_mbps=rate))

    ftype = obs.frame_type if obs.frame_type is not None else 2
    subtype = obs.frame_subtype if obs.frame_subtype is not None else 0
    to_ds = bool(obs.to_ds)
    from_ds = bool(obs.from_ds)
    fc = (ftype << 2) | (subtype << 4)
    if to_ds:
        fc |= 0x0100
    if from_ds:
        fc |= 0x0200
    if obs.retry:
        fc |= 0x0800

    # NOTE: hashes cannot be reversed; the writer is only used with raw_addr
    # present (simulator/property tests). Live captured observations are
    # never re-serialized to pcap.
    raw = obs.raw_addr
    if raw is None:
        raise PcapError(
            "observation_to_frame needs raw_addr (synthetic observations only); "
            "captured frames are never re-serialized (HARD RULE 3)"
        )
    peer = "ff:ff:ff:ff:ff:ff"
    body_pad = max(0, obs.length - 24 - 8)  # keep snaplen truncation realistic
    mac_header = bytearray()
    mac_header += struct.pack("<HH", fc, 0)
    src = raw
    bssid = raw if obs.role is Role.AP else peer
    mac_header += _mac_bytes(peer)
    mac_header += _mac_bytes(src)
    mac_header += _mac_bytes(bssid)
    mac_header += struct.pack("<H", 0)  # sequence control
    frame += mac_header
    frame += b"\x00" * min(body_pad, 64)  # zero padding, truncated like tcpdump -s
    return bytes(frame)


def write_observations_pcap(
    path: Union[str, Path], observations: Iterable[Observation], snaplen: int = 128
) -> int:
    """Write Wi-Fi observations (with raw_addr) to a replayable pcap file.

    Returns the number of records written. Synthetic/laptop use only: live
    captured observations have no raw_addr and are refused by design.
    """
    written = 0
    with open(path, "wb") as fh:
        write_pcap_header(fh, snaplen=snaplen)
        for obs in observations:
            if obs.source is not Source.BLE:
                try:
                    frame = observation_to_frame(obs)
                except PcapError:
                    continue
                write_pcap_packet(fh, obs.ts, frame, snaplen=snaplen, orig_len=obs.length)
                written += 1
    return written


def hash_of(mac: str, salt: bytes, truncate: int = 16) -> str:
    """Re-exported helper so tests can align hashes with the writer's salt."""
    return mac_hash(mac, salt, truncate)
