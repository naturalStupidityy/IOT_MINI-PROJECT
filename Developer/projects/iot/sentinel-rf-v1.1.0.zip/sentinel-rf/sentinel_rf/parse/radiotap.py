"""Radiotap header parser (Phase 1, pure stdlib, byte-level).

The capture path only ever needs a handful of Radiotap fields: channel /
frequency, antenna signal (dBm), PHY rate and the header length that bounds
the 802.11 frame that follows. This module parses exactly those, with strict
bounds checking, and raises :class:`RadiotapError` on anything malformed -
callers count errors and keep capturing (quality bar: a bad frame must never
crash the capture loop).

Implemented presence bits (radiotap.org field order):
  0 TSFT (u64)          1 FLAGS (u8)         2 RATE (u8, 500 kbps units)
  3 CHANNEL (u16+u16)   4 FHSS (u8+u8)       5 dBm ANTENNA SIGNAL (i8)
  6 dBm ANTENNA NOISE   7-14 (skipped, sized correctly)
Higher fields (MCS, VHT, HE...) sit after everything above, so their presence
never invalidates the fields we read. Extended presence words are consumed
before field decoding, as the standard requires.
"""

from __future__ import annotations

import struct
from dataclasses import dataclass
from typing import Optional, Tuple

__all__ = ["RadiotapError", "RadiotapMeta", "freq_to_channel", "parse_radiotap"]


class RadiotapError(ValueError):
    """Raised when a buffer is not a parseable Radiotap header."""


# (bit index, field name, alignment, size) - radiotap.org field table.
_FIELDS = (
    (0, "tsft", 8, 8),
    (1, "flags", 1, 1),
    (2, "rate", 1, 1),
    (3, "channel", 2, 4),
    (4, "fhss", 1, 2),
    (5, "dbm_signal", 1, 1),
    (6, "dbm_noise", 1, 1),
    (7, "lock_quality", 2, 2),
    (8, "tx_attenuation", 2, 2),
    (9, "db_tx_attenuation", 2, 2),
    (10, "dbm_tx_attenuation", 2, 2),
    (11, "antenna", 1, 1),
    (12, "db_signal", 1, 1),
    (13, "db_noise", 1, 1),
    (14, "rx_flags", 2, 2),
)


def freq_to_channel(freq_mhz: Optional[float]) -> Optional[int]:
    """Map an 802.11 centre frequency to its channel number (None if unknown)."""
    if freq_mhz is None:
        return None
    f = int(round(freq_mhz))
    if 2412 <= f <= 2472:
        return (f - 2407) // 5
    if f == 2484:
        return 14
    if 4910 <= f <= 4980:
        return (f - 4000) // 5
    if 5000 <= f <= 5885:
        return (f - 5000) // 5
    return None


@dataclass(frozen=True)
class RadiotapMeta:
    """The Radiotap fields SENTINEL-RF consumes (all optional).

    ``header_len`` is always set on success and tells the caller where the
    802.11 frame starts inside the captured buffer.
    """

    header_len: int = 0
    freq_mhz: Optional[int] = None
    rssi_dbm: Optional[float] = None
    rate_mbps: Optional[float] = None
    antenna: Optional[int] = None
    tsft_us: Optional[int] = None

    @property
    def channel(self) -> Optional[int]:
        """Channel number derived from the frequency (None when unknown)."""
        return freq_to_channel(self.freq_mhz)


def _align(pos: int, alignment: int) -> int:
    return (pos + alignment - 1) & ~(alignment - 1)


def parse_radiotap(data: bytes) -> Tuple[RadiotapMeta, bytes]:
    """Parse *data* as a Radiotap header; return (meta, remaining 802.11 bytes).

    Raises RadiotapError for truncated buffers, a non-zero version or a
    header length that does not fit the buffer.
    """
    if len(data) < 8:
        raise RadiotapError(f"radiotap buffer truncated: {len(data)} bytes < 8")
    version = data[0]
    if version != 0:
        raise RadiotapError(f"unsupported radiotap version {version}")
    header_len = struct.unpack_from("<H", data, 2)[0]
    if header_len < 8 or header_len > len(data):
        raise RadiotapError(f"radiotap it_len {header_len} invalid for {len(data)} bytes")

    presence = struct.unpack_from("<I", data, 4)[0]
    field_presence = presence  # bits 0-31 of the FIRST word govern our fields
    pos = 8
    # Extended presence words: bit 31 of each word announces one more word.
    # They sit before any field data, so they must be consumed to find the
    # field area - but field decoding still uses the first word's bits.
    while presence & 0x8000_0000:
        if pos + 4 > header_len:
            raise RadiotapError("radiotap presence word overruns header")
        presence = struct.unpack_from("<I", data, pos)[0]
        pos += 4

    found: dict = {}
    for bit, name, alignment, size in _FIELDS:
        if not ((field_presence >> bit) & 1):
            continue
        pos = _align(pos, alignment)
        if pos + size > header_len:
            raise RadiotapError(f"radiotap field {name} overruns header")
        raw = data[pos : pos + size]
        if name == "tsft":
            found["tsft_us"] = struct.unpack("<Q", raw)[0]
        elif name == "rate":
            found["rate_mbps"] = raw[0] * 0.5
        elif name == "channel":
            found["freq_mhz"] = struct.unpack("<H", raw[:2])[0]
        elif name == "dbm_signal":
            found["rssi_dbm"] = float(struct.unpack("<b", raw)[0])
        elif name == "antenna":
            found["antenna"] = raw[0]
        pos += size

    meta = RadiotapMeta(header_len=header_len, **found)
    return meta, data[header_len:]
