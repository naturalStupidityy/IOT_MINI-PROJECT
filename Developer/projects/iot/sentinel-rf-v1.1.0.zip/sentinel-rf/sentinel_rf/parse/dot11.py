"""802.11 MAC header parser and Observation builder (Phase 1, pure stdlib).

Parses the 24-byte (QoS: 26, 4-address: 30) MAC header plus the management
frame body's information elements, and turns each frame into an
:class:`~sentinel_rf.parse.observation.Observation` keyed on the
**transmitter** address. Only header fields are read (HARD RULE 2); the
frame body beyond the SSID/DS-parameter elements is never inspected or
retained.

Address semantics used for role inference:

===========  ====  ====  ====  =====================================
to_ds from_ds addr1 addr2 addr3 meaning
===========  ====  ====  ====  =====================================
1            0     AP    STA   DA    uplink:   transmitter is a STA
0            1     STA   AP    SA    downlink: transmitter is the AP
0            0     DA    SA    BSSID intra-BSS / ad-hoc: unknown role
1            1     AP    TA    SA    4-address (WDS): unknown role
===========  ====  ====  ====  =====================================

Uplink (To-DS) data from a stationary STA is exactly the signature a
streaming hidden camera leaves, so keying observations on the transmitter
is what the detection layer needs.

The SSID and vendor-specific OUIs travel in :class:`EphemeralWifi`, which
is live-memory-only: it feeds the priors layer (Phase 3) and is never
serialized, stored or exported (HARD RULE 3 applies to payloads too).
"""

from __future__ import annotations

import struct
from dataclasses import dataclass, field
from typing import Dict, Optional, Tuple

from sentinel_rf.crypto import mac_hash, normalize_mac
from sentinel_rf.parse.observation import Observation, Role
from sentinel_rf.parse.radiotap import RadiotapMeta
from sentinel_rf.privacy import is_locally_administered

__all__ = ["Dot11Error", "EphemeralWifi", "parse_dot11_header"]

# Radiotap FLAGS bit 1 (FCS): the captured frame includes a trailing FCS.
_FLAG_FCS_AT_END = 0x10


class Dot11Error(ValueError):
    """Raised when a buffer is not a parseable 802.11 header."""


@dataclass
class EphemeralWifi:
    """Live-memory-only extras from management frames (never serialized).

    The SSID is payload data: it may be examined on the spot for watchlist
    patterns and then must be dropped. Keeping it out of Observation
    guarantees no store or export can ever contain it (HARD RULE 2/3).
    """

    ssid: Optional[str] = None
    channel_from_ie: Optional[int] = None
    vendor_ouis: Tuple[str, ...] = ()
    raw_transmitter: Optional[str] = None

    def to_intel_dict(self) -> Dict[str, Optional[str]]:
        """A tiny snapshot for the priors layer (no raw addresses)."""
        return {"ssid": self.ssid, "channel": self.channel_from_ie}


@dataclass(frozen=True)
class Dot11Header:
    """The decoded 802.11 MAC header (addresses normalised AA:BB:..:CC)."""

    type: int
    subtype: int
    to_ds: bool
    from_ds: bool
    retry: bool
    protected: bool
    fcs_at_end: bool
    addr1: Optional[str]
    addr2: Optional[str]
    addr3: Optional[str]
    addr4: Optional[str]
    seq: int
    header_len: int


def _mac(raw: bytes) -> str:
    return ":".join(f"{b:02x}" for b in raw)


def parse_dot11_header(frame: bytes, *, radiotap_flags: int = 0) -> Tuple[Dot11Header, bytes]:
    """Parse *frame* (starting at the MAC header); return (header, body).

    ``radiotap_flags`` is the Radiotap FLAGS field (bit 1 set = FCS appended);
    it only affects the reported header/body split, never what is parsed.
    """
    if len(frame) < 2:
        raise Dot11Error("802.11 frame truncated: < 2 bytes")
    fc = struct.unpack_from("<H", frame, 0)[0]
    ftype = (fc >> 2) & 0x3
    subtype = (fc >> 4) & 0xF
    to_ds = bool((fc >> 8) & 0x1)
    from_ds = bool((fc >> 8) & 0x2)
    retry = bool((fc >> 8) & 0x8)
    protected = bool((fc >> 8) & 0x40)

    # Control frames have variable, shorter headers.
    if ftype == 1:
        # addr1-only: CTS (12), ACK (13). addr1+addr2: RTS (11), CF-End (14),
        # Block Ack req/resp (15), and the rest by default.
        addr1_only = subtype in (12, 13)
        need = 10 if addr1_only else 16
        if len(frame) < need:
            raise Dot11Error(f"control frame truncated: {len(frame)} < {need}")
        addr1 = _mac(frame[4:10])
        addr2 = None if addr1_only else _mac(frame[10:16])
        return (
            Dot11Header(
                type=ftype,
                subtype=subtype,
                to_ds=False,
                from_ds=False,
                retry=False,
                protected=False,
                fcs_at_end=bool(radiotap_flags & _FLAG_FCS_AT_END),
                addr1=addr1,
                addr2=addr2,
                addr3=None,
                addr4=None,
                seq=0,
                header_len=need,
            ),
            b"",
        )

    need = 24 + (6 if (to_ds and from_ds) else 0) + (2 if (ftype == 2 and subtype & 0x8) else 0)
    if len(frame) < 24:
        raise Dot11Error(f"802.11 header truncated: {len(frame)} < 24")
    if len(frame) < need:
        raise Dot11Error(f"802.11 header truncated: {len(frame)} < {need}")
    addr1 = _mac(frame[4:10])
    addr2 = _mac(frame[10:16])
    addr3 = _mac(frame[16:22])
    seq = struct.unpack_from("<H", frame, 22)[0] >> 4
    addr4 = _mac(frame[24:30]) if (to_ds and from_ds) else None
    return (
        Dot11Header(
            type=ftype,
            subtype=subtype,
            to_ds=to_ds,
            from_ds=from_ds,
            retry=retry,
            protected=protected,
            fcs_at_end=bool(radiotap_flags & _FLAG_FCS_AT_END),
            addr1=addr1,
            addr2=addr2,
            addr3=addr3,
            addr4=addr4,
            seq=seq,
            header_len=need,
        ),
        frame[need:],
    )


def _parse_beacon_ies(body: bytes) -> EphemeralWifi:
    """Extract SSID, DS channel and vendor OUIs from beacon/probe-response IEs."""
    eps = EphemeralWifi()
    ouis = []
    fixed_len = 12  # timestamp(8) + interval(2) + capabilities(2)
    pos = fixed_len
    while pos + 2 <= len(body):
        elem_id, length = body[pos], body[pos + 1]
        value = body[pos + 2 : pos + 2 + length]
        if len(value) < length:
            break  # truncated element (snaplen): stop, keep what we have
        if elem_id == 0:  # SSID
            try:
                eps.ssid = value.decode("utf-8") if value else ""
            except UnicodeDecodeError:
                eps.ssid = value.decode("latin-1", "replace")
        elif elem_id == 3 and length >= 1:  # DS parameter set -> channel
            eps.channel_from_ie = value[0]
        elif elem_id == 221 and length >= 3:  # vendor specific -> OUI
            ouis.append(":".join(f"{b:02x}" for b in value[:3]))
        pos += 2 + length
    eps.vendor_ouis = tuple(dict.fromkeys(ouis))  # de-duplicated, order kept
    return eps


def _frame_role(header: Dot11Header) -> Tuple[Role, Optional[str]]:
    """Return (role of the transmitter, raw BSSID) for a frame."""
    if header.type == 0:  # management
        if header.subtype in (8, 5):  # beacon, probe response -> AP speaks
            return Role.AP, header.addr2
        if header.subtype in (4, 0, 2, 11):  # probe req / assoc req / ...
            return Role.STA, header.addr3
        return Role.UNKNOWN, header.addr3
    if header.type == 2:  # data
        if header.to_ds and not header.from_ds:
            return Role.STA, header.addr1
        if header.from_ds and not header.to_ds:
            return Role.AP, header.addr2
        return Role.UNKNOWN, header.addr3
    return Role.UNKNOWN, None


def build_observation(
    frame: bytes,
    meta: RadiotapMeta,
    *,
    ts: float,
    node_id: str,
    salt: bytes,
    truncate: int = 16,
    wire_length: Optional[int] = None,
    allow_raw: bool = False,
) -> Tuple[Optional[Observation], Optional[EphemeralWifi]]:
    """Turn one captured 802.11 frame into an Observation (+ephemeral intel).

    Returns ``(None, None)`` for frames that carry no address we can key on
    (e.g. malformed extensions). ``wire_length`` is the on-air length when
    known (pcap orig_len); it defaults to the buffer length. The returned
    Observation carries salted hashes only; ``raw_addr`` is filled solely
    when *allow_raw* is set (privacy.allow_raw_mac_live, HARD RULE 3).
    """
    try:
        header, body = parse_dot11_header(frame)
    except Dot11Error:
        return None, None

    transmitter = header.addr2
    if transmitter is None:
        # ACK/CTS-style control frames have no transmitter field; attribute
        # the airtime to the receiver so the frame still counts somewhere.
        transmitter = header.addr1
    if transmitter is None:
        return None, None

    try:
        normalize_mac(transmitter)
    except ValueError:
        return None, None

    role, bssid_raw = _frame_role(header)
    ephemeral: Optional[EphemeralWifi] = None
    if header.type == 0 and header.subtype in (8, 5):
        ephemeral = _parse_beacon_ies(body)

    channel = meta.channel
    if channel is None and ephemeral is not None and ephemeral.channel_from_ie:
        channel = ephemeral.channel_from_ie
    if channel is None:
        channel = 0

    length = int(wire_length) if wire_length is not None else len(frame)

    return (
        Observation.wifi(
            ts=ts,
            node_id=node_id,
            rssi_dbm=round(float(meta.rssi_dbm), 1) if meta.rssi_dbm is not None else -100.0,
            addr_hash=mac_hash(transmitter, salt, truncate),
            length=length,
            channel=channel,
            freq_mhz=float(meta.freq_mhz) if meta.freq_mhz is not None else None,
            bssid_hash=mac_hash(bssid_raw, salt, truncate) if bssid_raw else None,
            addr_is_random=is_locally_administered(transmitter),
            role=role,
            frame_type=header.type,
            frame_subtype=header.subtype,
            to_ds=header.to_ds if header.type == 2 else None,
            from_ds=header.from_ds if header.type == 2 else None,
            retry=header.retry if header.type == 2 else None,
            rate_mbps=meta.rate_mbps,
            raw_addr=transmitter if allow_raw else None,
        ),
        ephemeral,
    )


@dataclass
class ParseCounters:
    """Bookkeeping for the capture loop's health metrics."""

    frames: int = 0
    parsed: int = 0
    radiotap_errors: int = 0
    dot11_errors: int = 0
    unsupported: int = 0
    notes: Dict[str, int] = field(default_factory=dict)
