"""Observation: the single normalised data model (CORE DATA MODEL).

Live monitor-mode capture, BLE scanning, PCAP replay and the simulator all
emit Observation objects; everything downstream (features, detection,
localization) consumes Observation streams only.

Privacy (HARD RULE 3): ``raw_addr`` may carry the raw MAC only for live
in-memory use, and only when privacy.allow_raw_mac_live is enabled.
``to_dict()`` never includes it and ``from_dict()`` refuses it, so a raw
address cannot survive a round trip through any store, queue or export.
Use ``redact()`` to strip it before handing an observation to consumers.
"""

from __future__ import annotations

import dataclasses
import math
import re
from dataclasses import dataclass
from enum import Enum
from typing import Any, Dict, Mapping, Optional, Tuple, Union

from sentinel_rf.crypto import normalize_mac
from sentinel_rf.privacy import PrivacyViolation

__all__ = ["OBSERVATION_SCHEMA_VERSION", "Observation", "Role", "Source"]

OBSERVATION_SCHEMA_VERSION = 1

_HEX_RE = re.compile(r"[0-9a-fA-F]+")


class Source(str, Enum):
    """Where an observation came from."""

    WIFI = "wifi"
    BLE = "ble"


class Role(str, Enum):
    """Inferred role of the transmitting device (Wi-Fi semantics)."""

    AP = "ap"
    STA = "sta"
    UNKNOWN = "unknown"


def _require(condition: bool, message: str) -> None:
    if not condition:
        raise ValueError(message)


def _is_int(value: object) -> bool:
    return isinstance(value, int) and not isinstance(value, bool)


def _is_number(value: object) -> bool:
    return isinstance(value, (int, float)) and not isinstance(value, bool)


def _require_hash(name: str, value: object) -> None:
    """Address fields must be bare hex salted hashes, never raw MACs."""
    ok = (
        isinstance(value, str)
        and 1 <= len(value) <= 64
        and _HEX_RE.fullmatch(value) is not None
        and ":" not in value
        and "-" not in value
    )
    _require(
        ok,
        f"{name} must be 1-64 bare hex characters (a salted hash), never a raw MAC; "
        f"got {value!r}",
    )


@dataclass(frozen=True)
class Observation:
    """One header-only RF event, identical for live capture, replay and sim.

    Wi-Fi fields carry 802.11/Radiotap metadata; BLE fields carry
    advertisement metadata; each set must be empty for the other source.
    """

    ts: float  # seconds (epoch or session-relative)
    source: Source
    node_id: str
    rssi_dbm: float
    addr_hash: str  # salted hash of the transmitter address (never the raw MAC)
    length: int  # frame length on air (bytes); snaplen may truncate what was read
    channel: Optional[int] = None  # 0 = unknown; BLE adv channels 37-39 allowed
    freq_mhz: Optional[float] = None
    bssid_hash: Optional[str] = None  # Wi-Fi only
    addr_is_random: bool = False  # locally-administered bit (MAC randomization)
    role: Role = Role.UNKNOWN
    frame_type: Optional[int] = None  # Wi-Fi only: 0 mgmt, 1 control, 2 data, 3 ext
    frame_subtype: Optional[int] = None  # Wi-Fi only: 0..15
    to_ds: Optional[bool] = None  # Wi-Fi only: direction to DS (uplink)
    from_ds: Optional[bool] = None  # Wi-Fi only: direction from DS (downlink)
    retry: Optional[bool] = None  # Wi-Fi only: retransmission flag
    rate_mbps: Optional[float] = None
    # --- BLE-only fields ---
    adv_type: Optional[str] = None  # e.g. "adv_ind", "adv_scan_rsp"
    tx_power: Optional[float] = None  # dBm, if advertised
    name: Optional[str] = None  # local name from the advertisement
    service_uuids: Tuple[str, ...] = ()
    company_id: Optional[int] = None  # Bluetooth SIG company identifier
    # --- live-only, never serialized (HARD RULE 3) ---
    raw_addr: Optional[str] = None

    def __post_init__(self) -> None:
        # Frozen dataclass: coerce via object.__setattr__.
        if not isinstance(self.source, Source):
            object.__setattr__(self, "source", Source(self.source))
        if not isinstance(self.role, Role):
            object.__setattr__(self, "role", Role(self.role))
        if not isinstance(self.service_uuids, tuple):
            object.__setattr__(self, "service_uuids", tuple(self.service_uuids))
        self._validate()

    def _validate(self) -> None:
        _require(
            isinstance(self.node_id, str) and bool(self.node_id),
            f"node_id must be a non-empty string; got {self.node_id!r}",
        )
        _require(
            _is_number(self.ts) and math.isfinite(float(self.ts)) and self.ts >= 0.0,
            f"ts must be a finite number >= 0; got {self.ts!r}",
        )
        _require(
            _is_number(self.rssi_dbm) and -120.0 <= float(self.rssi_dbm) <= 20.0,
            f"rssi_dbm must be within [-120, 20] dBm; got {self.rssi_dbm!r}",
        )
        _require_hash("addr_hash", self.addr_hash)
        if self.bssid_hash is not None:
            _require_hash("bssid_hash", self.bssid_hash)
        _require(
            _is_int(self.length) and 0 <= self.length <= 65535,
            f"length must be an int in [0, 65535]; got {self.length!r}",
        )
        _require(
            isinstance(self.addr_is_random, bool),
            f"addr_is_random must be a boolean; got {self.addr_is_random!r}",
        )
        if self.channel is not None:
            _require(
                _is_int(self.channel) and 0 <= self.channel <= 255,
                f"channel must be an int in [0, 255] (0 = unknown); got {self.channel!r}",
            )
        if self.freq_mhz is not None:
            _require(
                _is_number(self.freq_mhz) and 2000.0 <= float(self.freq_mhz) <= 6000.0,
                f"freq_mhz must be within [2000, 6000]; got {self.freq_mhz!r}",
            )
        if self.frame_type is not None:
            _require(
                _is_int(self.frame_type) and 0 <= self.frame_type <= 3,
                f"frame_type must be 0..3 (mgmt/control/data/ext); got {self.frame_type!r}",
            )
        if self.frame_subtype is not None:
            _require(
                _is_int(self.frame_subtype) and 0 <= self.frame_subtype <= 15,
                f"frame_subtype must be 0..15; got {self.frame_subtype!r}",
            )
        if self.rate_mbps is not None:
            _require(
                _is_number(self.rate_mbps) and 0.0 <= float(self.rate_mbps) <= 7000.0,
                f"rate_mbps must be within [0, 7000]; got {self.rate_mbps!r}",
            )
        for flag in ("to_ds", "from_ds", "retry"):
            value = getattr(self, flag)
            _require(
                value is None or isinstance(value, bool),
                f"{flag} must be a boolean or null; got {value!r}",
            )
        if self.adv_type is not None:
            _require(
                isinstance(self.adv_type, str) and 1 <= len(self.adv_type) <= 32,
                f"adv_type must be a short string (e.g. 'adv_ind'); got {self.adv_type!r}",
            )
        if self.tx_power is not None:
            _require(
                _is_number(self.tx_power) and -100.0 <= float(self.tx_power) <= 30.0,
                f"tx_power must be within [-100, 30] dBm; got {self.tx_power!r}",
            )
        if self.name is not None:
            _require(
                isinstance(self.name, str) and 1 <= len(self.name) <= 251,
                "name must be a non-empty string of at most 251 chars",
            )
        for uuid in self.service_uuids:
            _require(
                isinstance(uuid, str) and 1 <= len(uuid) <= 36,
                f"service_uuids entries must be strings of 1..36 chars; got {uuid!r}",
            )
        if self.company_id is not None:
            _require(
                _is_int(self.company_id) and 0 <= self.company_id <= 65535,
                f"company_id must be an int in [0, 65535]; got {self.company_id!r}",
            )
        if self.raw_addr is not None:
            normalize_mac(self.raw_addr)  # raises ValueError if malformed
        if self.source is Source.WIFI:
            ble_fields = (self.adv_type, self.tx_power, self.name, self.company_id)
            _require(
                all(v is None for v in ble_fields) and not self.service_uuids,
                "BLE-only fields must be empty for Wi-Fi observations",
            )
        else:
            wifi_fields = (
                self.frame_type,
                self.frame_subtype,
                self.to_ds,
                self.from_ds,
                self.retry,
                self.bssid_hash,
            )
            _require(
                all(v is None for v in wifi_fields),
                "Wi-Fi frame fields must be empty for BLE observations",
            )

    # ------------------------------------------------------------------ #

    def to_dict(self) -> Dict[str, Any]:
        """Serialize for storage/export. Never includes raw_addr (HARD RULE 3)."""
        return {
            "schema_version": OBSERVATION_SCHEMA_VERSION,
            "ts": self.ts,
            "source": self.source.value,
            "node_id": self.node_id,
            "rssi_dbm": self.rssi_dbm,
            "addr_hash": self.addr_hash,
            "length": self.length,
            "channel": self.channel,
            "freq_mhz": self.freq_mhz,
            "bssid_hash": self.bssid_hash,
            "addr_is_random": self.addr_is_random,
            "role": self.role.value,
            "frame_type": self.frame_type,
            "frame_subtype": self.frame_subtype,
            "to_ds": self.to_ds,
            "from_ds": self.from_ds,
            "retry": self.retry,
            "rate_mbps": self.rate_mbps,
            "adv_type": self.adv_type,
            "tx_power": self.tx_power,
            "name": self.name,
            "service_uuids": list(self.service_uuids),
            "company_id": self.company_id,
        }

    @classmethod
    def from_dict(cls, data: Mapping[str, Any]) -> "Observation":
        """Rebuild an Observation from its serialized form (to_dict)."""
        if not isinstance(data, Mapping):
            raise TypeError(f"from_dict expects a mapping, got {type(data).__name__}")
        version = data.get("schema_version")
        if version != OBSERVATION_SCHEMA_VERSION:
            raise ValueError(
                f"unsupported observation schema_version {version!r}; "
                f"expected {OBSERVATION_SCHEMA_VERSION}"
            )
        allowed = {f.name for f in dataclasses.fields(cls)} | {"schema_version"}
        unknown = sorted((str(k) for k in data if k not in allowed), key=repr)
        if unknown:
            raise ValueError(f"unknown Observation field(s): {unknown}")
        kwargs = {k: v for k, v in data.items() if k != "schema_version"}
        if kwargs.get("raw_addr") is not None:
            raise PrivacyViolation(
                "from_dict refuses raw_addr: raw addresses never come from "
                "serialized data (HARD RULE 3)"
            )
        kwargs.pop("raw_addr", None)
        return cls(**kwargs)

    def redact(self) -> "Observation":
        """Return a copy with the live-only raw_addr stripped (safe anywhere)."""
        return dataclasses.replace(self, raw_addr=None)

    # ------------------------------------------------------------------ #

    @classmethod
    def wifi(
        cls,
        *,
        ts: float,
        node_id: str,
        rssi_dbm: float,
        addr_hash: str,
        length: int,
        channel: Optional[int] = None,
        freq_mhz: Optional[float] = None,
        bssid_hash: Optional[str] = None,
        addr_is_random: bool = False,
        role: Union[Role, str] = Role.UNKNOWN,
        frame_type: Optional[int] = None,
        frame_subtype: Optional[int] = None,
        to_ds: Optional[bool] = None,
        from_ds: Optional[bool] = None,
        retry: Optional[bool] = None,
        rate_mbps: Optional[float] = None,
        raw_addr: Optional[str] = None,
    ) -> "Observation":
        """Build a Wi-Fi observation (BLE-only fields stay empty)."""
        return cls(
            ts=ts,
            source=Source.WIFI,
            node_id=node_id,
            rssi_dbm=rssi_dbm,
            addr_hash=addr_hash,
            length=length,
            channel=channel,
            freq_mhz=freq_mhz,
            bssid_hash=bssid_hash,
            addr_is_random=addr_is_random,
            role=role,
            frame_type=frame_type,
            frame_subtype=frame_subtype,
            to_ds=to_ds,
            from_ds=from_ds,
            retry=retry,
            rate_mbps=rate_mbps,
            raw_addr=raw_addr,
        )

    @classmethod
    def ble(
        cls,
        *,
        ts: float,
        node_id: str,
        rssi_dbm: float,
        addr_hash: str,
        length: int = 0,
        channel: Optional[int] = None,
        freq_mhz: Optional[float] = None,
        addr_is_random: bool = False,
        adv_type: Optional[str] = None,
        tx_power: Optional[float] = None,
        name: Optional[str] = None,
        service_uuids: Tuple[str, ...] = (),
        company_id: Optional[int] = None,
        raw_addr: Optional[str] = None,
    ) -> "Observation":
        """Build a BLE advertisement observation (Wi-Fi frame fields stay empty)."""
        return cls(
            ts=ts,
            source=Source.BLE,
            node_id=node_id,
            rssi_dbm=rssi_dbm,
            addr_hash=addr_hash,
            length=length,
            channel=channel,
            freq_mhz=freq_mhz,
            addr_is_random=addr_is_random,
            role=Role.UNKNOWN,
            adv_type=adv_type,
            tx_power=tx_power,
            name=name,
            service_uuids=service_uuids,
            company_id=company_id,
            raw_addr=raw_addr,
        )
