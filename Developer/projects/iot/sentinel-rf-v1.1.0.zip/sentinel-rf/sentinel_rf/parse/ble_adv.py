"""BLE advertisement payload parser (Phase 1, pure stdlib).

Parses Bluetooth Low Energy advertising data (and scan response data) into
the whitelisted, structured fields the Observation model carries: local
name, TX power, service UUIDs and manufacturer company id. Raw advertising
payload bytes are never retained (HARD RULE 2); only these parsed fields
survive, capped in size.

AD structure format (Bluetooth Core Spec, Vol 3, Part H): a sequence of
[length][type][value...] records where *length* counts type+value bytes.
A truncated final record is parsed up to what is present.
"""

from __future__ import annotations

import struct
from dataclasses import dataclass
from typing import List, Optional, Tuple

__all__ = ["BleAdvInfo", "parse_ad_structures", "parse_ble_adv"]

# Generic Access Profile AD types we consume.
_AD_TYPE = {
    "short_local_name": 0x08,
    "complete_local_name": 0x09,
    "tx_power_level": 0x0A,
    "incomplete_uuid16": 0x02,
    "complete_uuid16": 0x03,
    "incomplete_uuid32": 0x04,
    "complete_uuid32": 0x05,
    "incomplete_uuid128": 0x06,
    "complete_uuid128": 0x07,
    "manufacturer_data": 0xFF,
}

# BLE advertising channel -> centre frequency (MHz).
_BLE_ADV_FREQ = {37: 2402.0, 38: 2462.0, 39: 2480.0}

_MAX_NAME = 64  # Observation.name allows 251; keep names tight for display


class BleAdvError(ValueError):
    """Raised when advertising data cannot be parsed at all."""


@dataclass(frozen=True)
class BleAdvInfo:
    """Structured fields extracted from one advertisement."""

    name: Optional[str] = None
    tx_power: Optional[float] = None
    uuids: Tuple[str, ...] = ()
    company_id: Optional[int] = None
    adv_length: int = 0  # bytes of advertising data actually present


def parse_ad_structures(data: bytes) -> List[Tuple[int, bytes]]:
    """Split advertising data into (type, value) structures."""
    structures: List[Tuple[int, bytes]] = []
    i = 0
    while i < len(data):
        length = data[i]
        if length == 0:
            break
        if i + 1 + length > len(data):
            # Truncated final structure: keep the bytes that are present.
            value = data[i + 1 :]
            if value:
                structures.append((value[0], value[1:]))
            break
        structures.append((data[i + 1], data[i + 2 : i + 1 + length]))
        i += 1 + length
    return structures


def parse_ble_adv(adv_data: bytes, scan_rsp: bytes = b"") -> BleAdvInfo:
    """Parse advertisement (+optional scan response) into structured fields.

    Never raises for odd payloads: unknown or truncated structures are
    skipped, because a malformed record must not crash the capture loop
    (quality bar).
    """
    name: Optional[str] = None
    tx_power: Optional[float] = None
    uuids: List[str] = []
    company_id: Optional[int] = None
    total_len = len(adv_data) + len(scan_rsp)

    for ad_type, value in parse_ad_structures(adv_data) + parse_ad_structures(scan_rsp):
        if ad_type in (_AD_TYPE["short_local_name"], _AD_TYPE["complete_local_name"]):
            if name is None and value:
                name = value.decode("utf-8", "replace")[:_MAX_NAME]
        elif ad_type == _AD_TYPE["tx_power_level"] and len(value) >= 1:
            tx_power = float(struct.unpack("<b", value[:1])[0])
        elif ad_type in (_AD_TYPE["incomplete_uuid16"], _AD_TYPE["complete_uuid16"]):
            for k in range(0, len(value) - 1, 2):
                uuids.append(f"{struct.unpack_from('<H', value, k)[0]:04x}")
        elif ad_type in (_AD_TYPE["incomplete_uuid32"], _AD_TYPE["complete_uuid32"]):
            for k in range(0, len(value) - 3, 4):
                uuids.append(f"{struct.unpack_from('<I', value, k)[0]:08x}")
        elif ad_type in (_AD_TYPE["incomplete_uuid128"], _AD_TYPE["complete_uuid128"]):
            if len(value) >= 16:
                uuids.append("".join(f"{b:02x}" for b in value[:16]))
        elif ad_type == _AD_TYPE["manufacturer_data"] and len(value) >= 2 and company_id is None:
            company_id = struct.unpack_from("<H", value, 0)[0]

    return BleAdvInfo(
        name=name,
        tx_power=tx_power,
        uuids=tuple(dict.fromkeys(uuids)),
        company_id=company_id,
        adv_length=total_len,
    )


def ble_adv_frequency(channel: Optional[int]) -> Optional[float]:
    """Centre frequency of a BLE advertising channel (None when unknown)."""
    if channel is None:
        return None
    return _BLE_ADV_FREQ.get(int(channel))
