"""Parsing: Radiotap + 802.11 headers, BLE advertisements, PCAP I/O.

Phase 1 ships byte-level parsers built from hand-made fixtures (pure
stdlib - no scapy; DECISIONS.md D017), the PCAP replay path, and the
headers-only pcap writer used by the simulator.
"""

from sentinel_rf.parse.ble_adv import BleAdvInfo, parse_ble_adv
from sentinel_rf.parse.dot11 import (
    Dot11Error,
    Dot11Header,
    EphemeralWifi,
    build_observation,
    parse_dot11_header,
)
from sentinel_rf.parse.observation import (
    OBSERVATION_SCHEMA_VERSION,
    Observation,
    Role,
    Source,
)
from sentinel_rf.parse.pcap import (
    LINKTYPE_RADIOTAP,
    PcapError,
    PcapReader,
    iter_pcap_observations,
    read_pcap,
)
from sentinel_rf.parse.radiotap import (
    RadiotapError,
    RadiotapMeta,
    freq_to_channel,
    parse_radiotap,
)

__all__ = [
    "OBSERVATION_SCHEMA_VERSION",
    "Observation",
    "Role",
    "Source",
    "BleAdvInfo",
    "parse_ble_adv",
    "Dot11Error",
    "Dot11Header",
    "EphemeralWifi",
    "build_observation",
    "parse_dot11_header",
    "LINKTYPE_RADIOTAP",
    "PcapError",
    "PcapReader",
    "iter_pcap_observations",
    "read_pcap",
    "RadiotapError",
    "RadiotapMeta",
    "freq_to_channel",
    "parse_radiotap",
]
