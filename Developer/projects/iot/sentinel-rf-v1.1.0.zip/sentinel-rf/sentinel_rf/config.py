"""Typed YAML configuration loading and validation.

configs/default.yaml is the single source of truth for documented defaults;
sentinel_rf.defaults.default_config() mirrors it in code and a unit test
fails if the two drift. Unknown keys are rejected (typos fail loudly,
DECISIONS.md D011) and every validation error carries the full dotted key
path. Validation lives in each dataclass's __post_init__, so programmatic
construction is checked exactly like YAML input.
"""

from __future__ import annotations

import dataclasses
import math
import os
from dataclasses import dataclass, field
from pathlib import Path
from typing import (
    Any,
    Mapping,
    Optional,
    Tuple,
    Union,
    get_args,
    get_origin,
    get_type_hints,
)

import yaml

__all__ = [
    "BleCaptureConfig",
    "CaptureConfig",
    "ChannelPlanConfig",
    "ConfigError",
    "DashboardConfig",
    "DetectConfig",
    "FusionBandsConfig",
    "FusionConfig",
    "FusionWeights",
    "LocateConfig",
    "LoggingConfig",
    "MqttConfig",
    "MqttTlsConfig",
    "PathlossConfig",
    "PrivacyConfig",
    "RoomConfig",
    "SentinelConfig",
    "StoreConfig",
    "StimulusConfig",
    "WindowsConfig",
    "load_config",
]

DEFAULT_CONFIG_RELPATH = Path("configs/default.yaml")
CONFIG_ENV_VAR = "SENTINEL_RF_CONFIG"

_LEVELS = ("DEBUG", "INFO", "WARNING", "ERROR", "CRITICAL")

_VALID_5G = frozenset(
    {
        36,
        40,
        44,
        48,
        52,
        56,
        60,
        64,
        100,
        104,
        108,
        112,
        116,
        120,
        124,
        128,
        132,
        136,
        140,
        144,
        149,
        153,
        157,
        161,
        165,
        169,
        173,
        177,
    }
)


class ConfigError(ValueError):
    """Raised when configuration cannot be read, parsed or validated."""


def _require(condition: bool, message: str) -> None:
    if not condition:
        raise ValueError(message)


def _is_int(value: object) -> bool:
    return isinstance(value, int) and not isinstance(value, bool)


def _is_number(value: object) -> bool:
    return isinstance(value, (int, float)) and not isinstance(value, bool)


def _int_in(value: object, lo: int, hi: int) -> bool:
    return _is_int(value) and lo <= value <= hi


def _num_in(value: object, lo: float, hi: float) -> bool:
    return _is_number(value) and math.isfinite(float(value)) and lo <= value <= hi


# --------------------------------------------------------------------------- #
# Configuration tree (mirrors configs/default.yaml exactly)
# --------------------------------------------------------------------------- #


@dataclass(frozen=True)
class PrivacyConfig:
    """privacy.* - HARD RULE 3 knobs."""

    allow_raw_mac_live: bool = False
    salt_file: Optional[Path] = None
    hash_truncate: int = 16

    def __post_init__(self) -> None:
        _require(
            isinstance(self.allow_raw_mac_live, bool),
            f"allow_raw_mac_live must be a boolean; got {self.allow_raw_mac_live!r}",
        )
        _require(
            self.salt_file is None or isinstance(self.salt_file, Path),
            f"salt_file must be a path or null; got {self.salt_file!r}",
        )
        _require(
            _int_in(self.hash_truncate, 16, 64) and self.hash_truncate % 2 == 0,
            "hash_truncate must be an even number of hex chars in [16, 64] "
            "(12 is forbidden on purpose so bare raw MACs can never be confused "
            "with hashes; DECISIONS.md D009)",
        )


@dataclass(frozen=True)
class ChannelPlanConfig:
    """capture.channel_plan.* - hopping strategy (Scan mode; Lock mode pins)."""

    bands: Tuple[str, ...] = ("2g",)
    channels_2g: Tuple[int, ...] = (1, 6, 11, 2, 3, 4, 5, 7, 8, 9, 10, 12, 13)
    channels_5g: Tuple[int, ...] = (36, 40, 44, 48, 149, 153, 157, 161, 165)
    dwell_ms: int = 300

    def __post_init__(self) -> None:
        _require(
            bool(self.bands) and set(self.bands) <= {"2g", "5g"},
            f"bands must be a non-empty subset of ('2g', '5g'); got {self.bands!r}",
        )
        _require(
            all(_int_in(c, 1, 13) for c in self.channels_2g),
            f"channels_2g entries must be channel numbers 1..13; got {self.channels_2g!r}",
        )
        _require(
            all(c in _VALID_5G for c in self.channels_5g),
            f"channels_5g entries must be standard 5 GHz channels; got {self.channels_5g!r}",
        )
        if "2g" in self.bands:
            _require(
                bool(self.channels_2g), "channels_2g must not be empty when bands includes '2g'"
            )
        if "5g" in self.bands:
            _require(
                bool(self.channels_5g), "channels_5g must not be empty when bands includes '5g'"
            )
        _require(
            _int_in(self.dwell_ms, 100, 2000),
            f"dwell_ms must be an int in [100, 2000] (Scan-mode dwell); got {self.dwell_ms!r}",
        )


@dataclass(frozen=True)
class BleCaptureConfig:
    """capture.ble.* - BLE coexistence knobs (Phase 2)."""

    enabled: bool = True
    scan_mode: str = "active"
    slot_between_hops: bool = True

    def __post_init__(self) -> None:
        _require(
            isinstance(self.enabled, bool),
            f"enabled must be a boolean; got {self.enabled!r}",
        )
        _require(
            self.scan_mode in ("active", "passive"),
            "scan_mode must be 'active' or 'passive' (active requests SCAN_RSP: "
            f"names, TX power); got {self.scan_mode!r}",
        )
        _require(
            isinstance(self.slot_between_hops, bool),
            f"slot_between_hops must be a boolean; got {self.slot_between_hops!r}",
        )


@dataclass(frozen=True)
class CaptureConfig:
    """capture.* - interface and pipeline sizing."""

    iface: str = "mon0"
    snaplen: int = 128
    queue_size: int = 4096
    channel_plan: ChannelPlanConfig = field(default_factory=ChannelPlanConfig)
    ble: BleCaptureConfig = field(default_factory=BleCaptureConfig)

    def __post_init__(self) -> None:
        _require(
            isinstance(self.iface, str) and bool(self.iface),
            f"iface must be a non-empty interface name (e.g. 'mon0'); got {self.iface!r}",
        )
        _require(
            _int_in(self.snaplen, 64, 256),
            "snaplen must be in [64, 256] bytes: headers-only capture, payload "
            f"bytes are never stored (HARD RULE 2); got {self.snaplen!r}",
        )
        _require(
            _int_in(self.queue_size, 16, 1_000_000),
            f"queue_size must be an int in [16, 1000000]; got {self.queue_size!r}",
        )
        _require(
            isinstance(self.channel_plan, ChannelPlanConfig),
            "channel_plan must be a mapping",
        )
        _require(isinstance(self.ble, BleCaptureConfig), "ble must be a mapping")


@dataclass(frozen=True)
class WindowsConfig:
    """windows.* - sliding feature windows per device (Phase 3)."""

    short_s: int = 1
    medium_s: int = 10
    long_s: int = 60

    def __post_init__(self) -> None:
        _require(
            _is_int(self.short_s) and _is_int(self.medium_s) and _is_int(self.long_s),
            "window lengths must be integers",
        )
        _require(
            0 < self.short_s < self.medium_s < self.long_s,
            f"must satisfy 0 < short_s < medium_s < long_s; got {self.short_s}, "
            f"{self.medium_s}, {self.long_s}",
        )


@dataclass(frozen=True)
class FusionWeights:
    """detect.fusion.weights.* - relative evidence weights (normalized at use)."""

    priors: float = 15.0
    traffic: float = 35.0
    stimulus: float = 40.0
    ble: float = 10.0

    def __post_init__(self) -> None:
        for name in ("priors", "traffic", "stimulus", "ble"):
            value = getattr(self, name)
            _require(
                _num_in(value, 0.0, 100.0) and value > 0.0,
                f"{name} weight must be a positive number in (0, 100]; got {value!r}",
            )


@dataclass(frozen=True)
class FusionBandsConfig:
    """detect.fusion.bands.* - score interpretation thresholds."""

    ignore_below: float = 30.0
    likely_above: float = 60.0

    def __post_init__(self) -> None:
        _require(
            _num_in(self.ignore_below, 0.0, 100.0) and _num_in(self.likely_above, 0.0, 100.0),
            "bands must be numbers in [0, 100]",
        )
        _require(
            self.ignore_below < self.likely_above,
            f"must satisfy ignore_below < likely_above; got {self.ignore_below} < "
            f"{self.likely_above}",
        )


@dataclass(frozen=True)
class StimulusConfig:
    """detect.stimulus.* - CLI-guided stimulus protocol (Phase 4)."""

    baseline_s: int = 60
    stimulus_s: int = 60
    half_period_s: float = 5.0
    alpha: float = 0.05

    def __post_init__(self) -> None:
        _require(
            _int_in(self.baseline_s, 10, 600) and _int_in(self.stimulus_s, 10, 600),
            "baseline_s and stimulus_s must be ints in [10, 600]",
        )
        _require(
            _num_in(self.half_period_s, 0.5, 60.0),
            f"half_period_s must be in [0.5, 60] seconds; got {self.half_period_s!r}",
        )
        _require(
            _num_in(self.alpha, 0.001, 0.5),
            f"alpha must be a significance level in (0, 0.5]; got {self.alpha!r}",
        )


@dataclass(frozen=True)
class FusionConfig:
    """detect.fusion.*"""

    weights: FusionWeights = field(default_factory=FusionWeights)
    bands: FusionBandsConfig = field(default_factory=FusionBandsConfig)


@dataclass(frozen=True)
class DetectConfig:
    """detect.*"""

    fusion: FusionConfig = field(default_factory=FusionConfig)
    stimulus: StimulusConfig = field(default_factory=StimulusConfig)


@dataclass(frozen=True)
class RoomConfig:
    """locate.room.* - rectangular room bounds (metres)."""

    x_m: float = 5.0
    y_m: float = 4.0

    def __post_init__(self) -> None:
        _require(
            _num_in(self.x_m, 1.0, 100.0) and _num_in(self.y_m, 1.0, 100.0),
            "room sides must be numbers in [1, 100] metres",
        )


@dataclass(frozen=True)
class PathlossConfig:
    """locate.pathloss.* - RSSI(d) = P0 - 10*n*log10(d); calibrate per room."""

    p0_dbm: float = -40.0
    n: float = 2.5

    def __post_init__(self) -> None:
        _require(
            _num_in(self.p0_dbm, -100.0, 10.0),
            f"p0_dbm must be in [-100, 10]; got {self.p0_dbm!r}",
        )
        _require(
            _num_in(self.n, 1.0, 6.0), f"path-loss exponent n must be in [1, 6]; got {self.n!r}"
        )


@dataclass(frozen=True)
class LocateConfig:
    """locate.*"""

    room: RoomConfig = field(default_factory=RoomConfig)
    grid_resolution_m: float = 0.25
    pathloss: PathlossConfig = field(default_factory=PathlossConfig)
    survey_sample_s: int = 45
    anchors_file: Optional[Path] = None

    def __post_init__(self) -> None:
        _require(
            _num_in(self.grid_resolution_m, 0.05, 1.0),
            f"grid_resolution_m must be in [0.05, 1.0]; got {self.grid_resolution_m!r}",
        )
        _require(
            _int_in(self.survey_sample_s, 10, 120),
            f"survey_sample_s must be an int in [10, 120]; got {self.survey_sample_s!r}",
        )
        _require(
            self.anchors_file is None or isinstance(self.anchors_file, Path),
            "anchors_file must be a path or null",
        )


@dataclass(frozen=True)
class StoreConfig:
    """store.* - SQLite persistence (Phase 6); raw frames never hit disk."""

    path: Path = Path("data/sentinel.sqlite3")
    batch_size: int = 200
    retention_days: int = 7

    def __post_init__(self) -> None:
        _require(
            isinstance(self.path, Path),
            f"path must be a filesystem path string; got {self.path!r}",
        )
        _require(
            _int_in(self.batch_size, 1, 10_000),
            f"batch_size must be an int in [1, 10000]; got {self.batch_size!r}",
        )
        _require(
            _int_in(self.retention_days, 1, 3650),
            f"retention_days must be an int in [1, 3650]; got {self.retention_days!r}",
        )


@dataclass(frozen=True)
class MqttTlsConfig:
    """mqtt.tls.*"""

    enabled: bool = False
    ca: Optional[Path] = None

    def __post_init__(self) -> None:
        _require(
            isinstance(self.enabled, bool),
            f"tls.enabled must be a boolean; got {self.enabled!r}",
        )
        _require(self.ca is None or isinstance(self.ca, Path), "tls.ca must be a path or null")


@dataclass(frozen=True)
class MqttConfig:
    """mqtt.* - multi-node transport (Phase 6). Credentials never live here."""

    enabled: bool = False
    host: str = "localhost"
    port: int = 1883
    site: str = "lab"
    node_id: str = "node-1"
    keepalive_s: int = 60
    tls: MqttTlsConfig = field(default_factory=MqttTlsConfig)

    def __post_init__(self) -> None:
        _require(
            isinstance(self.enabled, bool),
            f"enabled must be a boolean; got {self.enabled!r}",
        )
        _require(
            isinstance(self.host, str) and bool(self.host),
            f"host must be a non-empty string; got {self.host!r}",
        )
        _require(_int_in(self.port, 1, 65535), f"port must be in [1, 65535]; got {self.port!r}")
        for name in ("site", "node_id"):
            value = getattr(self, name)
            _require(
                isinstance(value, str) and bool(value) and not (set(value) & set("/+#")),
                f"{name} must be a non-empty string without MQTT topic characters '/', '+', '#'",
            )
        _require(
            _int_in(self.keepalive_s, 5, 600),
            f"keepalive_s must be an int in [5, 600]; got {self.keepalive_s!r}",
        )
        _require(isinstance(self.tls, MqttTlsConfig), "tls must be a mapping")


@dataclass(frozen=True)
class DashboardConfig:
    """dashboard.* - FastAPI service (Phase 7)."""

    host: str = "0.0.0.0"
    port: int = 8000

    def __post_init__(self) -> None:
        _require(
            isinstance(self.host, str) and bool(self.host),
            f"host must be a non-empty string; got {self.host!r}",
        )
        _require(_int_in(self.port, 1, 65535), f"port must be in [1, 65535]; got {self.port!r}")


@dataclass(frozen=True)
class LoggingConfig:
    """logging.*"""

    level: str = "INFO"
    file: Optional[Path] = None

    def __post_init__(self) -> None:
        _require(
            self.level in _LEVELS,
            f"level must be one of {', '.join(_LEVELS)}; got {self.level!r}",
        )
        _require(
            self.file is None or isinstance(self.file, Path),
            "file must be a path or null",
        )


@dataclass(frozen=True)
class SentinelConfig:
    """Top-level configuration tree (mirrors configs/default.yaml)."""

    schema_version: int = 1
    privacy: PrivacyConfig = field(default_factory=PrivacyConfig)
    capture: CaptureConfig = field(default_factory=CaptureConfig)
    windows: WindowsConfig = field(default_factory=WindowsConfig)
    detect: DetectConfig = field(default_factory=DetectConfig)
    locate: LocateConfig = field(default_factory=LocateConfig)
    store: StoreConfig = field(default_factory=StoreConfig)
    mqtt: MqttConfig = field(default_factory=MqttConfig)
    dashboard: DashboardConfig = field(default_factory=DashboardConfig)
    logging: LoggingConfig = field(default_factory=LoggingConfig)

    def __post_init__(self) -> None:
        _require(
            self.schema_version == 1,
            f"unsupported schema_version {self.schema_version!r}; expected 1",
        )


# --------------------------------------------------------------------------- #
# Loader
# --------------------------------------------------------------------------- #

_NoneType = type(None)


def _convert(tp: Any, value: Any, path: str) -> Any:
    """Convert a raw YAML value to the type expected by dataclass field *tp*."""
    origin = get_origin(tp)
    if origin is tuple:
        args = get_args(tp)
        if not (len(args) == 2 and args[1] is Ellipsis):
            raise ConfigError(f"{path}: unsupported tuple type {tp!r} (only Tuple[T, ...])")
        if not isinstance(value, (list, tuple)):
            raise ConfigError(f"{path}: expected a list, got {type(value).__name__}")
        return tuple(_convert(args[0], item, f"{path}[{i}]") for i, item in enumerate(value))
    if origin is Union:
        if value is None:
            return None
        non_none = [a for a in get_args(tp) if a is not _NoneType]
        if len(non_none) != 1:
            raise ConfigError(f"{path}: unsupported union type {tp!r}")
        return _convert(non_none[0], value, path)
    if tp is bool:
        if not isinstance(value, bool):
            raise ConfigError(f"{path}: expected a boolean, got {value!r}")
        return value
    if tp is int:
        if not _is_int(value):
            raise ConfigError(f"{path}: expected an integer, got {value!r}")
        return value
    if tp is float:
        if not _is_number(value) or not math.isfinite(float(value)):
            raise ConfigError(f"{path}: expected a finite number, got {value!r}")
        return float(value)
    if tp is str:
        if not isinstance(value, str):
            raise ConfigError(f"{path}: expected a string, got {value!r}")
        return value
    if isinstance(tp, type) and issubclass(tp, Path):
        if not isinstance(value, str):
            raise ConfigError(f"{path}: expected a filesystem path string, got {value!r}")
        return Path(value)
    if dataclasses.is_dataclass(tp):
        return _build(tp, value, path)
    raise ConfigError(f"{path}: unsupported config field type {tp!r}")


def _build(dc_type: type, raw: Any, path: str) -> Any:
    """Build a frozen config dataclass from a raw mapping, with key-path errors."""
    if not isinstance(raw, Mapping):
        raise ConfigError(f"{path or '<root>'}: expected a mapping, got {type(raw).__name__}")
    hints = get_type_hints(dc_type)
    field_names = {f.name for f in dataclasses.fields(dc_type)}
    unknown = sorted((str(k) for k in raw if k not in field_names), key=repr)
    if unknown:
        raise ConfigError(
            f"{path or '<root>'}: unknown key(s) {unknown}; valid keys: " f"{sorted(field_names)}"
        )
    kwargs: dict = {}
    for name in sorted(field_names):
        if name not in raw:
            continue  # keep the documented dataclass default
        key_path = f"{path}.{name}" if path else name
        kwargs[name] = _convert(hints[name], raw[name], key_path)
    try:
        return dc_type(**kwargs)
    except ValueError as exc:
        raise ConfigError(f"{path or '<root>'}: {exc}") from exc


def load_config(path: Optional[Union[str, Path]] = None) -> SentinelConfig:
    """Load and validate the configuration.

    Resolution order: explicit *path*, then $SENTINEL_RF_CONFIG, then
    ./configs/default.yaml when present, otherwise the built-in defaults
    (identical to the shipped YAML; a unit test enforces that).
    """
    resolved: Optional[Path] = None
    if path is not None:
        resolved = Path(path)
    elif os.environ.get(CONFIG_ENV_VAR):
        resolved = Path(os.environ[CONFIG_ENV_VAR])
    elif DEFAULT_CONFIG_RELPATH.is_file():
        resolved = DEFAULT_CONFIG_RELPATH
    if resolved is None:
        from sentinel_rf.defaults import default_config  # local import avoids a cycle

        return default_config()
    if not resolved.is_file():
        raise ConfigError(f"config file not found: {resolved}")
    try:
        raw = yaml.safe_load(resolved.read_text(encoding="utf-8"))
    except yaml.YAMLError as exc:
        raise ConfigError(f"{resolved}: invalid YAML: {exc}") from exc
    if not isinstance(raw, Mapping):
        raise ConfigError(f"{resolved}: top level must be a mapping, got {type(raw).__name__}")
    return _build(SentinelConfig, raw, "")
