"""Traffic simulator (Phase 1).

Seedable and deterministic; generates labelled device traces as
Observation streams (or PCAP via sentinel_rf.parse.pcap for the replay
backend): streaming camera (uplink-dominant, large frames, periodic
keyframe bursts, bitrate following a scene-activity signal), video call,
YouTube-like download, web browsing, bulk upload, idle IoT, BLE
advertisers. The shared ground truth for Phase 3-5 unit tests and
experiments.
"""

from sentinel_rf.sim.generator import (
    RfSimulator,
    SimDevice,
    square_wave,
    standard_devices,
)

__all__ = ["RfSimulator", "SimDevice", "square_wave", "standard_devices"]
