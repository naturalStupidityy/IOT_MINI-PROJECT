"""Deterministic RF environment simulator (Phase 1).

Generates labelled Wi-Fi + BLE traffic as Observation streams - the shared
ground truth for Phase 3-5 unit tests, ML training data and laptop demos.
Determinism: every stream uses its own ``random.Random`` seeded from the
simulator seed and the device id; the global ``random`` module is never
touched, so every experiment is bit-reproducible (quality bar).

Modelled device kinds (behavioural, not vendor claims):
  ap                  beaconing access point; also emits its STAs' downlink
  camera              hidden-camera profile: stationary STA, uplink-dominant,
                      QoS video traffic, periodic keyframe bursts, bitrate
                      follows scene activity (light/motion), fixed factory MAC
  camera_lowres       same but ~1/4 bitrate (harder positive)
  phone_video_call    symmetric moderate video call (uplink+downlink)
  laptop_youtube      downlink-heavy; uplink is only small ACK/burst frames
  laptop_browsing     bursty request/response web traffic
  laptop_bulk_upload  saturated MTU-sized uplink (hard negative: high uplink
                      alone is not a camera)
  iot_idle            keepalive frames every ~45 s
  ble_watch           BLE advertiser with a generic wearable name
  ble_camera_companion BLE advertiser with a camera-ish name (priors test)

RSSI is path-loss from the device position to each receiver node position:
``rssi = p0 - 10*n*log10(d) + N(0, sigma)`` (BLE uses its own p0/n).
"""

from __future__ import annotations

import heapq
import math
import random
from dataclasses import dataclass
from typing import Any, Callable, Dict, Iterator, List, Optional, Sequence, Tuple

from sentinel_rf.crypto import mac_hash
from sentinel_rf.parse.ble_adv import ble_adv_frequency
from sentinel_rf.parse.observation import Observation, Role
from sentinel_rf.privacy import is_locally_administered

__all__ = ["RfSimulator", "SimDevice", "square_wave", "standard_devices", "varied_cast"]

_WIFI_P0 = -40.0  # dBm at 1 m
_WIFI_N = 2.5  # path-loss exponent
_WIFI_SIGMA = 3.0  # dB log-normal shadowing
_BLE_P0 = -50.0
_BLE_N = 2.0

# Plausible synthetic OUIs per kind (synthetic MACs; not vendor claims).
_KIND_OUI = {
    "ap": "b8:27:eb",
    "camera": "24:0a:c4",
    "camera_lowres": "24:0a:c4",
    "phone_video_call": "f0:18:98",
    "laptop_youtube": "3c:a9:f4",
    "laptop_browsing": "3c:a9:f4",
    "laptop_bulk_upload": "3c:a9:f4",
    "iot_idle": "00:e0:4c",
    "ble_watch": "00:16:32",
    "ble_camera_companion": "24:0a:c4",
}

_BSSID_PEER = "b8:27:eb:11:22:33"  # the AP STAs associate with


@dataclass(frozen=True)
class SimDevice:
    """One simulated device (behaviour + geometry + identity)."""

    device_id: str
    kind: str
    mac: str
    position: Tuple[float, float]
    channel: int = 6
    ssid: Optional[str] = None
    is_camera: bool = False
    mobile: bool = False
    ble_name: Optional[str] = None
    ble_uuids: Tuple[str, ...] = ()
    ble_company_id: Optional[int] = None
    ble_random: bool = False
    ble_interval_s: float = 1.0


def _synth_mac(device_id: str, kind: str) -> str:
    """Deterministic synthetic MAC for a device id."""
    oui = _KIND_OUI.get(kind, "02:00:00")
    digest = abs(hash((device_id, kind))) % 0xFFFFFF
    return f"{oui}:{(digest >> 16) & 0xFF:02x}:{(digest >> 8) & 0xFF:02x}:{digest & 0xFF:02x}"


def square_wave(
    t: float,
    *,
    period: float,
    duty: float = 0.5,
    phase: float = 0.0,
    hi: float = 1.0,
    lo: float = 0.0,
) -> float:
    """Stimulus helper: light on/off square wave evaluated at time *t*."""
    frac = ((t + phase) % period) / period
    return hi if frac < duty else lo


def _default_activity(t: float) -> float:
    """Steady scene activity with slow variation (no stimulus)."""
    return 0.55 + 0.15 * math.sin(2.0 * math.pi * t / 37.0)


_BENIGN_SSIDS = ("HomeNet", "CoffeeFree", "eduroam", "IoT-Lab", "Flat-4B", "GuestNet")


def varied_cast(
    rng: random.Random, room: Tuple[float, float], *, with_camera: bool = True
) -> List[SimDevice]:
    """A randomized cast for ML environment diversity (Phase 4).

    Unlike :func:`standard_devices` (fixed, for deterministic demos), each
    call draws device counts, positions, channels and camera bitrates from
    *rng*, so every training environment contains different device
    instances - leave-one-device-out CV then measures generalization to
    unseen devices, which is the question that matters.
    """
    devices: List[SimDevice] = []
    counter: Dict[str, int] = {}

    def add(kind: str, **kwargs) -> None:
        counter[kind] = counter.get(kind, 0) + 1
        device_id = f"{kind}-{len(devices):02d}-{counter[kind]}"
        defaults: Dict[str, object] = {
            "device_id": device_id,
            "kind": kind,
            "mac": _synth_mac(device_id, kind),
            "position": (
                round(rng.uniform(0.1, 0.9) * room[0], 2),
                round(rng.uniform(0.1, 0.9) * room[1], 2),
            ),
            "channel": rng.choice((1, 6, 11)),
        }
        defaults.update(kwargs)
        devices.append(SimDevice(**defaults))  # type: ignore[arg-type]

    n_aps = rng.randint(1, 2)
    for _ in range(n_aps):
        add("ap", ssid=rng.choice(_BENIGN_SSIDS), is_camera=False)
    for _ in range(rng.randint(1, 3)):
        add("phone_video_call", mobile=True)
    for _ in range(rng.randint(0, 2)):
        add("laptop_youtube", mobile=True)
    for _ in range(rng.randint(1, 2)):
        add("laptop_browsing", mobile=True)
    if rng.random() < 0.7:
        add("laptop_bulk_upload")
    if rng.random() < 0.5:
        add("iot_idle")
    if rng.random() < 0.7:
        add(
            "ble_watch",
            ble_name="Fit Watch 3",
            ble_uuids=("180d", "181a"),
            ble_company_id=0x0087,
            ble_random=True,
            ble_interval_s=rng.uniform(0.8, 1.5),
        )
    if with_camera:
        for _ in range(rng.randint(1, 2)):
            add("camera", is_camera=True)
        if rng.random() < 0.6:
            add("camera_lowres", is_camera=True)
        if rng.random() < 0.6:
            add(
                "ble_camera_companion",
                ble_name=f"IPC-{rng.randint(0x1000, 0xFFFF):04X}",
                ble_uuids=("181a",),
                ble_company_id=0x0059,
                ble_random=False,
                ble_interval_s=rng.uniform(0.5, 1.0),
            )
    return devices


def standard_devices(
    room: Tuple[float, float] = (5.0, 4.0), with_camera: bool = True
) -> List[SimDevice]:
    """The standard cast: one BSS, neighbours, BLE advertisers.

    ``room`` scales positions; with_camera=False drops the camera devices so
    negative-only runs (specificity tests) are easy to build.
    """

    def pos(fx: float, fy: float) -> Tuple[float, float]:
        return (round(room[0] * fx, 2), round(room[1] * fy, 2))

    devices = [
        SimDevice(
            device_id="ap-main",
            kind="ap",
            mac=_synth_mac("ap-main", "ap"),
            position=pos(0.5, 0.5),
            ssid="LabNet",
        ),
        SimDevice(
            device_id="phone-alice",
            kind="phone_video_call",
            mac=_synth_mac("phone-alice", "phone_video_call"),
            position=pos(0.7, 0.2),
            mobile=True,
        ),
        SimDevice(
            device_id="phone-bob",
            kind="phone_video_call",
            mac=_synth_mac("phone-bob", "phone_video_call"),
            position=pos(0.1, 0.8),
            mobile=True,
        ),
        SimDevice(
            device_id="laptop-stream",
            kind="laptop_youtube",
            mac=_synth_mac("laptop-stream", "laptop_youtube"),
            position=pos(0.9, 0.9),
            mobile=True,
        ),
        SimDevice(
            device_id="laptop-web",
            kind="laptop_browsing",
            mac=_synth_mac("laptop-web", "laptop_browsing"),
            position=pos(0.3, 0.6),
            mobile=True,
        ),
        SimDevice(
            device_id="laptop-backup",
            kind="laptop_bulk_upload",
            mac=_synth_mac("laptop-backup", "laptop_bulk_upload"),
            position=pos(0.6, 0.7),
        ),
        SimDevice(
            device_id="plug-meter",
            kind="iot_idle",
            mac=_synth_mac("plug-meter", "iot_idle"),
            position=pos(0.2, 0.1),
        ),
        SimDevice(
            device_id="watch-carol",
            kind="ble_watch",
            mac=_synth_mac("watch-carol", "ble_watch"),
            position=pos(0.4, 0.3),
            ble_name="Fit Watch 3",
            ble_uuids=("180d", "181a"),
            ble_company_id=0x0087,
            ble_random=True,
            ble_interval_s=1.0,
        ),
    ]
    if with_camera:
        devices += [
            SimDevice(
                device_id="cam-bookshelf",
                kind="camera",
                mac=_synth_mac("cam-bookshelf", "camera"),
                position=pos(0.85, 0.15),
                is_camera=True,
            ),
            SimDevice(
                device_id="cam-lowres-smoke",
                kind="camera_lowres",
                mac=_synth_mac("cam-lowres-smoke", "camera_lowres"),
                position=pos(0.15, 0.9),
                is_camera=True,
            ),
            SimDevice(
                device_id="ble-cam-tag",
                kind="ble_camera_companion",
                mac=_synth_mac("ble-cam-tag", "ble_camera_companion"),
                position=pos(0.84, 0.16),
                ble_name="IPC-9F2A",
                ble_uuids=("181a",),
                ble_company_id=0x0059,
                ble_random=False,
                ble_interval_s=0.7,
            ),
        ]
    return devices


@dataclass
class _FrameEvent:
    ts: float
    device_id: str
    kind: str  # "beacon" | "data_up" | "data_down" | "ble_adv"
    length: int
    is_qos: bool
    retry: bool
    rate_mbps: float


class RfSimulator:
    """Seedable, deterministic, multi-node RF environment."""

    def __init__(
        self,
        *,
        seed: int = 42,
        duration_s: float = 120.0,
        t0: float = 1_700_000_000.0,
        devices: Optional[Sequence[SimDevice]] = None,
        room: Tuple[float, float] = (5.0, 4.0),
        node_positions: Optional[Dict[str, Tuple[float, float]]] = None,
        stimulus_signal: Optional[Callable[[float], float]] = None,
        salt: Optional[bytes] = None,
        truncate: int = 16,
        allow_raw: bool = False,
        wifi_p0: float = _WIFI_P0,
        wifi_n: float = _WIFI_N,
        wifi_sigma: float = _WIFI_SIGMA,
    ) -> None:
        import secrets

        self.seed = int(seed)
        self.duration_s = float(duration_s)
        self.t0 = float(t0)
        self.room = tuple(room)
        self.stimulus_signal = stimulus_signal
        self.salt = salt if salt is not None else secrets.token_bytes(16)
        self.truncate = int(truncate)
        self.allow_raw = bool(allow_raw)
        self.wifi_p0, self.wifi_n, self.wifi_sigma = wifi_p0, wifi_n, wifi_sigma
        self.devices: List[SimDevice] = list(devices) if devices else standard_devices(room)
        self.node_positions: Dict[str, Tuple[float, float]] = dict(node_positions or {})
        if not self.node_positions:
            self.node_positions = {"node-1": (0.3, 0.3)}
        self._by_id = {d.device_id: d for d in self.devices}
        self._label_cache: Dict[str, Dict[str, Any]] = {}

    # ------------------------------------------------------------------ #
    # Geometry / physics
    # ------------------------------------------------------------------ #

    def _rng(self, device_id: str, stream: str = "main") -> random.Random:
        return random.Random(f"{self.seed}:{device_id}:{stream}")

    def _rssi_at(
        self, position: Tuple[float, float], node_pos: Tuple[float, float], rng: Any, ble: bool
    ) -> float:
        p0, n = (_BLE_P0, _BLE_N) if ble else (self.wifi_p0, self.wifi_n)
        d = max(math.hypot(position[0] - node_pos[0], position[1] - node_pos[1]), 0.5)
        rssi = p0 - 10.0 * n * math.log10(d) + rng.gauss(0.0, self.wifi_sigma)
        return round(max(min(rssi, -25.0), -95.0), 1)

    def _activity(self, t: float) -> float:
        if self.stimulus_signal is not None:
            return self.stimulus_signal(t)
        return _default_activity(t)

    def _position_at(self, dev: SimDevice, t: float) -> Tuple[float, float]:
        """Mobile devices random-walk ~0.3 m per 10 s around their anchor."""
        if not dev.mobile:
            return dev.position
        rng = self._rng(dev.device_id, "walk")
        x, y = dev.position
        for _ in range(int(t / 10.0) + 1):
            x += rng.gauss(0.0, 0.3)
            y += rng.gauss(0.0, 0.3)
        x = max(0.2, min(self.room[0] - 0.2, x))
        y = max(0.2, min(self.room[1] - 0.2, y))
        return (x, y)

    # ------------------------------------------------------------------ #
    # Per-device event streams
    # ------------------------------------------------------------------ #

    def _ap_beacon_stream(self, dev: SimDevice) -> Iterator[_FrameEvent]:
        """AP beacons (~102.4 ms interval)."""
        rng = self._rng(dev.device_id, "beacons")
        t = 0.0
        while t < self.duration_s:
            yield _FrameEvent(
                t,
                dev.device_id,
                "beacon",
                length=int(max(rng.gauss(140, 8), 60)),
                is_qos=False,
                retry=False,
                rate_mbps=6.0,
            )
            t += 0.1024 * rng.uniform(0.95, 1.05)

    def _ap_downlink_stream(
        self, dev: SimDevice, ap_downlink: Dict[float, float]
    ) -> Iterator[_FrameEvent]:
        """Aggregated downlink to associated STAs (1 s buckets, 1 ms pacing)."""
        rng_dl = self._rng(dev.device_id, "downlink")
        t = 0.0
        while t < self.duration_s:
            demand = ap_downlink.get(round(t, 3), 0.0)
            if demand <= 0.0:
                t += 0.05
                continue
            for k in range(min(max(1, int(demand / 900.0)), 40)):
                yield _FrameEvent(
                    t + 0.001 * k,
                    dev.device_id,
                    "data_down",
                    length=int(min(max(rng_dl.gauss(1000, 250), 60), 1500)),
                    is_qos=True,
                    retry=bool(rng_dl.random() < 0.02),
                    rate_mbps=65.0,
                )
            t += 1.0

    def _station_stream(self, dev: SimDevice) -> Iterator[_FrameEvent]:
        """Uplink data stream, behaviour per kind; camera bitrate follows activity."""
        rng = self._rng(dev.device_id, "uplink")
        t = 0.0
        kind = dev.kind
        base_bps = {
            "camera": 1_200_000.0,
            "camera_lowres": 320_000.0,
            "phone_video_call": 450_000.0,
            "laptop_youtube": 60_000.0,
            "laptop_bulk_upload": 2_400_000.0,
        }.get(kind, 0.0)

        if kind == "laptop_browsing":
            while t < self.duration_s:
                on = rng.uniform(2.0, 6.0)
                off = rng.uniform(8.0, 30.0)
                end = min(t + on, self.duration_s)
                n = int(rng.uniform(8, 25))
                for k in range(n):
                    tt = t + (end - t) * (k + rng.random()) / n
                    if tt >= self.duration_s:
                        break
                    yield _FrameEvent(
                        tt,
                        dev.device_id,
                        "data_up",
                        length=int(rng.uniform(300, 900)),
                        is_qos=False,
                        retry=bool(rng.random() < 0.02),
                        rate_mbps=24.0,
                    )
                t = end + off
            return

        if kind == "iot_idle":
            while t < self.duration_s:
                yield _FrameEvent(
                    t,
                    dev.device_id,
                    "data_up",
                    length=int(rng.uniform(48, 96)),
                    is_qos=False,
                    retry=False,
                    rate_mbps=1.0,
                )
                t += rng.uniform(35.0, 55.0)
            return

        paced = kind in ("camera", "camera_lowres", "phone_video_call", "laptop_bulk_upload")
        jitter = {
            "camera": 0.10,
            "camera_lowres": 0.12,
            "phone_video_call": 0.25,
            "laptop_bulk_upload": 0.02,
            "laptop_youtube": 0.6,
        }.get(kind, 0.3)
        mean_size = {
            "camera": 900.0,
            "camera_lowres": 620.0,
            "phone_video_call": 420.0,
            "laptop_youtube": 60.0,
            "laptop_bulk_upload": 1450.0,
        }.get(kind, 500.0)
        size_sd = mean_size * 0.25
        retry_p = {
            "camera": 0.10,
            "camera_lowres": 0.12,
            "phone_video_call": 0.03,
            "laptop_youtube": 0.01,
            "laptop_bulk_upload": 0.02,
        }.get(kind, 0.03)
        last_keyframe = -10.0
        while t < self.duration_s:
            if kind in ("camera", "camera_lowres"):
                activity = self._activity(max(t - 0.2, 0.0))
                bps = base_bps * (0.25 + 0.75 * max(0.0, activity))
            else:
                bps = base_bps * rng.uniform(0.9, 1.1)
            fps = bps / 8.0 / mean_size
            if fps < 0.05:
                t += 0.25
                continue
            length = int(max(min(rng.gauss(mean_size, size_sd), 1500), 40))
            if kind in ("camera", "camera_lowres") and (t - last_keyframe) >= 2.0:
                last_keyframe = t
                length = int(min(rng.gauss(1450, 40), 1500))
            yield _FrameEvent(
                t,
                dev.device_id,
                "data_up",
                length=length,
                is_qos=kind in ("camera", "camera_lowres", "phone_video_call"),
                retry=bool(rng.random() < retry_p),
                rate_mbps=65.0 if kind != "laptop_youtube" else 6.0,
            )
            interval = 1.0 / fps
            if paced:
                t += interval * rng.uniform(1.0 - jitter, 1.0 + jitter)
            else:
                t += rng.expovariate(1.0 / interval)

    def _ble_stream(self, dev: SimDevice) -> Iterator[_FrameEvent]:
        rng = self._rng(dev.device_id, "ble")
        t = rng.uniform(0.0, dev.ble_interval_s)
        while t < self.duration_s:
            yield _FrameEvent(
                t,
                dev.device_id,
                "ble_adv",
                length=31 + (31 if dev.ble_name else 0),
                is_qos=False,
                retry=False,
                rate_mbps=1.0,
            )
            t += dev.ble_interval_s * rng.uniform(0.85, 1.15)

    # ------------------------------------------------------------------ #
    # Event merge
    # ------------------------------------------------------------------ #

    def _events(self) -> Iterator[_FrameEvent]:
        """Merge all device streams into one ts-ordered event iterator."""
        downlink_demand: Dict[float, float] = {}

        def note_downlink(t: float, bps: float) -> None:
            key = round(min(t, self.duration_s - 0.001), 3)
            downlink_demand[key] = downlink_demand.get(key, 0.0) + bps

        # Per-second downlink demand of receiving STAs (the AP transmits it).
        for dev in self.devices:
            if dev.kind in ("phone_video_call", "laptop_youtube", "laptop_browsing"):
                rng = self._rng(dev.device_id, "downlink_demand")
                t = 0.0
                while t < self.duration_s:
                    if dev.kind == "phone_video_call":
                        bps, t_next = 450_000.0 * rng.uniform(0.9, 1.1), 1.0
                    elif dev.kind == "laptop_youtube":
                        bps = 1_800_000.0 if rng.random() < 0.75 else 50_000.0
                        t_next = 1.0
                    else:
                        bps = 600_000.0 if rng.random() < 0.35 else 0.0
                        t_next = rng.uniform(1.0, 5.0)
                    note_downlink(t, bps)
                    t += t_next

        streams: List[Iterator[_FrameEvent]] = []
        for dev in self.devices:
            if dev.kind == "ap":
                streams.append(self._ap_beacon_stream(dev))
                streams.append(self._ap_downlink_stream(dev, downlink_demand))
            elif dev.kind.startswith("ble_"):
                streams.append(self._ble_stream(dev))
            else:
                streams.append(self._station_stream(dev))
        yield from heapq.merge(*streams, key=lambda e: e.ts)

    # ------------------------------------------------------------------ #
    # Public API
    # ------------------------------------------------------------------ #

    def observations(self) -> Iterator[Observation]:
        """Yield every observation of every node, in timestamp order."""
        rssi_rngs = {
            (dev.device_id, node_id): self._rng(dev.device_id, f"rssi:{node_id}")
            for dev in self.devices
            for node_id in self.node_positions
        }
        for event in self._events():
            ts = self.t0 + event.ts
            dev = self._by_id[event.device_id]
            ble = event.kind == "ble_adv"
            position = self._position_at(dev, event.ts)
            for node_id, node_pos in self.node_positions.items():
                rng = rssi_rngs[(dev.device_id, node_id)]
                rssi = self._rssi_at(position, node_pos, rng, ble=ble)
                if ble:
                    yield self._ble_observation(dev, event, ts, node_id, rssi)
                else:
                    yield self._wifi_observation(dev, event, ts, node_id, rssi)

    def _wifi_observation(
        self,
        dev: SimDevice,
        event: _FrameEvent,
        ts: float,
        node_id: str,
        rssi: float,
    ) -> Observation:
        if event.kind == "beacon":
            role, bssid = Role.AP, dev.mac
            frame_type, frame_subtype = 0, 8
            to_ds = from_ds = retry = None
        elif event.kind == "data_down":
            role, bssid = Role.AP, dev.mac
            frame_type, frame_subtype = 2, (8 if event.is_qos else 0)
            to_ds, from_ds, retry = False, True, event.retry
        else:  # data_up
            role, bssid = Role.STA, _BSSID_PEER
            frame_type, frame_subtype = 2, (8 if event.is_qos else 0)
            to_ds, from_ds, retry = True, False, event.retry
        return Observation.wifi(
            ts=ts,
            node_id=node_id,
            rssi_dbm=rssi,
            addr_hash=mac_hash(dev.mac, self.salt, self.truncate),
            length=event.length,
            channel=dev.channel,
            freq_mhz=2407.0 + 5.0 * dev.channel if dev.channel <= 13 else None,
            bssid_hash=mac_hash(bssid, self.salt, self.truncate),
            addr_is_random=is_locally_administered(dev.mac),
            role=role,
            frame_type=frame_type,
            frame_subtype=frame_subtype,
            to_ds=to_ds,
            from_ds=from_ds,
            retry=retry,
            rate_mbps=event.rate_mbps,
            raw_addr=dev.mac if self.allow_raw else None,
        )

    def _ble_observation(
        self,
        dev: SimDevice,
        event: _FrameEvent,
        ts: float,
        node_id: str,
        rssi: float,
    ) -> Observation:
        channel = (37, 38, 39)[int(event.ts * 3) % 3]
        return Observation.ble(
            ts=ts,
            node_id=node_id,
            rssi_dbm=rssi,
            addr_hash=mac_hash(dev.mac, self.salt, self.truncate),
            length=event.length,
            channel=channel,
            freq_mhz=ble_adv_frequency(channel),
            addr_is_random=dev.ble_random,
            adv_type="adv_ind" if (int(event.ts) % 5) else "adv_scan_rsp",
            tx_power=-4.0 if dev.ble_name else None,
            name=dev.ble_name,
            service_uuids=dev.ble_uuids,
            company_id=dev.ble_company_id,
            raw_addr=dev.mac if self.allow_raw else None,
        )

    # ------------------------------------------------------------------ #
    # Ground truth (eval only)
    # ------------------------------------------------------------------ #

    def labels(self) -> Dict[str, Dict[str, Any]]:
        """addr_hash -> {device_id, kind, is_camera, position}.

        Evaluation/test-side ground truth only; the detection pipeline never
        sees it. Positions are device anchor positions (metres).
        """
        if not self._label_cache:
            for dev in self.devices:
                self._label_cache[mac_hash(dev.mac, self.salt, self.truncate)] = {
                    "device_id": dev.device_id,
                    "kind": dev.kind,
                    "is_camera": dev.is_camera,
                    "position": dev.position,
                }
        return dict(self._label_cache)

    def seed_intel(self, cache) -> None:
        """Seed an IntelCache with vendor/SSID/BLE-name priors for the cast.

        The dot11 parser normally fills the cache from live frames (raw-MAC
        OUI lookup); the simulator emits Observations directly, so this
        helper performs the equivalent seeding from the device list. Memory
        only, like every intel path (D025).
        """
        from sentinel_rf.intel.cache import DeviceIntel
        from sentinel_rf.intel.oui import load_packaged_oui

        db = load_packaged_oui()
        for dev in self.devices:
            info = db.lookup(dev.mac)
            cache.seed(
                mac_hash(dev.mac, self.salt, self.truncate),
                DeviceIntel(
                    vendor=info.vendor if info else None,
                    vendor_category=info.category if info else None,
                    ssid=dev.ssid,
                    ble_name=dev.ble_name,
                ),
            )

    def summary(self) -> Dict[str, int]:
        """Event counts per device kind (per node copies not multiplied)."""
        kind_of = {d.device_id: d.kind for d in self.devices}
        counts: Dict[str, int] = {d.kind: 0 for d in self.devices}
        for event in self._events():
            counts[kind_of[event.device_id]] += 1
        return counts
