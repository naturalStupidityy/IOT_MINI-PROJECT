"""Localization (Phase 5): path-loss calibration, grid likelihood, WLS,
waypoint survey, mesh merge and hot-cold LED hunting.

Primary estimator: 0.25 m likelihood grid with Gaussian dB residuals.
Secondary: robust weighted least squares (scipy, extras 'locate') as a
cross-check. Single-node deployments degrade to a distance-only estimate.
All hardware-facing output (ACT LED) is UNVERIFIED until
docs/verification-log.md carries Pi evidence.
"""

from sentinel_rf.locate.anchors import Anchor, AnchorSet, RoomProfile
from sentinel_rf.locate.grid import GridLocator, LocationEstimate
from sentinel_rf.locate.hotcold import HotColdGuide, console_blink, score_from_rssi
from sentinel_rf.locate.lsq import wls_estimate
from sentinel_rf.locate.pathloss import (
    PathLossModel,
    fit,
    median_rssi,
    residual_db,
    trimmed_mean,
)
from sentinel_rf.locate.survey import SurveyRunner, WaypointResult, collect_measurements

__all__ = [
    "Anchor",
    "AnchorSet",
    "GridLocator",
    "HotColdGuide",
    "LocationEstimate",
    "PathLossModel",
    "RoomProfile",
    "SurveyRunner",
    "WaypointResult",
    "collect_measurements",
    "console_blink",
    "fit",
    "median_rssi",
    "residual_db",
    "score_from_rssi",
    "trimmed_mean",
    "wls_estimate",
]
