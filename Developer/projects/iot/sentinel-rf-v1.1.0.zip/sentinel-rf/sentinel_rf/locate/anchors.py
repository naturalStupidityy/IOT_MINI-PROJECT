"""Anchors and room profiles (Phase 5).

An *anchor* is a sensor node with known coordinates in the room frame
(measured with a tape during setup). A *room profile* bundles the room
bounds, the path-loss model (calibrated) and the anchors; it is the single
YAML artefact the localization stack consumes. Single-node deployments
have one anchor and degrade to a distance-only estimate.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, Optional, Sequence, Tuple, Union

import yaml

from sentinel_rf.locate.pathloss import PathLossModel

__all__ = ["Anchor", "AnchorSet", "RoomProfile"]


@dataclass(frozen=True)
class Anchor:
    """A sensor node at known room coordinates (metres)."""

    node_id: str
    x: float
    y: float

    def distance_to(self, x: float, y: float) -> float:
        return ((x - self.x) ** 2 + (y - self.y) ** 2) ** 0.5


@dataclass(frozen=True)
class AnchorSet:
    """Immutable anchor collection with node_id lookup."""

    anchors: Tuple[Anchor, ...] = ()

    @classmethod
    def from_list(cls, anchors: Sequence[Anchor]) -> "AnchorSet":
        seen = set()
        for anchor in anchors:
            if anchor.node_id in seen:
                raise ValueError(f"duplicate anchor node_id {anchor.node_id!r}")
            seen.add(anchor.node_id)
        return cls(tuple(anchors))

    def get(self, node_id: str) -> Optional[Anchor]:
        for anchor in self.anchors:
            if anchor.node_id == node_id:
                return anchor
        return None

    def __len__(self) -> int:
        return len(self.anchors)

    def __iter__(self):
        return iter(self.anchors)

    def bounds(self) -> Tuple[float, float]:
        """(max_x, max_y) over anchors - sanity hint for room bounds."""
        if not self.anchors:
            return 0.0, 0.0
        return (
            max(a.x for a in self.anchors),
            max(a.y for a in self.anchors),
        )


@dataclass(frozen=True)
class RoomProfile:
    """Room bounds + calibrated path-loss model + anchors."""

    name: str = "room"
    width_m: float = 5.0
    height_m: float = 4.0
    pathloss: PathLossModel = field(default_factory=PathLossModel)
    anchors: AnchorSet = field(default_factory=AnchorSet)

    def __post_init__(self) -> None:
        if self.width_m <= 0 or self.height_m <= 0:
            raise ValueError("room dimensions must be positive")
        for anchor in self.anchors:
            if not (0.0 <= anchor.x <= self.width_m and 0.0 <= anchor.y <= self.height_m):
                raise ValueError(
                    f"anchor {anchor.node_id} at ({anchor.x}, {anchor.y}) lies outside "
                    f"the {self.width_m}x{self.height_m} m room"
                )

    # ------------------------------------------------------------------ #

    def to_dict(self) -> Dict:
        return {
            "name": self.name,
            "width_m": self.width_m,
            "height_m": self.height_m,
            "pathloss": {
                "p0_dbm": self.pathloss.p0_dbm,
                "n": self.pathloss.n,
                "sigma_db": self.pathloss.sigma_db,
            },
            "anchors": [
                {"node_id": a.node_id, "x": round(a.x, 3), "y": round(a.y, 3)} for a in self.anchors
            ],
        }

    def save(self, path: Union[str, Path]) -> None:
        Path(path).parent.mkdir(parents=True, exist_ok=True)
        Path(path).write_text(
            yaml.safe_dump(self.to_dict(), sort_keys=False, allow_unicode=True),
            encoding="utf-8",
        )

    @classmethod
    def from_dict(cls, data: Dict) -> "RoomProfile":
        pathloss = data.get("pathloss") or {}
        anchors = AnchorSet.from_list(
            [
                Anchor(node_id=str(a["node_id"]), x=float(a["x"]), y=float(a["y"]))
                for a in data.get("anchors") or []
            ]
        )
        return cls(
            name=str(data.get("name", "room")),
            width_m=float(data.get("width_m", 5.0)),
            height_m=float(data.get("height_m", 4.0)),
            pathloss=PathLossModel(
                p0_dbm=float(pathloss.get("p0_dbm", -40.0)),
                n=float(pathloss.get("n", 2.5)),
                sigma_db=float(pathloss.get("sigma_db", 3.0)),
            ),
            anchors=anchors,
        )

    @classmethod
    def load(cls, path: Union[str, Path]) -> "RoomProfile":
        data = yaml.safe_load(Path(path).read_text(encoding="utf-8"))
        if not isinstance(data, dict):
            raise ValueError(f"{path}: room profile must be a mapping")
        return cls.from_dict(data)
