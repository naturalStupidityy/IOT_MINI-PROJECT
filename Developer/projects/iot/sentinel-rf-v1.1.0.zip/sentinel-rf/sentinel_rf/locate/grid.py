"""Grid likelihood localization (Phase 5) - the primary estimator.

Discretises the room at ``grid_resolution_m`` (default 0.25 m) and scores
every cell with a Gaussian dB-residual log-likelihood under the room's
path-loss model:

    log L(x, y) = -sum_i (rssi_i - (P0 - 10 n log10 d_i(x, y)))^2 / (2 sigma^2)

The posterior is the softmax over cells; the estimate is the posterior mean
(clipped to the room) and the uncertainty the posterior standard deviation
(a "credible radius"). Compared to least squares this is robust to
outliers, cannot diverge, and yields a heatmap the dashboard can draw.
"""

from __future__ import annotations

import math
from dataclasses import dataclass
from typing import Dict, Tuple

import numpy as np

from sentinel_rf.locate.anchors import RoomProfile

__all__ = ["GridLocator", "LocationEstimate"]


@dataclass(frozen=True)
class LocationEstimate:
    """One localization result with uncertainty."""

    x: float
    y: float
    sigma_m: float  # posterior standard deviation (combined)
    method: str = "grid"
    node_ids: Tuple[str, ...] = ()
    residuals_db: Tuple[float, ...] = ()

    @property
    def as_tuple(self) -> Tuple[float, float]:
        return (self.x, self.y)

    def to_dict(self) -> Dict:
        return {
            "x": round(self.x, 3),
            "y": round(self.y, 3),
            "sigma_m": round(self.sigma_m, 3),
            "method": self.method,
            "node_ids": list(self.node_ids),
            "residuals_db": [round(r, 2) for r in self.residuals_db],
        }


class GridLocator:
    """Likelihood grid over a rectangular room."""

    def __init__(self, profile: RoomProfile, grid_resolution_m: float = 0.25) -> None:
        if grid_resolution_m <= 0 or grid_resolution_m > min(profile.width_m, profile.height_m):
            raise ValueError(f"invalid grid resolution {grid_resolution_m}")
        self.profile = profile
        self.resolution = float(grid_resolution_m)
        self._xs = np.arange(self.resolution / 2.0, profile.width_m, self.resolution)
        self._ys = np.arange(self.resolution / 2.0, profile.height_m, self.resolution)
        self._gx, self._gy = np.meshgrid(self._xs, self._ys)  # (ny, nx)
        # Pre-compute distance from every anchor to every cell.
        self._dist: Dict[str, np.ndarray] = {}
        for anchor in profile.anchors:
            self._dist[anchor.node_id] = np.hypot(self._gx - anchor.x, self._gy - anchor.y)

    @property
    def shape(self) -> Tuple[int, int]:
        return (len(self._ys), len(self._xs))

    # ------------------------------------------------------------------ #

    def estimate(
        self, measurements: Dict[str, float], *, minimum: bool = False
    ) -> LocationEstimate:
        """Estimate (x, y) from {node_id: rssi_dbm} (one reading per anchor).

        ``minimum`` returns the maximum-likelihood cell instead of the
        posterior mean (used when the posterior is hopelessly multimodal).
        """
        usable = [
            (self.profile.anchors.get(node_id), float(rssi))
            for node_id, rssi in measurements.items()
        ]
        usable = [(a, r) for a, r in usable if a is not None]
        if not usable:
            raise ValueError("no measurements match the room's anchors")

        model = self.profile.pathloss
        log_lik = np.zeros(self._gx.shape)
        for anchor, rssi in usable:
            expected = model.p0_dbm - 10.0 * model.n * np.log10(
                np.maximum(self._dist[anchor.node_id], self.resolution)
            )
            log_lik -= (rssi - expected) ** 2 / (2.0 * model.sigma_db**2)

        posterior = np.exp(log_lik - log_lik.max())
        posterior /= posterior.sum()

        if minimum:
            idx = int(np.argmax(posterior))
            y_idx, x_idx = np.unravel_index(idx, posterior.shape)
            x, y = float(self._gx[y_idx, x_idx]), float(self._gy[y_idx, x_idx])
        else:
            x = float((posterior * self._gx).sum())
            y = float((posterior * self._gy).sum())
        var = float((posterior * ((self._gx - x) ** 2 + (self._gy - y) ** 2)).sum())
        sigma_m = math.sqrt(max(var, 0.0))

        residuals = tuple(
            round(rssi - model.rssi_at(anchor.distance_to(x, y)), 2) for anchor, rssi in usable
        )
        return LocationEstimate(
            x=min(max(x, 0.0), self.profile.width_m),
            y=min(max(y, 0.0), self.profile.height_m),
            sigma_m=sigma_m,
            method="grid",
            node_ids=tuple(a.node_id for a, _ in usable),
            residuals_db=residuals,
        )

    def heatmap(self, measurements: Dict[str, float]) -> Dict:
        """Posterior + geometry for the dashboard (extent for imshow-style use)."""
        usable = [
            (self.profile.anchors.get(node_id), float(rssi))
            for node_id, rssi in measurements.items()
        ]
        usable = [(a, r) for a, r in usable if a is not None]
        if not usable:
            raise ValueError("no measurements match the room's anchors")
        model = self.profile.pathloss
        log_lik = np.zeros(self._gx.shape)
        for anchor, rssi in usable:
            expected = model.p0_dbm - 10.0 * model.n * np.log10(
                np.maximum(self._dist[anchor.node_id], self.resolution)
            )
            log_lik -= (rssi - expected) ** 2 / (2.0 * model.sigma_db**2)
        posterior = np.exp(log_lik - log_lik.max())
        posterior /= posterior.sum()
        return {
            "posterior": posterior.tolist(),
            "shape": list(posterior.shape),
            "extent": [0.0, self.profile.width_m, 0.0, self.profile.height_m],
            "resolution": self.resolution,
            "anchors": [{"node_id": a.node_id, "x": a.x, "y": a.y} for a in self.profile.anchors],
        }

    def single_node_estimate(self, node_id: str, rssi: float) -> LocationEstimate:
        """Distance-only estimate for one anchor: point on the anchor-room diagonal."""
        anchor = self.profile.anchors.get(node_id)
        if anchor is None:
            raise ValueError(f"unknown anchor {node_id!r}")
        distance = self.profile.pathloss.distance_from(rssi)
        # project along the diagonal through the anchor, clamped to the room
        direction = np.array(
            [self.profile.width_m / 2 - anchor.x, self.profile.height_m / 2 - anchor.y]
        )
        norm = float(np.linalg.norm(direction))
        if norm < 1e-6:
            direction = np.array([1.0, 0.0])
            norm = 1.0
        reach = min(distance / norm, 1.0)
        x = float(anchor.x + reach * direction[0])
        y = float(anchor.y + reach * direction[1])
        return LocationEstimate(
            x=min(max(x, 0.0), self.profile.width_m),
            y=min(max(y, 0.0), self.profile.height_m),
            sigma_m=distance / 2.0,  # single range is a ring, not a point
            method="single-anchor-distance",
            node_ids=(node_id,),
            residuals_db=(round(rssi - self.profile.pathloss.rssi_at(distance), 2),),
        )
