"""Waypoint survey (Phase 5): collect per-anchor RSSI for a target device.

Standing at each of >= 4 marked waypoints with the sensor running, the
operator records 30-60 s of the target device's RSSI per node; medians
over each waypoint become a multilateration measurement set. The same
machinery powers `sentinel calibrate` (known distances instead of
waypoints) and the mesh collector (Phase 6).

All pure-python; works against any Observation stream, so the laptop demo
drives it from the simulator.
"""

from __future__ import annotations

import time
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Sequence, Tuple

from sentinel_rf.locate.anchors import RoomProfile
from sentinel_rf.locate.grid import GridLocator, LocationEstimate
from sentinel_rf.locate.pathloss import median_rssi, trimmed_mean
from sentinel_rf.parse.observation import Observation

__all__ = ["SurveyRunner", "WaypointResult"]


@dataclass
class WaypointResult:
    """RSSI aggregates for one waypoint visit."""

    position: Tuple[float, float]
    samples: Dict[str, List[float]] = field(default_factory=dict)  # node_id -> rssi

    def medians(self) -> Dict[str, float]:
        return {node: median_rssi(values) for node, values in self.samples.items() if values}

    def trimmed_means(self) -> Dict[str, float]:
        return {node: trimmed_mean(values) for node, values in self.samples.items() if values}

    @property
    def n_samples(self) -> int:
        return sum(len(v) for v in self.samples.values())


class SurveyRunner:
    """Collect waypoint measurements for one target device."""

    def __init__(
        self,
        *,
        target_hash: str,
        profile: RoomProfile,
        aggregate: str = "median",
        min_waypoints: int = 4,
    ) -> None:
        if aggregate not in ("median", "trimmed_mean"):
            raise ValueError("aggregate must be 'median' or 'trimmed_mean'")
        self.target_hash = target_hash
        self.profile = profile
        self.aggregate = aggregate
        self.min_waypoints = min_waypoints
        self.waypoints: List[WaypointResult] = []
        self._current: Optional[WaypointResult] = None
        self._started_at: Optional[float] = None

    # -- waypoint lifecycle --------------------------------------------- #

    def begin_waypoint(self, x: float, y: float) -> None:
        if self._current is not None:
            raise RuntimeError("end the current waypoint before beginning another")
        self._current = WaypointResult(position=(float(x), float(y)))
        self._started_at = time.time()

    def update(self, obs: Observation) -> None:
        """Feed observations; only the target device's are recorded."""
        if self._current is None or obs.addr_hash != self.target_hash:
            return
        self._current.samples.setdefault(obs.node_id, []).append(obs.rssi_dbm)

    def end_waypoint(self) -> WaypointResult:
        if self._current is None:
            raise RuntimeError("no waypoint in progress")
        result = self._current
        self.waypoints.append(result)
        self._current = None
        self._started_at = None
        return result

    # -- estimation ------------------------------------------------------ #

    def measurement_set(self) -> Dict[str, float]:
        """Merge waypoints into {node_id: aggregated rssi} for the target."""
        if not self.waypoints:
            raise RuntimeError("no waypoints collected yet")
        per_node: Dict[str, List[float]] = {}
        for waypoint in self.waypoints:
            aggregates = (
                waypoint.medians() if self.aggregate == "median" else waypoint.trimmed_means()
            )
            for node_id, value in aggregates.items():
                per_node.setdefault(node_id, []).append(value)
        # Median across waypoints per node (robust to one bad visit).
        return {node: median_rssi(values) for node, values in per_node.items()}

    def estimate(self, grid: Optional[GridLocator] = None) -> LocationEstimate:
        """Grid (primary) and WLS (cross-check) over the merged measurements."""
        measurements = self.measurement_set()
        if len(measurements) < 2:
            raise RuntimeError(
                f"only {len(measurements)} anchor(s) saw the target; multilateration "
                "needs >= 2 (survey near more nodes or extend the dwell)"
            )
        locator = grid if grid is not None else GridLocator(self.profile)
        return locator.estimate(measurements)

    def ready(self) -> bool:
        return len(self.waypoints) >= self.min_waypoints

    def summary(self) -> Dict:
        return {
            "target": self.target_hash,
            "waypoints": [
                {"x": w.position[0], "y": w.position[1], "n": w.n_samples} for w in self.waypoints
            ],
            "ready": self.ready(),
        }


def collect_measurements(
    observations: Sequence[Observation],
    target_hash: str,
    *,
    aggregate: str = "median",
) -> Dict[str, float]:
    """One-shot helper: aggregate a plain observation list per node."""
    runner = SurveyRunner(target_hash=target_hash, profile=RoomProfile(), aggregate=aggregate)
    runner.begin_waypoint(0.0, 0.0)
    for obs in observations:
        runner.update(obs)
    runner.end_waypoint()
    return runner.measurement_set()
