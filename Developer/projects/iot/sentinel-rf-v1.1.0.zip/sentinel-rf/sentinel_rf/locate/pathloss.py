"""Path-loss model and calibration (Phase 5).

RSSI(d) = P0 - 10*n*log10(d) + shadowing. ``P0`` is the RSSI at 1 m and
``n`` the path-loss exponent (2 in free space, 2-4 indoors, up to ~6 in
heavy clutter). Both are room-specific: ``sentinel calibrate`` fits them
from measurements taken at known distances and stores the result in a room
profile (YAML) used by the grid and WLS estimators.

:func:`fit` recovers (P0, n) by linear regression of RSSI on log10(d).
"""

from __future__ import annotations

import math
from dataclasses import dataclass
from typing import Iterable, List, Sequence, Tuple

__all__ = ["PathLossModel", "fit", "residual_db"]


@dataclass(frozen=True)
class PathLossModel:
    """RSSI(d) = p0_dbm - 10*n*log10(d)."""

    p0_dbm: float = -40.0
    n: float = 2.5
    sigma_db: float = 3.0  # shadowing std used by the likelihood grid

    def rssi_at(self, distance_m: float) -> float:
        d = max(float(distance_m), 0.25)
        return self.p0_dbm - 10.0 * self.n * math.log10(d)

    def distance_from(self, rssi_dbm: float) -> float:
        """Invert the model: the ML distance estimate for one RSSI reading."""
        return 10.0 ** ((self.p0_dbm - float(rssi_dbm)) / (10.0 * self.n))


def fit(measurements: Iterable[Tuple[float, float]]) -> PathLossModel:
    """Least-squares fit of (P0, n) from (distance_m, rssi_dbm) pairs.

    Needs at least two distinct distances (three recommended). Raises
    ValueError for degenerate input; the calibrate CLI catches it.
    """
    data = [(float(d), float(r)) for d, r in measurements]
    if len(data) < 2:
        raise ValueError("need at least two (distance, rssi) measurements")
    logs = [math.log10(d) for d, _ in data]
    if max(logs) - min(logs) < 1e-6:
        raise ValueError("need at least two distinct distances")
    n_points = len(data)
    mean_x = sum(logs) / n_points
    mean_y = sum(r for _, r in data) / n_points
    sxx = sum((x - mean_x) ** 2 for x in logs)
    sxy = sum((x - mean_x) * (y - mean_y) for x, (_, y) in zip(logs, data))
    if sxx <= 1e-12:
        raise ValueError("degenerate distance spread")
    slope = sxy / sxx  # dRSSI/dlog10(d) = -10n
    n_exponent = -slope / 10.0
    p0 = mean_y + 10.0 * n_exponent * mean_x
    residuals = [r - (p0 - 10.0 * n_exponent * x) for x, (_, r) in zip(logs, data)]
    sigma = math.sqrt(sum(e * e for e in residuals) / max(len(residuals) - 2, 1))
    if not (1.0 <= n_exponent <= 6.0):
        raise ValueError(
            f"fitted path-loss exponent {n_exponent:.2f} outside the plausible indoor "
            "range [1, 6]; check the calibration measurements"
        )
    return PathLossModel(p0_dbm=round(p0, 2), n=round(n_exponent, 3), sigma_db=round(sigma, 2))


def residual_db(model: PathLossModel, rssi: float, distance_m: float) -> float:
    """Signed residual between a measurement and the model prediction."""
    return float(rssi) - model.rssi_at(distance_m)


def median_rssi(values: Sequence[float]) -> float:
    """Robust aggregate for survey waypoints (median beats mean under fading)."""
    if not values:
        raise ValueError("no rssi values")
    ordered = sorted(float(v) for v in values)
    mid = len(ordered) // 2
    if len(ordered) % 2:
        return ordered[mid]
    return 0.5 * (ordered[mid - 1] + ordered[mid])


def trimmed_mean(values: Sequence[float], trim: float = 0.2) -> float:
    """Symmetric trimmed mean (fallback aggregate, e.g. for very short runs)."""
    if not values:
        raise ValueError("no rssi values")
    ordered = sorted(float(v) for v in values)
    k = int(len(ordered) * trim)
    kept: List[float] = ordered[k : len(ordered) - k] if k else ordered
    return sum(kept) / len(kept)
