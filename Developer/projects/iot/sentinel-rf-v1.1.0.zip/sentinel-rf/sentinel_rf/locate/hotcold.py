"""Hot-cold proximity hunting (Phase 5) - find the device with your feet.

Walk the room with the Pi; the ACT LED (and the console) encodes proximity
to the target device from live RSSI:

  score >= 80   solid LED            (very close)
  60 - 79       fast blink (~8 Hz)
  40 - 59       medium blink (~4 Hz)
  20 - 39       slow blink (~1.5 Hz)
  < 20          faint double-pulse every ~2 s

Safety: the LED is taken over via SysfsLed (trigger saved) and **always
restored**, including on SIGINT/SIGTERM and internal errors. The real
sysfs path is UNVERIFIED on a Pi until evidence lands in
docs/verification-log.md; FakeLed and the console renderer make the whole
flow testable on a laptop.
"""

from __future__ import annotations

import logging
import signal
import threading
import time
from typing import Callable, List, Optional, Tuple

from sentinel_rf.parse.observation import Observation
from sentinel_rf.system.led import Led

__all__ = ["HotColdGuide", "console_blink", "score_from_rssi"]

log = logging.getLogger(__name__)

# (min_score, period_s) - first matching row wins; None period = solid on.
_BLINK_TABLE = (
    (80.0, None),
    (60.0, 0.125),
    (40.0, 0.25),
    (20.0, 0.667),
    (0.0, 2.0),
)

_RSSI_NEAR_DBM = -40.0  # this close -> score 100
_RSSI_FAR_DBM = -85.0  # this far -> score 0


def score_from_rssi(rssi_dbm: float) -> float:
    """Map RSSI to a 0-100 proximity score (linear in dB)."""
    if rssi_dbm >= _RSSI_NEAR_DBM:
        return 100.0
    if rssi_dbm <= _RSSI_FAR_DBM:
        return 0.0
    return 100.0 * (rssi_dbm - _RSSI_FAR_DBM) / (_RSSI_NEAR_DBM - _RSSI_FAR_DBM)


def _period_for(score: float) -> Optional[float]:
    for threshold, period in _BLINK_TABLE:
        if score >= threshold:
            return period
    return 2.0


class HotColdGuide:
    """Drives an LED (and an optional callback) from live RSSI samples."""

    def __init__(
        self,
        led: Optional[Led] = None,
        *,
        window_s: float = 4.0,
        render: Optional[Callable[[float], None]] = None,
        use_signals: bool = False,
    ) -> None:
        self._led = led
        self._render = render
        self._window_s = float(window_s)
        self._samples: List[Tuple[float, float]] = []  # (ts, rssi)
        self._lock = threading.Lock()
        self._stop = threading.Event()
        self._thread: Optional[threading.Thread] = None
        self._signal_handlers_installed = False
        self.latest_score: float = 0.0
        if use_signals:
            self._install_signal_handlers()

    # -- ingestion -------------------------------------------------------- #

    def update(self, obs_or_rssi, ts: Optional[float] = None) -> float:
        """Feed one observation (or bare RSSI); returns the current score."""
        rssi = obs_or_rssi.rssi_dbm if isinstance(obs_or_rssi, Observation) else float(obs_or_rssi)
        t = ts if ts is not None else time.time()
        with self._lock:
            self._samples.append((t, rssi))
            cutoff = t - self._window_s
            self._samples = [s for s in self._samples if s[0] >= cutoff]
            recent = [r for _, r in self._samples]
        # Median of the recent window: robust to single-frame fades.
        recent.sort()
        mid = len(recent) // 2
        median_rssi = recent[mid] if len(recent) % 2 else 0.5 * (recent[mid - 1] + recent[mid])
        self.latest_score = score_from_rssi(median_rssi)
        return self.latest_score

    @property
    def score(self) -> float:
        return self.latest_score

    # -- LED thread -------------------------------------------------------- #

    def start(self) -> None:
        if self._thread is not None:
            return
        if self._led is not None:
            try:
                self._led.open()
            except Exception as exc:  # LED failure must not kill the hunt
                log.warning("LED unavailable (%s); continuing with console output", exc)
                self._led = None
        self._stop.clear()
        self._thread = threading.Thread(target=self._run, name="sentinel-hotcold", daemon=True)
        self._thread.start()

    def stop(self) -> None:
        self._stop.set()
        if self._thread is not None:
            self._thread.join(timeout=3.0)
            self._thread = None
        if self._led is not None:
            self._led.close()

    def _run(self) -> None:
        while not self._stop.is_set():
            period = _period_for(self.latest_score)
            if self._render is not None:
                try:
                    self._render(self.latest_score)
                except Exception:  # pragma: no cover - defensive
                    log.exception("hot-cold render callback failed")
            if self._led is None:
                self._stop.wait(0.25)
                continue
            if period is None:
                self._led.on()
                if self._stop.wait(0.25):
                    break
            else:
                self._led.on()
                if self._stop.wait(period / 2.0):
                    break
                self._led.off()
                if self._stop.wait(period / 2.0):
                    break

    # -- signals ------------------------------------------------------------ #

    def _install_signal_handlers(self) -> None:
        if self._signal_handlers_installed:
            return
        for sig in (signal.SIGINT, signal.SIGTERM):
            try:
                previous = signal.getsignal(sig)

                def handler(signum, frame, _previous=previous):  # noqa: ANN001
                    self.stop()
                    if callable(_previous):
                        _previous(signum, frame)
                    raise SystemExit(0)

                signal.signal(sig, handler)
            except ValueError:  # not on the main thread
                log.debug("cannot install %s handler off the main thread", sig)
        self._signal_handlers_installed = True

    def __enter__(self) -> "HotColdGuide":
        self.start()
        return self

    def __exit__(self, *exc: object) -> None:
        self.stop()


def console_blink(score: float) -> None:
    """Console fallback renderer: a bar of 'O' characters (no ANSI escapes)."""
    width = 24
    filled = int(round(score / 100.0 * width))
    print(f"\rproximity [{ '#' * filled}{ '.' * (width - filled)}] {score:5.1f}", end="")
