"""Weighted least-squares multilateration (Phase 5) - the secondary estimator.

Solves for (x, y) such that modelled distances match RSSI-derived ranges:
``minimize sum_i w_i * (d_i(x, y) - range_i)^2`` with soft-L1 loss (robust
to one bad anchor) and distances weighted 1/d (a 3 dB error at 10 m is a
much bigger range error than at 1 m). Seeded from the room centre and
bounded by the room. The likelihood grid is the primary estimator; WLS is
the cross-check - when they disagree strongly, the measurement set is
untrustworthy (both results carry their own residuals to make that visible).
"""

from __future__ import annotations

from typing import Dict, Tuple

from sentinel_rf.locate.anchors import RoomProfile
from sentinel_rf.locate.grid import LocationEstimate

__all__ = ["wls_estimate"]


def _require_scipy():
    try:
        from scipy.optimize import least_squares
    except ImportError as exc:  # pragma: no cover - environment-dependent
        raise ImportError(
            "scipy is required for WLS multilateration; "
            "install with: pip install -e '.[locate]' (or '.[all]')"
        ) from exc
    return least_squares


def wls_estimate(
    measurements: Dict[str, float],
    profile: RoomProfile,
    *,
    x0: Tuple[float, float] = None,
) -> LocationEstimate:
    """Estimate (x, y) from {node_id: rssi_dbm} via robust weighted least squares."""
    least_squares = _require_scipy()
    pairs = []
    for node_id, rssi in measurements.items():
        anchor = profile.anchors.get(node_id)
        if anchor is not None:
            pairs.append((anchor, float(rssi)))
    if len(pairs) < 2:
        raise ValueError("WLS needs measurements from at least two anchors")

    model = profile.pathloss
    ranges = [model.distance_from(rssi) for _, rssi in pairs]
    anchors_xy = [(a.x, a.y) for a, _ in pairs]
    weights = [1.0 / max(r, 0.5) for r in ranges]

    if x0 is None:
        x0 = (profile.width_m / 2.0, profile.height_m / 2.0)

    def residuals(p):
        x, y = p
        out = []
        for (ax, ay), rng, w in zip(anchors_xy, ranges, weights):
            modelled = ((x - ax) ** 2 + (y - ay) ** 2) ** 0.5
            out.append(w * (modelled - rng))
        return out

    result = least_squares(
        residuals,
        x0=list(x0),
        bounds=([0.0, 0.0], [profile.width_m, profile.height_m]),
        loss="cauchy",
        f_scale=0.5,
    )
    x, y = float(result.x[0]), float(result.x[1])
    residuals_db = tuple(
        round(rssi - model.rssi_at(((x - a.x) ** 2 + (y - a.y) ** 2) ** 0.5), 2)
        for a, rssi in pairs
    )
    return LocationEstimate(
        x=x,
        y=y,
        sigma_m=float((result.cost * 2) ** 0.5 / max(len(pairs), 1)),
        method="wls",
        node_ids=tuple(a.node_id for a, _ in pairs),
        residuals_db=residuals_db,
    )
