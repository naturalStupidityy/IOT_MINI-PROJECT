"""Privacy boundary: raw MAC addresses must never reach storage or export.

HARD RULE 3: full MACs may exist only in live in-memory state and on the
local dashboard when explicitly enabled. This module provides the detector
used at every store/export boundary; the Phase-0 acceptance test proves
that observations carrying a live raw_addr are stored without it.

The detector flags separator-form MACs ("aa:bb:cc:dd:ee:ff" or dash form).
Salted hashes are bare hex without separators, so they never trigger it
(DECISIONS.md D014). This fails closed: a suspicious-looking string is
rejected even if it might be innocent.
"""

from __future__ import annotations

import re
from typing import Any, Mapping

__all__ = [
    "PrivacyViolation",
    "assert_no_raw_mac",
    "is_locally_administered",
    "looks_like_raw_mac",
]


class PrivacyViolation(RuntimeError):
    """A raw MAC address (or raw-address field) reached a privacy boundary."""


_RAW_MAC_COLON_RE = re.compile(r"[0-9A-Fa-f]{2}(?::[0-9A-Fa-f]{2}){5}")
_RAW_MAC_DASH_RE = re.compile(r"[0-9A-Fa-f]{2}(?:-[0-9A-Fa-f]{2}){5}")

# Any payload field literally named like a raw address is refused outright,
# whatever its value: address fields must be hashes (addr_hash, bssid_hash).
_FORBIDDEN_KEYS = frozenset({"raw_addr", "raw", "raw_mac", "mac"})


def looks_like_raw_mac(value: str) -> bool:
    """True if *value* contains a separator-form MAC address.

    Bare 12-hex-char strings are ambiguous by design and are NOT flagged:
    internally, raw addresses always keep their ':' separators while live,
    while hashes are >= 16 bare hex chars (DECISIONS.md D014).
    """
    if not isinstance(value, str):
        return False
    return bool(_RAW_MAC_COLON_RE.search(value) or _RAW_MAC_DASH_RE.search(value))


def is_locally_administered(mac: str) -> bool:
    """True if the MAC's locally-administered bit is set (randomized MAC).

    Phones and laptops randomize; hidden cameras normally keep their fixed
    factory MAC, so this bit feeds the priors evidence layer (Phase 3/4).
    """
    bare = mac.strip().lower().replace(":", "").replace("-", "")
    if len(bare) != 12 or any(c not in "0123456789abcdef" for c in bare):
        raise ValueError(f"not a MAC address: {mac!r}")
    return bool(int(bare[0:2], 16) & 0x02)


def assert_no_raw_mac(payload: Any, *, where: str) -> None:
    """Raise PrivacyViolation if *payload* carries a raw MAC or raw-address key.

    Keys are checked against the forbidden set; every string value is scanned
    with looks_like_raw_mac(), RECURSIVELY through nested mappings and lists
    (a MAC hidden in a nested structure is still a leak). Call this at every
    boundary where data leaves live memory: store, MQTT publish, file export,
    cloud telemetry.
    """
    if isinstance(payload, Mapping):
        for key, value in payload.items():
            key_name = str(key).lower()
            if key_name in _FORBIDDEN_KEYS:
                raise PrivacyViolation(f"{where}: forbidden raw-address key {key!r}")
            assert_no_raw_mac(value, where=where)
    elif isinstance(payload, (list, tuple, set, frozenset)):
        for item in payload:
            assert_no_raw_mac(item, where=where)
    elif isinstance(payload, str) and looks_like_raw_mac(payload):
        raise PrivacyViolation(f"{where}: string value looks like a raw MAC")
