"""Programmatic default configuration, kept in sync with configs/default.yaml.

The dataclass defaults ARE the defaults; tests/test_config.py fails when the
YAML file and this construction drift apart.
"""

from __future__ import annotations

from sentinel_rf.config import SentinelConfig

__all__ = ["default_config"]


def default_config() -> SentinelConfig:
    """Return the default configuration (equal to configs/default.yaml)."""
    return SentinelConfig()
