"""Detection engine (Phase 4): per-device evaluation + alert emission.

Once per detection interval the pipeline calls :meth:`Detector.process`
with the current tracker snapshot. For every device with enough history
the engine:

  1. computes the feature vector,
  2. scores the four evidence components (priors, traffic, stimulus, BLE),
  3. fuses them into one 0-100 score with plain-English reasons,
  4. emits an alert when the band is 'likely' (respecting a cooldown and
     an escalation rule: a 10+ point jump re-alerts immediately).

Every score - not just alerts - is retained in a bounded history so the
dashboard can plot score timelines.
"""

from __future__ import annotations

import itertools
import logging
import threading
import time
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Tuple

from sentinel_rf.config import SentinelConfig
from sentinel_rf.detect.fusion import BAND_LIKELY, ComponentResult, fuse
from sentinel_rf.detect.model import TrafficModel
from sentinel_rf.detect.rules import PriorsEngine, TrafficRules
from sentinel_rf.detect.stimulus import StimulusTracker, verdict_to_component
from sentinel_rf.features.stats import compute_features
from sentinel_rf.features.windows import DeviceTracker
from sentinel_rf.intel.ble_rules import BleRuleBook
from sentinel_rf.intel.cache import IntelCache
from sentinel_rf.parse.observation import Source

__all__ = ["Alert", "DeviceScore", "Detector"]

log = logging.getLogger(__name__)

_ALERT_ID = itertools.count(1)


@dataclass(frozen=True)
class DeviceScore:
    """One evaluation of one device (all bands, not only alerts)."""

    addr_hash: str
    ts: float
    score: float
    band: str
    reasons: List[str] = field(default_factory=list)
    contributions: List[Tuple[str, float]] = field(default_factory=list)
    features: Dict[str, float] = field(default_factory=dict)
    components: Dict[str, ComponentResult] = field(default_factory=dict)

    def to_dict(self) -> Dict:
        return {
            "addr_hash": self.addr_hash,
            "ts": self.ts,
            "score": self.score,
            "band": self.band,
            "reasons": self.reasons,
            "contributions": self.contributions,
            "features": {k: round(v, 3) for k, v in self.features.items()},
            "components": {k: c.score for k, c in self.components.items() if c.available},
        }


@dataclass(frozen=True)
class Alert(DeviceScore):
    """A 'likely' verdict that crossed the alerting threshold."""

    alert_id: int = 0
    escalated: bool = False

    def to_dict(self) -> Dict:
        payload = super().to_dict()
        payload.update({"alert_id": self.alert_id, "escalated": self.escalated})
        return payload


class Detector:
    """Fuses evidence per device and manages alert state."""

    def __init__(
        self,
        config: SentinelConfig,
        *,
        priors: PriorsEngine,
        traffic_rules: Optional[TrafficRules] = None,
        model: Optional[TrafficModel] = None,
        ble_rules: Optional[BleRuleBook] = None,
        stimulus_tracker: Optional[StimulusTracker] = None,
        min_frames: int = 50,
        cooldown_s: float = 120.0,
    ) -> None:
        self.config = config
        self.priors = priors
        self.traffic_rules = traffic_rules or TrafficRules()
        self.model = model
        self.ble_rules = ble_rules
        self.stimulus = stimulus_tracker
        self.min_frames = int(min_frames)
        self.cooldown_s = float(cooldown_s)
        self._lock = threading.Lock()
        self._last_alert_ts: Dict[str, float] = {}
        self._last_alert_score: Dict[str, float] = {}
        self.score_history: Dict[str, List[Tuple[float, float]]] = {}
        self.alerts: List[Alert] = []
        self.latest: Dict[str, DeviceScore] = {}

    # ------------------------------------------------------------------ #

    def evaluate(
        self,
        addr_hash: str,
        tracker: DeviceTracker,
        intel: IntelCache,
        now: float,
        *,
        window=None,
    ) -> DeviceScore:
        """Score one device right now (also used directly by tests/reports)."""
        device_window = window if window is not None else tracker.window(addr_hash, now)
        features = (
            compute_features(device_window)
            if device_window is not None
            else {name: 0.0 for name in ("n_frames",)}
        )
        device_intel = intel.get(addr_hash)
        components: Dict[str, ComponentResult] = {}

        components["priors"] = self.priors.score(features, device_intel)

        if device_window is not None and features.get("n_frames", 0.0) >= self.min_frames:
            rule_result = self.traffic_rules.score(features)
            if self.model is not None:
                p = self.model.predict_proba_camera(features)
                blended = 0.5 * rule_result.score + 0.5 * (100.0 * p)
                reasons = list(rule_result.reasons)
                if p >= 0.5:
                    reasons.append(f"ML traffic classifier: {p:.0%} camera-like profile")
                for name, push in self.model.contributions(features, top=3):
                    direction = "high" if push > 0 else "low"
                    reasons.append(f"ML evidence: unusually {direction} {name}")
                components["traffic"] = ComponentResult(
                    name="traffic",
                    available=True,
                    score=round(min(blended, 100.0), 1),
                    reasons=reasons,
                )
            else:
                components["traffic"] = rule_result
        else:
            components["traffic"] = ComponentResult.unavailable(
                "traffic",
                f"only {int(features.get('n_frames', 0.0))} frames in the window; "
                f"need {self.min_frames} before traffic evidence counts",
            )

        if self.stimulus is not None and self.stimulus.session.phase.value == "done":
            result = self.stimulus.analyze(addr_hash)
            components["stimulus"] = verdict_to_component(result)
        else:
            components["stimulus"] = ComponentResult.unavailable(
                "stimulus", "No stimulus test performed in this session"
            )

        if self.ble_rules is not None and device_window is not None:
            ble_obs = [o for o in device_window.long if o.source is Source.BLE]
            if ble_obs:
                newest = ble_obs[-1]
                ble_result = self.ble_rules.score(
                    name=newest.name,
                    service_uuids=newest.service_uuids,
                    company_id=newest.company_id,
                    addr_is_random=newest.addr_is_random,
                )
                components["ble"] = ComponentResult(
                    name="ble",
                    available=True,
                    score=ble_result.score,
                    reasons=ble_result.reasons
                    or ["Device also advertises over BLE (no watchlist match)"],
                )
            else:
                components["ble"] = ComponentResult.unavailable(
                    "ble", "No BLE advertisements from this device"
                )
        else:
            components["ble"] = ComponentResult.unavailable("ble", "BLE layer not active")

        fusion = fuse(components, self.config.detect)
        return DeviceScore(
            addr_hash=addr_hash,
            ts=now,
            score=fusion.score,
            band=fusion.band,
            reasons=fusion.reasons,
            contributions=fusion.contributions,
            features=features,
            components=components,
        )

    # ------------------------------------------------------------------ #

    def process(
        self,
        tracker: DeviceTracker,
        intel: IntelCache,
        now: Optional[float] = None,
    ) -> List[Alert]:
        """Evaluate every tracked device; return alerts raised this round."""
        t_now = now if now is not None else time.time()
        raised: List[Alert] = []
        with self._lock:
            self.score_history = {}
        for addr_hash, window in tracker.snapshot(t_now).items():
            score = self.evaluate(addr_hash, tracker, intel, t_now, window=window)
            with self._lock:
                self.latest[addr_hash] = score
                history = self.score_history.setdefault(addr_hash, [])
                history.append((t_now, score.score))
                if len(history) > 600:
                    del history[: len(history) - 600]
                if score.band == BAND_LIKELY and self._should_alert(addr_hash, score.score, t_now):
                    alert = Alert(
                        **{
                            f.name: getattr(score, f.name)
                            for f in score.__dataclass_fields__.values()  # type: ignore[attr-defined]
                        },
                        alert_id=next(_ALERT_ID),
                        escalated=self._is_escalation(addr_hash, score.score),
                    )
                    self.alerts.append(alert)
                    if len(self.alerts) > 500:
                        del self.alerts[: len(self.alerts) - 500]
                    self._last_alert_ts[addr_hash] = t_now
                    self._last_alert_score[addr_hash] = score.score
                    raised.append(alert)
        return raised

    def _should_alert(self, addr_hash: str, score: float, now: float) -> bool:
        last = self._last_alert_ts.get(addr_hash)
        if last is None:
            return True
        if now - last >= self.cooldown_s:
            return True
        return score >= self._last_alert_score.get(addr_hash, 0.0) + 10.0

    def _is_escalation(self, addr_hash: str, score: float) -> bool:
        return (
            addr_hash in self._last_alert_score
            and score >= self._last_alert_score.get(addr_hash, 0.0) + 10.0
        )
