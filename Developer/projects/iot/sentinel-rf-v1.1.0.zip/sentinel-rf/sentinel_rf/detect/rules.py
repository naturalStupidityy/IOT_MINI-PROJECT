"""Priors and traffic rule baselines (Phase 4) - explainable evidence.

Two rule engines, both pure functions of (features, intel):

* :class:`PriorsEngine` - vendor/SSID/address-randomization priors from the
  intel cache (fusion weight 15 by default).
* :class:`TrafficRules` - hand-written traffic fingerprint: uplink-dominant,
  QoS-marked, steady, keyframe-periodic traffic looks like a video uplink;
  management-heavy traffic looks like an access point. Blended with the ML
  classifier by the traffic scorer (model.py) and fully explainable on its
  own - every point earned comes with a plain-English reason.
"""

from __future__ import annotations

from typing import Dict, List, Optional

from sentinel_rf.detect.fusion import ComponentResult
from sentinel_rf.intel.ble_rules import BleRuleBook
from sentinel_rf.intel.cache import DeviceIntel
from sentinel_rf.intel.oui import CATEGORY_SCORES
from sentinel_rf.intel.ssid_rules import SsidRuleBook

__all__ = ["PriorsEngine", "TrafficRules"]


class PriorsEngine:
    """Watchlist/vendor/address priors (weight 15/100 by default)."""

    def __init__(self, ssid_rules: SsidRuleBook, ble_rules: BleRuleBook) -> None:
        self._ssid_rules = ssid_rules
        self._ble_rules = ble_rules

    def score(
        self,
        features: Dict[str, float],
        intel: DeviceIntel,
        *,
        vendor_category: Optional[str] = None,
    ) -> ComponentResult:
        reasons: List[str] = []
        score = 0.0

        category = vendor_category or intel.vendor_category
        if category:
            prior = CATEGORY_SCORES.get(category, 0.0)
            if prior > 0:
                score += prior * 45.0
                strength = "strong" if prior >= 1.0 else "weak"
                reasons.append(
                    f"MAC vendor is {intel.vendor or category} - {strength} prior for "
                    "camera hardware (a prior, not proof)"
                )

        if intel.ssid:
            ssid_result = self._ssid_rules.score(intel.ssid)
            if ssid_result.score > 0:
                score += ssid_result.score
                reasons.extend(ssid_result.reasons)

        # Stationary factory-addressed devices are slightly more suspicious
        # than randomized ones (phones randomize; cameras usually cannot).
        if (
            features.get("role_ap", 0.0) < 0.5
            and features.get("is_ble", 0.0) == 0.0
            and intel.ble_name
        ):
            ble_result = self._ble_rules.score(
                name=intel.ble_name,
                service_uuids=(),
                company_id=None,
                addr_is_random=False,
            )
            if ble_result.score > 0:
                score += min(ble_result.score, 30.0)
                reasons.extend(ble_result.reasons)

        if features.get("role_ap", 0.0) >= 0.5:
            reasons.append(
                "Device behaves as an access point (beaconing) - priors for a camera "
                "hotspot, not a hidden client"
            )

        return ComponentResult(
            name="priors",
            available=True,
            score=round(min(score, 100.0), 1),
            reasons=reasons,
        )


class TrafficRules:
    """Hand-written traffic fingerprint (explainable baseline for ML).

    Rewards the camera *shape* (uplink-dominant, QoS-marked, keyframe-
    periodic, steady pacing) and - just as important - penalises the
    look-alike that is NOT a camera: a saturated bulk transfer (near-link
    rate, MTU-filling frames, no QoS, no periodicity).
    """

    def score(self, features: Dict[str, float]) -> ComponentResult:
        reasons: List[str] = []
        score = 0.0

        if features.get("role_ap", 0.0) >= 0.5 or features.get("data_ratio", 0.0) < 0.2:
            return ComponentResult(
                name="traffic",
                available=True,
                score=0.0,
                reasons=[
                    "Traffic profile is management-heavy (an access point or idle device), "
                    "not a video stream"
                ],
            )

        def add(points: float, reason: str) -> None:
            nonlocal score
            score += points
            reasons.append(reason)

        if features.get("uplink_share", 0.0) >= 0.70:
            add(15, "Traffic flows mostly upstream (device -> network), like video upload")
        if features.get("qos_share", 0.0) >= 0.50:
            add(15, "QoS-marked data frames, typical of video streams")
        bps = features.get("bytes_per_s", 0.0)
        if bps >= 50_000.0:
            add(10, f"Sustained upload of {bps / 1000:.0f} kB/s is video-sized")
        if features.get("burst_periodicity", 0.0) >= 0.35:
            add(15, "Periodic traffic bursts consistent with video keyframes")
        if features.get("mean_frame_size", 0.0) >= 600.0:
            add(5, "Large average frame size, like encoded video")
        if features.get("retry_rate", 0.0) >= 0.05:
            add(5, "Retransmissions suggest a contended uplink")
        if features.get("duty_cycle", 0.0) >= 0.90:
            add(5, "Continuous channel usage")
        if (
            features.get("iat_cv", 1.0) < 0.30
            and features.get("frames_per_s", 0.0) > 10.0
            and features.get("uplink_share", 0.0) > 0.5
        ):
            add(5, "Steady, paced transmission - encoder-like timing")

        # Negative evidence: the classic false positive is a bulk upload.
        if bps > 400_000.0 and features.get("qos_share", 0.0) < 0.3:
            add(-10, "Near-saturation rate without QoS looks like a bulk transfer, not a camera")
        if (
            features.get("mean_frame_size", 0.0) > 1200.0
            and features.get("p90_frame_size", 0.0) >= 1490.0
        ):
            add(-5, "MTU-filling frames are typical of file transfers; video encoders vary more")

        return ComponentResult(
            name="traffic",
            available=True,
            score=round(max(min(score, 100.0), 0.0), 1),
            reasons=reasons,
        )
