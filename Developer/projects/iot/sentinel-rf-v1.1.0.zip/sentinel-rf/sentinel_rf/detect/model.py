"""Traffic-profile classifier (Phase 4): RandomForest + model card.

The ML half of the traffic component (fusion weight 35). Trained on the
deterministic simulator's labelled environments (Phase 1), evaluated with
leave-one-device-out cross validation so no device appears in both train
and test folds. Persisted with joblib next to a YAML **model card**
describing data provenance, hyperparameters, feature list and CV metrics -
a model without provenance is not shippable (course quality bar).

scikit-learn is an optional extra (`pip install -e '.[ml]'`): importing
this module without it raises a helpful error, and the pipeline falls back
to the explainable rule baseline alone.
"""

from __future__ import annotations

import logging
from pathlib import Path
from typing import Dict, List, Optional, Sequence, Tuple

import numpy as np

from sentinel_rf.features.stats import FEATURE_NAMES

__all__ = [
    "FEATURE_PLAINTEXT",
    "ModelCard",
    "TrafficModel",
    "lodo_cross_validate",
    "require_sklearn",
]

log = logging.getLogger(__name__)

FEATURE_PLAINTEXT: Dict[str, str] = {
    "frames_per_s": "frame rate",
    "bytes_per_s": "upload rate",
    "uplink_share": "uplink-dominant traffic",
    "data_ratio": "data (vs management) frames",
    "qos_share": "QoS-marked video priority",
    "retry_rate": "retransmissions",
    "mean_frame_size": "average frame size",
    "p90_frame_size": "large-frame tail",
    "large_frame_share": "video-sized frames",
    "iat_mean_ms": "inter-frame spacing",
    "iat_cv": "transmission regularity",
    "duty_cycle": "channel occupancy",
    "burst_periodicity": "keyframe-like burst periodicity",
    "mean_rate_mbps": "PHY rate",
    "rssi_mean": "signal strength",
    "rssi_var": "signal stability",
    "rssi_drift_db_min": "signal drift",
    "channel_changes": "channel hopping",
    "is_ble": "BLE source",
    "ble_adv_rate": "BLE advertisement rate",
    "ble_named": "BLE local name present",
    "role_ap": "acting as access point",
    "n_frames": "frames observed",
}


def require_sklearn():
    """Import and return sklearn modules or raise a helpful error."""
    try:
        from sklearn.ensemble import RandomForestClassifier
        from sklearn.metrics import (
            accuracy_score,
            f1_score,
            precision_score,
            recall_score,
            roc_auc_score,
        )
        from sklearn.model_selection import LeaveOneGroupOut
    except ImportError as exc:  # pragma: no cover - environment-dependent
        raise ImportError(
            "scikit-learn is required for the ML traffic classifier; "
            "install with: pip install -e '.[ml]' (or '.[all]')"
        ) from exc
    return {
        "RandomForestClassifier": RandomForestClassifier,
        "LeaveOneGroupOut": LeaveOneGroupOut,
        "accuracy_score": accuracy_score,
        "precision_score": precision_score,
        "recall_score": recall_score,
        "f1_score": f1_score,
        "roc_auc_score": roc_auc_score,
    }


class ModelCard:
    """YAML-serializable provenance record for a trained model."""

    def __init__(
        self,
        *,
        model_type: str,
        feature_names: Sequence[str],
        hyperparameters: Dict,
        dataset: Dict,
        metrics: Dict,
        notes: str = "",
    ) -> None:
        self.model_type = model_type
        self.feature_names = list(feature_names)
        self.hyperparameters = dict(hyperparameters)
        self.dataset = dict(dataset)
        self.metrics = dict(metrics)
        self.notes = notes

    def to_dict(self) -> Dict:
        return {
            "model_type": self.model_type,
            "feature_names": self.feature_names,
            "hyperparameters": self.hyperparameters,
            "dataset": self.dataset,
            "metrics": self.metrics,
            "notes": self.notes,
        }

    @classmethod
    def from_dict(cls, data: Dict) -> "ModelCard":
        return cls(
            model_type=data["model_type"],
            feature_names=data["feature_names"],
            hyperparameters=data.get("hyperparameters", {}),
            dataset=data.get("dataset", {}),
            metrics=data.get("metrics", {}),
            notes=data.get("notes", ""),
        )

    def save(self, path) -> None:
        import yaml

        Path(path).parent.mkdir(parents=True, exist_ok=True)
        Path(path).write_text(
            yaml.safe_dump(self.to_dict(), sort_keys=False, allow_unicode=True),
            encoding="utf-8",
        )

    @classmethod
    def load(cls, path) -> "ModelCard":
        import yaml

        return cls.from_dict(yaml.safe_load(Path(path).read_text(encoding="utf-8")))


class TrafficModel:
    """RandomForest traffic classifier with per-sample contribution analysis."""

    def __init__(self, estimator, card: ModelCard, train_means=None, train_stds=None) -> None:
        self.estimator = estimator
        self.card = card
        self._means = np.asarray(
            train_means if train_means is not None else [0.0] * len(FEATURE_NAMES)
        )
        self._stds = np.asarray(
            train_stds if train_stds is not None else [1.0] * len(FEATURE_NAMES)
        )

    # ------------------------------------------------------------------ #

    @classmethod
    def train(
        cls,
        X: np.ndarray,
        y: np.ndarray,
        *,
        seed: int = 42,
        n_estimators: int = 300,
        min_samples_leaf: int = 3,
        dataset_info: Optional[Dict] = None,
    ) -> "TrafficModel":
        sk = require_sklearn()
        estimator = sk["RandomForestClassifier"](
            n_estimators=n_estimators,
            min_samples_leaf=min_samples_leaf,
            class_weight="balanced",
            random_state=seed,
            n_jobs=-1,
        )
        estimator.fit(X, y)
        card = ModelCard(
            model_type="RandomForestClassifier",
            feature_names=list(FEATURE_NAMES),
            hyperparameters={
                "n_estimators": n_estimators,
                "min_samples_leaf": min_samples_leaf,
                "class_weight": "balanced",
                "random_state": seed,
            },
            dataset=dataset_info or {},
            metrics={},
            notes=(
                "Trained on the deterministic RF simulator (Phase 1) - synthetic data; "
                "field performance must be re-validated on real captures before any "
                "operational claim (see docs/REPORT.md, Limitations)."
            ),
        )
        return cls(
            estimator,
            card,
            train_means=X.mean(axis=0),
            train_stds=np.where(X.std(axis=0) > 1e-9, X.std(axis=0), 1.0),
        )

    # ------------------------------------------------------------------ #

    def predict_proba_camera(self, features: Dict[str, float]) -> float:
        x = np.array([[features[name] for name in FEATURE_NAMES]], dtype=float)
        proba = self.estimator.predict_proba(x)[0]
        classes = list(self.estimator.classes_)
        if 1 in classes:
            return float(proba[classes.index(1)])
        return 0.0

    def contributions(self, features: Dict[str, float], top: int = 4) -> List[Tuple[str, float]]:
        """Approximate per-feature push toward 'camera' for one sample.

        Uses the forest's global importances scaled by the sample's
        standardized deviation from the training mean: a feature the model
        finds important AND that is unusual for this device pushes hard.
        """
        x = np.array([features[name] for name in FEATURE_NAMES], dtype=float)
        z = np.clip((x - self._means) / self._stds, -3.0, 3.0)
        importances = np.asarray(self.estimator.feature_importances_)
        push = importances * z
        order = np.argsort(-np.abs(push))[:top]
        out = []
        for idx in order:
            if abs(push[idx]) < 1e-4:
                continue
            out.append(
                (FEATURE_PLAINTEXT.get(FEATURE_NAMES[idx], FEATURE_NAMES[idx]), float(push[idx]))
            )
        return out

    # ------------------------------------------------------------------ #

    def save(self, model_path, card_path) -> None:
        import joblib

        Path(model_path).parent.mkdir(parents=True, exist_ok=True)
        joblib.dump(
            {
                "estimator": self.estimator,
                "card": self.card.to_dict(),
                "train_means": self._means,
                "train_stds": self._stds,
                "feature_names": list(FEATURE_NAMES),
            },
            model_path,
        )
        self.card.save(card_path)

    @classmethod
    def load(cls, model_path) -> "TrafficModel":
        import joblib

        blob = joblib.load(model_path)
        if list(blob["feature_names"]) != list(FEATURE_NAMES):
            raise ValueError(
                "model was trained with a different feature vocabulary; retrain with "
                "`sentinel train`"
            )
        return cls(
            blob["estimator"],
            ModelCard.from_dict(blob["card"]),
            train_means=blob["train_means"],
            train_stds=blob["train_stds"],
        )


def lodo_cross_validate(
    X: np.ndarray,
    y: np.ndarray,
    groups: np.ndarray,
    *,
    seed: int = 42,
) -> Dict[str, float]:
    """Leave-one-device-out CV: no device is ever in train and test together."""
    sk = require_sklearn()
    logo = sk["LeaveOneGroupOut"]()
    y_true_all, y_prob_all, y_pred_all = [], [], []
    for train_idx, test_idx in logo.split(X, y, groups):
        estimator = sk["RandomForestClassifier"](
            n_estimators=200,
            min_samples_leaf=3,
            class_weight="balanced",
            random_state=seed,
            n_jobs=-1,
        )
        estimator.fit(X[train_idx], y[train_idx])
        proba = estimator.predict_proba(X[test_idx])[:, 1]
        y_prob_all.extend(proba.tolist())
        y_pred_all.extend((proba >= 0.5).astype(int).tolist())
        y_true_all.extend(y[test_idx].tolist())
    y_true = np.array(y_true_all)
    y_pred = np.array(y_pred_all)
    y_prob = np.array(y_prob_all)
    metrics = {
        "accuracy": round(float(sk["accuracy_score"](y_true, y_pred)), 4),
        "precision": round(float(sk["precision_score"](y_true, y_pred, zero_division=0)), 4),
        "recall": round(float(sk["recall_score"](y_true, y_pred, zero_division=0)), 4),
        "f1": round(float(sk["f1_score"](y_true, y_pred, zero_division=0)), 4),
        "roc_auc": (
            round(float(sk["roc_auc_score"](y_true, y_prob)), 4)
            if len(np.unique(y_true)) == 2
            else None
        ),
        "n_samples": int(len(y_true)),
        "n_devices": int(len(np.unique(groups))),
    }
    return metrics
