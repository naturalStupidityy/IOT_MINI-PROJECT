"""Stimulus-response correlation (Phase 4) - the strongest evidence layer.

Protocol (CLI/dashboard-guided): with the sensor running, the operator
records a still-room **baseline**, then alternates a strong scene stimulus
(light on/off or large motion in front of each suspected device) for the
stimulus window, marking each on/off transition. A streaming camera's
encoder bitrate tracks what it sees, so its frame/byte rate follows the
stimulus with a small lag; unrelated devices do not.

Statistics per device:
  1. per-second frame-count (and byte) series over the session
  2. Pearson r against the 0/1 stimulus vector, maximised over lags
     -lag_search..+lag_search seconds
  3. significance via a permutation test (shuffled stimulus vectors),
     using the same max-over-lags statistic so the p-value is corrected for
     the 11-way lag search

HARD RULE 7 (encoded in the verdicts): a missing response is INCONCLUSIVE,
never evidence of innocence. Only 'responsive'/'weak' contribute evidence;
everything else makes the component unavailable with an explicit note.
"""

from __future__ import annotations

import math
import threading
import time
from dataclasses import dataclass, field
from enum import Enum
from typing import Dict, List, Optional, Tuple

import numpy as np

from sentinel_rf.config import StimulusConfig
from sentinel_rf.parse.observation import Observation

__all__ = [
    "StimulusResult",
    "StimulusSession",
    "StimulusTracker",
    "correlate",
    "verdict_to_component",
]


class Phase(Enum):
    IDLE = "idle"
    BASELINE = "baseline"
    ARMED = "armed"
    STIMULUS = "stimulus"
    DONE = "done"


@dataclass
class StimulusSession:
    """State machine for one stimulus experiment (wall-clock timestamps)."""

    config: StimulusConfig = field(default_factory=StimulusConfig)
    phase: Phase = Phase.IDLE
    started_at: Optional[float] = None
    marks: List[Tuple[float, bool]] = field(default_factory=list)  # (ts, on)

    def start(self, ts: Optional[float] = None) -> None:
        if self.phase is not Phase.IDLE:
            raise RuntimeError(f"stimulus session already {self.phase.value}")
        self.started_at = ts if ts is not None else time.time()
        self.marks = []
        self.phase = Phase.BASELINE

    def _now(self, ts: Optional[float]) -> float:
        return ts if ts is not None else time.time()

    def mark(self, on: bool, ts: Optional[float] = None) -> None:
        t = self._now(ts)
        if self.phase in (Phase.IDLE, Phase.DONE):
            raise RuntimeError(
                f"stimulus session is {self.phase.value}; call start() first"
                if self.phase is Phase.IDLE
                else "stimulus session already ended"
            )
        if self.phase is Phase.BASELINE:
            start = self.started_at if self.started_at is not None else t
            elapsed = t - start
            if elapsed < self.config.baseline_s:
                raise RuntimeError(
                    f"baseline still running ({elapsed:.0f}/{self.config.baseline_s} s); "
                    "wait before the first stimulus mark"
                )
            self.phase = Phase.ARMED
        if self.phase is not Phase.DONE:
            self.marks.append((t, bool(on)))
            self.phase = Phase.STIMULUS

    def end(self, ts: Optional[float] = None) -> None:
        if self.phase in (Phase.STIMULUS, Phase.ARMED, Phase.BASELINE):
            self.phase = Phase.DONE

    @property
    def window(self) -> Tuple[Optional[float], Optional[float]]:
        """(start, end) of the analysis window (baseline start to last mark)."""
        if self.started_at is None:
            return None, None
        end = max((t for t, _ in self.marks), default=None)
        if end is None:
            return self.started_at, None
        return self.started_at, end

    def stimulus_vector(self, t_start: float, n_bins: int, bin_s: float = 1.0) -> np.ndarray:
        """0/1 vector of the stimulus state over n_bins from t_start."""
        vector = np.zeros(n_bins, dtype=float)
        state = False
        edge = sorted(self.marks)
        idx = 0
        for i in range(n_bins):
            t = t_start + i * bin_s
            while idx < len(edge) and edge[idx][0] <= t:
                state = edge[idx][1]
                idx += 1
            vector[i] = 1.0 if state else 0.0
        return vector

    def has_on_off(self) -> bool:
        states = {on for _, on in self.marks}
        return True in states and False in states


@dataclass(frozen=True)
class StimulusResult:
    """Correlation outcome for one device."""

    verdict: str  # responsive | weak | inconclusive | insufficient
    r: float = 0.0
    p: float = 1.0
    lag_s: int = 0
    n_bins: int = 0
    reason: str = ""

    @property
    def usable(self) -> bool:
        return self.verdict in ("responsive", "weak")


def _pearson(x: np.ndarray, y: np.ndarray) -> float:
    if len(x) < 2:
        return 0.0
    xs, ys = x - x.mean(), y - y.mean()
    denom = math.sqrt(float(xs @ xs) * float(ys @ ys))
    if denom <= 1e-12:
        return 0.0
    return float(xs @ ys) / denom


def correlate(
    series: np.ndarray,
    stim: np.ndarray,
    *,
    lag_search_s: int = 5,
    permutations: int = 1000,
    alpha: float = 0.05,
    min_r: float = 0.4,
    seed: int = 7,
) -> StimulusResult:
    """Correlate a per-second rate series against the stimulus vector."""
    series = np.asarray(series, dtype=float)
    stim = np.asarray(stim, dtype=float)
    if len(series) != len(stim):
        raise ValueError("series and stimulus vector must have equal length")
    n = len(series)
    if n < 20:
        return StimulusResult(
            verdict="insufficient",
            n_bins=n,
            reason=f"only {n} seconds of data; need at least 20",
        )
    on_bins = int((stim > 0.5).sum())
    off_bins = n - on_bins
    if on_bins < 5 or off_bins < 5:
        return StimulusResult(
            verdict="insufficient",
            n_bins=n,
            reason=f"stimulus had {on_bins} on-bins / {off_bins} off-bins; need >= 5 each",
        )
    if float(series.std()) <= 1e-9:
        return StimulusResult(
            verdict="inconclusive",
            n_bins=n,
            reason="device showed no traffic variation during the test",
        )

    best_r, best_lag = 0.0, 0
    for lag in range(-lag_search_s, lag_search_s + 1):
        # Positive lag = the device's rate follows the stimulus *lag* seconds
        # later (the physical response delay); negative = rate changes lead
        # the stimulus (usually coincidence).
        if lag > 0:
            r = _pearson(series[lag:], stim[:-lag])
        elif lag < 0:
            r = _pearson(series[:lag], stim[-lag:])
        else:
            r = _pearson(series, stim)
        if abs(r) > abs(best_r):
            best_r, best_lag = r, lag

    def _best_over_lags(a: np.ndarray, b: np.ndarray) -> float:
        best = 0.0
        for lag in range(-lag_search_s, lag_search_s + 1):
            if lag > 0:
                r = _pearson(a[lag:], b[:-lag])
            elif lag < 0:
                r = _pearson(a[:lag], b[-lag:])
            else:
                r = _pearson(a, b)
            if abs(r) > abs(best):
                best = r
        return best

    # Permutations use the SAME max-over-lags statistic, so the p-value
    # accounts for the 11-way lag search (multiple comparisons). The null is
    # the classic permutation-of-independence: the stimulus vector's labels
    # are shuffled. (Circular shifts were considered and rejected: when the
    # response is periodic with the stimulus, shifting by whole periods
    # reproduces perfect alignment and destroys the test's power.)
    rng = np.random.default_rng(seed)
    exceed = 0
    for _ in range(permutations):
        r_perm = _best_over_lags(series, rng.permutation(stim))
        if abs(r_perm) >= abs(best_r):
            exceed += 1
    p = (1 + exceed) / (permutations + 1)

    if p < alpha and abs(best_r) >= min_r:
        verdict = "responsive"
        reason = (
            f"Frame rate followed the on/off stimulus with r={best_r:+.2f} "
            f"(p={p:.3f}, lag {best_lag:+d}s) - the device appears to respond to what it sees"
        )
    elif p < alpha and abs(best_r) >= min_r / 2:
        verdict = "weak"
        reason = (
            f"Statistically significant but small response (r={best_r:+.2f}, p={p:.3f}, "
            f"lag {best_lag:+d}s)"
        )
    else:
        verdict = "inconclusive"
        reason = (
            f"No reliable stimulus response (best r={best_r:+.2f}, p={p:.3f}). This is "
            "INCONCLUSIVE, not evidence the device is innocent (HARD RULE 7)"
        )
    return StimulusResult(
        verdict=verdict,
        r=round(best_r, 3),
        p=round(p, 4),
        lag_s=best_lag,
        n_bins=n,
        reason=reason,
    )


def verdict_to_component(result: StimulusResult) -> "object":
    """Map a StimulusResult to a fusion ComponentResult (import-lazy type)."""
    from sentinel_rf.detect.fusion import ComponentResult

    if not result.usable:
        note = result.reason or "No stimulus test performed"
        return ComponentResult.unavailable("stimulus", note)
    if result.verdict == "responsive":
        score = min(100.0, 40.0 + abs(result.r) * 80.0)
    else:  # weak
        score = min(50.0, abs(result.r) * 100.0)
    return ComponentResult(
        name="stimulus", available=True, score=round(score, 1), reasons=[result.reason]
    )


class StimulusTracker:
    """Per-device per-second rate series recorded during a session.

    Kept separately from the feature windows (which only span the long
    window): a stimulus experiment needs the full baseline+stimulus span.
    """

    def __init__(self, session: StimulusSession, bin_s: float = 1.0) -> None:
        self.session = session
        self.bin_s = float(bin_s)
        self._lock = threading.Lock()
        self._counts: Dict[str, List[Tuple[float, int]]] = {}

    def update(self, obs: Observation) -> None:
        if self.session.phase not in (Phase.BASELINE, Phase.STIMULUS):
            return
        t0 = self.session.started_at
        if t0 is None or obs.ts < t0:
            return
        with self._lock:
            series = self._counts.setdefault(obs.addr_hash, [])
            series.append((obs.ts, obs.length + 1))  # length+1: frames, not just bytes

    def analyze(
        self,
        addr_hash: str,
        *,
        min_frames: int = 50,
        **kwargs,
    ) -> StimulusResult:
        window_start, window_end = self.session.window
        if window_start is None or window_end is None or window_end <= window_start:
            return StimulusResult(
                verdict="insufficient", reason="stimulus session has no marked window"
            )
        with self._lock:
            events = list(self._counts.get(addr_hash, []))
        if len(events) < min_frames:
            return StimulusResult(
                verdict="insufficient",
                reason=f"only {len(events)} frames during the test",
            )
        n_bins = int((window_end - window_start) / self.bin_s) + 1
        counts = np.zeros(n_bins)
        for ts, weight in events:
            idx = int((ts - window_start) / self.bin_s)
            if 0 <= idx < n_bins:
                counts[idx] += weight
        stim = self.session.stimulus_vector(window_start, n_bins, self.bin_s)
        return correlate(counts, stim, **kwargs)

    def devices(self) -> List[str]:
        with self._lock:
            return list(self._counts)
