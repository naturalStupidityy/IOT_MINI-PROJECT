"""Evidence fusion (Phase 4): components -> one explainable 0-100 score.

Components (default weights, normalized at use; configs/default.yaml):
  priors    15  OUI vendor / SSID patterns / address randomization / role
  traffic   35  traffic-profile evidence (rule baseline + ML classifier)
  stimulus  40  stimulus-response correlation (the strongest single layer)
  ble       10  BLE watchlist corroboration

Missing components never zero the score: weights are renormalized over the
available evidence. A stimulus test that ran but found no response makes
the stimulus component *unavailable* and appends an explicit "inconclusive,
not innocence" reason - HARD RULE 7.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, List, Tuple

from sentinel_rf.config import DetectConfig, SentinelConfig

__all__ = [
    "BAND_IGNORE",
    "BAND_LIKELY",
    "BAND_WATCH",
    "ComponentResult",
    "FusionResult",
    "fuse",
]

BAND_IGNORE = "ignore"
BAND_WATCH = "watch"
BAND_LIKELY = "likely"


@dataclass(frozen=True)
class ComponentResult:
    """One evidence component's contribution to the fused score."""

    name: str
    available: bool
    score: float = 0.0  # 0..100 when available
    weight: float = 0.0
    reasons: List[str] = field(default_factory=list)

    @classmethod
    def unavailable(cls, name: str, reason: str = "") -> "ComponentResult":
        return cls(name=name, available=False, reasons=[reason] if reason else [])


@dataclass(frozen=True)
class FusionResult:
    """Fused verdict for one device at one point in time."""

    score: float  # 0..100
    band: str  # ignore | watch | likely
    reasons: List[str] = field(default_factory=list)
    components: Dict[str, ComponentResult] = field(default_factory=dict)
    contributions: List[Tuple[str, float]] = field(default_factory=list)

    @property
    def is_alert(self) -> bool:
        return self.band == BAND_LIKELY


def _as_detect_config(config) -> DetectConfig:
    """Accept either a SentinelConfig or its .detect subtree."""
    return config.detect if isinstance(config, SentinelConfig) else config


def _band_for(score: float, config: DetectConfig) -> str:
    bands = config.fusion.bands
    if score >= bands.likely_above:
        return BAND_LIKELY
    if score >= bands.ignore_below:
        return BAND_WATCH
    return BAND_IGNORE


def fuse(
    components: Dict[str, ComponentResult],
    config,
) -> FusionResult:
    """Fuse available components into one score with renormalized weights."""
    config = _as_detect_config(config)
    weights = {
        "priors": config.fusion.weights.priors,
        "traffic": config.fusion.weights.traffic,
        "stimulus": config.fusion.weights.stimulus,
        "ble": config.fusion.weights.ble,
    }
    available = {k: c for k, c in components.items() if c.available and weights.get(k, 0) > 0}
    reasons: List[str] = []

    if not available:
        return FusionResult(
            score=0.0,
            band=BAND_IGNORE,
            reasons=["No evidence components are available for this device yet."],
            components=components,
            contributions=[],
        )

    total_weight = sum(weights[k] for k in available)
    score = sum(weights[k] * available[k].score for k in available) / total_weight
    for component in available.values():
        reasons.extend(component.reasons)

    for component in components.values():
        if not component.available and component.reasons:
            reasons.extend(component.reasons)

    contributions = sorted(
        ((name, weights[name] * c.score / total_weight) for name, c in available.items()),
        key=lambda kv: kv[1],
        reverse=True,
    )
    return FusionResult(
        score=round(min(max(score, 0.0), 100.0), 1),
        band=_band_for(score, config),
        reasons=reasons,
        components=components,
        contributions=[(name, round(value, 1)) for name, value in contributions],
    )
