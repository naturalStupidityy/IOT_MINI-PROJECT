"""Detection: priors, traffic rules + ML, stimulus correlation, fusion.

Fusion weights (defaults, configs/default.yaml): priors 15, traffic 35,
stimulus 40, BLE 10. Bands: <30 ignore, 30-60 watch, >=60 likely streaming
camera. HARD RULE 7: a missing stimulus response is inconclusive, never
exculpatory. The ML classifier is optional (extras 'ml'); without it the
explainable rule baseline carries the traffic component alone.
"""

from sentinel_rf.detect.ablation import format_ablation_table, run_ablation
from sentinel_rf.detect.dataset import build_training_data, dataset_summary
from sentinel_rf.detect.engine import Alert, Detector, DeviceScore
from sentinel_rf.detect.fusion import (
    BAND_IGNORE,
    BAND_LIKELY,
    BAND_WATCH,
    ComponentResult,
    FusionResult,
    fuse,
)
from sentinel_rf.detect.model import (
    FEATURE_PLAINTEXT,
    ModelCard,
    TrafficModel,
    lodo_cross_validate,
)
from sentinel_rf.detect.rules import PriorsEngine, TrafficRules
from sentinel_rf.detect.stimulus import (
    StimulusResult,
    StimulusSession,
    StimulusTracker,
    correlate,
    verdict_to_component,
)

__all__ = [
    "BAND_IGNORE",
    "BAND_LIKELY",
    "BAND_WATCH",
    "Alert",
    "ComponentResult",
    "Detector",
    "DeviceScore",
    "FEATURE_PLAINTEXT",
    "FusionResult",
    "ModelCard",
    "PriorsEngine",
    "StimulusResult",
    "StimulusSession",
    "StimulusTracker",
    "TrafficModel",
    "TrafficRules",
    "build_training_data",
    "correlate",
    "dataset_summary",
    "format_ablation_table",
    "fuse",
    "lodo_cross_validate",
    "run_ablation",
    "verdict_to_component",
]
