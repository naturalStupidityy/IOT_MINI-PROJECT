"""Training-set construction from the simulator (Phase 4).

Builds (X, y, groups, meta) by running deterministic simulator environments,
sliding evaluation windows per device, and labelling from the simulator's
ground truth. Groups are *device ids* so leave-one-device-out CV never leaks
a device across the train/test boundary.

Label semantics: y=1 means "behaves like a live-streaming camera" - in the
simulator that is exactly the camera/camera_lowres device kinds. Everything
else (including the bulk-upload laptop, deliberately) is a negative.
"""

from __future__ import annotations

import random
from typing import Dict, List, Optional, Tuple

import numpy as np

from sentinel_rf.config import WindowsConfig
from sentinel_rf.features.stats import FEATURE_NAMES, compute_features
from sentinel_rf.features.windows import DeviceTracker
from sentinel_rf.sim.generator import RfSimulator, varied_cast

__all__ = ["build_training_data"]

_CAMERA_KINDS = ("camera", "camera_lowres")


def build_training_data(
    *,
    n_envs: int = 6,
    base_seed: int = 1000,
    duration_s: float = 120.0,
    window_step_s: float = 20.0,
    salt: Optional[bytes] = None,
    include_no_camera_envs: bool = True,
) -> Tuple[np.ndarray, np.ndarray, np.ndarray, List[Dict]]:
    """Simulate environments and return labelled feature rows.

    meta rows carry {device_id, kind, env, t_eval, addr_hash} for debugging
    and for the ablation study; they are never part of the model input.
    """
    if salt is None:
        import secrets

        salt = secrets.token_bytes(16)

    rows: List[Dict[str, float]] = []
    labels: List[int] = []
    groups: List[str] = []
    meta: List[Dict] = []
    env_seeds: List[int] = []
    n_positive_envs = 0

    for env in range(n_envs):
        seed = base_seed + env
        with_camera = True
        if include_no_camera_envs and env % 3 == 2:
            with_camera = False
        if with_camera:
            n_positive_envs += 1
        env_seeds.append(seed)
        rng = random.Random(f"cast:{seed}")
        cast = varied_cast(rng, (5.0, 4.0), with_camera=with_camera)
        sim = RfSimulator(seed=seed, duration_s=duration_s, salt=salt, devices=cast)
        tracker = DeviceTracker(WindowsConfig())
        for obs in sim.observations():
            tracker.update(obs)
        truth = sim.labels()
        t0 = sim.t0
        for t_eval in np.arange(60.0, duration_s + 1.0, window_step_s):
            now = t0 + float(t_eval)
            for addr_hash, window in tracker.snapshot(now).items():
                info = truth.get(addr_hash)
                if info is None or info["kind"].startswith("ble_"):
                    continue  # BLE-only devices are priors evidence, not traffic rows
                features = compute_features(window)
                if features["n_frames"] < 50:
                    continue  # too sparse to judge honestly
                rows.append(features)
                labels.append(1 if info["kind"] in _CAMERA_KINDS else 0)
                groups.append(info["device_id"])
                meta.append(
                    {
                        "device_id": info["device_id"],
                        "kind": info["kind"],
                        "env": env,
                        "env_seed": seed,
                        "t_eval": float(t_eval),
                        "addr_hash": addr_hash,
                        "with_camera": with_camera,
                    }
                )

    X = np.array([[row[name] for name in FEATURE_NAMES] for row in rows], dtype=float)
    y = np.array(labels, dtype=int)
    groups_arr = np.array(groups)
    return X, y, groups_arr, meta


def dataset_summary(meta: List[Dict], y: np.ndarray) -> Dict:
    """Provenance info for the model card."""
    kinds: Dict[str, int] = {}
    for row in meta:
        kinds[row["kind"]] = kinds.get(row["kind"], 0) + 1
    return {
        "n_samples": int(len(y)),
        "n_positives": int(y.sum()),
        "n_negatives": int(len(y) - y.sum()),
        "n_devices": len({row["device_id"] for row in meta}),
        "n_environments": len({row["env"] for row in meta}),
        "env_seeds": sorted({row["env_seed"] for row in meta}),
        "kind_counts": dict(sorted(kinds.items())),
        "label": "1 = simulator camera / camera_lowres device",
    }
