"""Ablation study runner (Phase 4 / Phase 9 report input).

Answers "which evidence layer actually earns its weight?" by re-scoring a
labelled set of device windows with each component disabled and measuring
how detection quality moves. Output is a table (list of dicts) ready for
the report; results with real numbers land in docs/results/ during Phase 9.
"""

from __future__ import annotations

from typing import Callable, Dict, List, Optional, Sequence

from sentinel_rf.config import SentinelConfig
from sentinel_rf.detect.engine import Detector
from sentinel_rf.detect.fusion import BAND_LIKELY, ComponentResult, fuse
from sentinel_rf.intel.cache import IntelCache

__all__ = ["format_ablation_table", "run_ablation"]

_COMPONENTS = ("priors", "traffic", "stimulus", "ble")
_RULES_ONLY = "__rules_only__"


def _metrics(rows: List[Dict]) -> Dict[str, float]:
    if not rows:
        return {
            "n": 0,
            "tp": 0,
            "fp": 0,
            "fn": 0,
            "tn": 0,
            "precision": 0.0,
            "recall": 0.0,
            "f1": 0.0,
            "alert_rate": 0.0,
        }
    tp = sum(1 for r in rows if r["label"] == 1 and r["alert"])
    fp = sum(1 for r in rows if r["label"] == 0 and r["alert"])
    fn = sum(1 for r in rows if r["label"] == 1 and not r["alert"])
    tn = sum(1 for r in rows if r["label"] == 0 and not r["alert"])
    precision = tp / (tp + fp) if (tp + fp) else 0.0
    recall = tp / (tp + fn) if (tp + fn) else 0.0
    f1 = 2 * precision * recall / (precision + recall) if (precision + recall) else 0.0
    return {
        "n": len(rows),
        "tp": tp,
        "fp": fp,
        "fn": fn,
        "tn": tn,
        "precision": round(precision, 3),
        "recall": round(recall, 3),
        "f1": round(f1, 3),
        "alert_rate": round((tp + fp) / len(rows), 3),
    }


def run_ablation(
    *,
    config: SentinelConfig,
    detector: Detector,
    windows: Sequence[Dict],
    intel: IntelCache,
    evaluator: Optional[Callable[[Dict], Dict]] = None,
) -> List[Dict]:
    """Score labelled windows with each component disabled in turn.

    ``windows`` items: {"window": DeviceWindow, "label": 0/1, "addr_hash": str}.
    ``evaluator`` (optional) overrides full-fusion scoring for tests.
    """
    table: List[Dict] = []

    def full_score(row: Dict) -> Dict:
        if evaluator is not None:
            return evaluator(row)
        score = detector.evaluate(row["addr_hash"], None, intel, now=0.0, window=row["window"])
        return {"band": score.band, "components": score.components, "features": score.features}

    def run_variant(name: str, disable: Optional[str]) -> Dict:
        rows = []
        for row in windows:
            result = full_score(row)
            if disable is None:
                band = result["band"]
            elif disable == _RULES_ONLY:
                components = dict(result["components"])
                components["traffic"] = detector.traffic_rules.score(result["features"])
                band = fuse(components, config.detect).band
            else:
                components = dict(result["components"])
                components[disable] = ComponentResult.unavailable(disable, "(ablated)")
                band = fuse(components, config.detect).band
            rows.append({"label": row["label"], "alert": band == BAND_LIKELY})
        return {"variant": name, "disabled": disable or "-", **_metrics(rows)}

    table.append(run_variant("full fusion", None))
    for component in _COMPONENTS:
        table.append(run_variant(f"without {component}", component))
    table.append(run_variant("rules only (no ML)", _RULES_ONLY))
    return table


def format_ablation_table(table: List[Dict]) -> str:
    """Render the ablation result as an aligned text table (reports/CLI)."""
    header = (
        f"{'variant':<22} {'n':>5} {'tp':>4} {'fp':>4} {'fn':>4} "
        f"{'prec':>6} {'rec':>6} {'f1':>6}"
    )
    lines = [header, "-" * len(header)]
    for row in table:
        lines.append(
            f"{row['variant']:<22} {row.get('n', 0):>5} {row.get('tp', 0):>4} "
            f"{row.get('fp', 0):>4} {row.get('fn', 0):>4} {row.get('precision', 0):>6.3f} "
            f"{row.get('recall', 0):>6.3f} {row.get('f1', 0):>6.3f}"
        )
    return "\n".join(lines)
