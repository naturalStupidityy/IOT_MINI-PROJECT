"""SoC temperature reading (Phase 2) - health metric for the capture box.

Sources, in order:
1. /sys/class/thermal/thermal_zone0/temp (millidegrees Celsius) - standard
   sysfs thermal zone, works on the Pi and most Linux laptops.
2. ``vcgencmd measure_temp`` - Raspberry Pi specific. UNVERIFIED until a Pi
   session records evidence in docs/verification-log.md.

Returns ``None`` when no source is readable: an unreadable temperature is a
missing metric, never a crash (quality bar).
"""

from __future__ import annotations

import shutil
import subprocess
from pathlib import Path
from typing import Optional

__all__ = ["read_temperature"]

_THERMAL_ZONE = Path("/sys/class/thermal/thermal_zone0/temp")


def read_temperature() -> Optional[float]:
    """SoC temperature in degrees Celsius, or None when unreadable."""
    try:
        millidegrees = int(_THERMAL_ZONE.read_text(encoding="ascii").strip())
        return millidegrees / 1000.0
    except (OSError, ValueError):
        pass
    if shutil.which("vcgencmd") is None:
        return None
    try:
        proc = subprocess.run(  # noqa: S603 - fixed argv, no shell
            ["vcgencmd", "measure_temp"], capture_output=True, text=True, timeout=5
        )
        # output looks like: temp=42.8'C
        payload = proc.stdout.strip()
        if payload.startswith("temp="):
            return float(payload[5:].rstrip("'C"))
    except (OSError, ValueError, subprocess.SubprocessError):
        pass
    return None
