"""ACT LED control (Phase 2/5) - hot-cold hunting output.

The Raspberry Pi's ACT LED is exposed at /sys/class/leds/led0 (green, on Pi
4B boards). To drive it we switch its trigger to "none" and write brightness;
the original trigger (typically mmc0 or heartbeat) is saved and **always
restored on close**, including on exceptions (safety rule: the LED must
never be left in a broken state for the rest of the session).

UNVERIFIED on a Pi until evidence lands in docs/verification-log.md
(HARD RULE 5). All paths are file operations under a configurable base
directory, so tests run against a tmpdir with no hardware.
"""

from __future__ import annotations

import logging
from pathlib import Path
from typing import List, Optional, Tuple

__all__ = ["FakeLed", "Led", "LedError", "SysfsLed"]

log = logging.getLogger(__name__)

DEFAULT_LED_BASE = Path("/sys/class/leds/led0")


class LedError(RuntimeError):
    """Raised when the LED cannot be controlled (missing sysfs node etc.)."""


class Led:
    """Interface: a single controllable LED with guaranteed restore."""

    def open(self) -> None:
        raise NotImplementedError

    def on(self) -> None:
        raise NotImplementedError

    def off(self) -> None:
        raise NotImplementedError

    def close(self) -> None:
        raise NotImplementedError

    def __enter__(self) -> "Led":
        self.open()
        return self

    def __exit__(self, *exc: object) -> None:
        self.close()


class SysfsLed(Led):
    """Real LED via sysfs. UNVERIFIED on Raspberry Pi hardware."""

    def __init__(self, base: Path = DEFAULT_LED_BASE) -> None:
        self.base = Path(base)
        self._trigger_path = self.base / "trigger"
        self._brightness_path = self.base / "brightness"
        self._original_trigger: Optional[str] = None

    def open(self) -> None:
        if not self._trigger_path.is_file() or not self._brightness_path.is_file():
            raise LedError(f"LED sysfs nodes not found under {self.base}")
        try:
            content = self._trigger_path.read_text(encoding="ascii")
            # sysfs shows the active trigger in [brackets]: "none mmc0 [mmc0]"
            active = content.split("[", 1)[1].split("]", 1)[0] if "[" in content else "none"
            self._original_trigger = active
        except (OSError, IndexError) as exc:
            raise LedError(f"cannot read LED trigger: {exc}") from exc
        try:
            self._trigger_path.write_text("none", encoding="ascii")
        except OSError as exc:
            raise LedError(f"cannot take LED control (write 'none' to trigger): {exc}") from exc
        log.debug("LED %s under control (was trigger %r)", self.base, self._original_trigger)

    def _write_brightness(self, value: int) -> None:
        try:
            self._brightness_path.write_text(str(value), encoding="ascii")
        except OSError as exc:
            raise LedError(f"cannot set LED brightness: {exc}") from exc

    def on(self) -> None:
        self._write_brightness(1)

    def off(self) -> None:
        self._write_brightness(0)

    def close(self) -> None:
        """Restore the original trigger (best effort, never raises)."""
        try:
            self._write_brightness(0)
        except LedError:
            log.warning("could not turn LED off before restoring trigger")
        if self._original_trigger is not None:
            try:
                self._trigger_path.write_text(self._original_trigger, encoding="ascii")
            except OSError:
                log.warning("could not restore LED trigger %r", self._original_trigger)
        log.debug("LED %s released", self.base)


class FakeLed(Led):
    """Records every transition for assertions; touches no hardware."""

    def __init__(self) -> None:
        self.transitions: List[Tuple[bool, float]] = []  # (state, timestamp)
        self.opened = 0
        self.closed = 0
        self._state = False
        self._failed = False

    def fail_on_open(self, failed: bool) -> None:
        """Test hook: make open() raise to exercise error paths."""
        self._failed = failed

    def open(self) -> None:
        if self._failed:
            raise LedError("fake LED configured to fail")
        self.opened += 1

    def on(self) -> None:
        import time

        self._state = True
        self.transitions.append((True, time.monotonic()))

    def off(self) -> None:
        import time

        self._state = False
        self.transitions.append((False, time.monotonic()))

    @property
    def state(self) -> bool:
        return self._state

    def close(self) -> None:
        self.closed += 1

    def on_fractions(self) -> float:
        """Fraction of time the LED was on (0..1) - for blink-rate tests."""
        if len(self.transitions) < 2:
            return 0.0
        on_time = 0.0
        for i in range(len(self.transitions) - 1):
            state, t0 = self.transitions[i]
            t1 = self.transitions[i + 1][1]
            if state:
                on_time += t1 - t0
        total = self.transitions[-1][1] - self.transitions[0][1]
        return on_time / total if total > 0 else 0.0
