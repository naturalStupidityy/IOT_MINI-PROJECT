"""`sentinel doctor` - environment diagnostics (Phase 2).

Every check runs defensively (no exceptions escape) and reports one of:
  OK          present and working on this host
  WARN        usable, but something is missing/degraded
  FAIL        required for the configured mode and broken
  UNVERIFIED  hardware-dependent; needs the Raspberry Pi session
              (docs/verification-log.md, HARD RULE 5)

On a laptop with no Wi-Fi tools this intentionally prints UNVERIFIED for
everything hardware-facing - that is the honest answer, not a failure.
"""

from __future__ import annotations

import importlib
import json
import os
import platform
import shutil
import sys
from dataclasses import dataclass
from pathlib import Path
from typing import List, Optional

from sentinel_rf.config import SentinelConfig
from sentinel_rf.system.led import DEFAULT_LED_BASE
from sentinel_rf.system.resources import total_ram_mb
from sentinel_rf.system.temperature import read_temperature

__all__ = ["CheckResult", "run_checks", "format_checks", "run_doctor"]

OK = "OK"
WARN = "WARN"
FAIL = "FAIL"
UNVERIFIED = "UNVERIFIED"

# Optional dependencies: name -> (import name, what it is needed for)
_OPTIONAL_DEPS = {
    "numpy": ("numpy", "feature statistics (Phase 3)"),
    "scikit-learn": ("sklearn", "ML traffic classifier (Phase 4)"),
    "joblib": ("joblib", "model persistence (Phase 4)"),
    "scipy": ("scipy", "multilateration WLS (Phase 5)"),
    "fastapi": ("fastapi", "dashboard API (Phase 7)"),
    "uvicorn": ("uvicorn", "dashboard server (Phase 7)"),
    "paho-mqtt": ("paho.mqtt.client", "MQTT transport (Phase 6)"),
    "bleak": ("bleak", "BLE scanning (Phase 2, needs BlueZ)"),
}

_SYSTEM_TOOLS = {
    "iw": "channel control (Scan/Lock mode)",
    "tcpdump": "live monitor-mode capture",
    "ip": "interface bring-up",
    "mosquitto_pub": "MQTT end-to-end check (optional)",
    "vcgencmd": "Pi temperature (falls back to sysfs)",
}


@dataclass
class CheckResult:
    name: str
    status: str
    detail: str = ""
    section: str = "environment"
    hint: str = ""


def _check_python() -> CheckResult:
    version = sys.version_info
    detail = f"Python {platform.python_version()} on {sys.platform}"
    if version >= (3, 9):
        return CheckResult("python", OK, detail)
    return CheckResult("python", FAIL, detail, hint="SENTINEL-RF needs Python >= 3.9")


def _check_package() -> CheckResult:
    try:
        import sentinel_rf

        return CheckResult("sentinel-rf package", OK, f"v{sentinel_rf.__version__} importable")
    except Exception as exc:  # pragma: no cover - would be a broken install
        return CheckResult("sentinel-rf package", FAIL, str(exc))


def _check_optional_deps() -> List[CheckResult]:
    results = []
    for dist_name, (import_name, why) in _OPTIONAL_DEPS.items():
        try:
            module = importlib.import_module(import_name)
            version = getattr(module, "__version__", "unknown")
            results.append(CheckResult(f"dep: {dist_name}", OK, f"{version} ({why})"))
        except ImportError:
            results.append(
                CheckResult(
                    f"dep: {dist_name}",
                    WARN,
                    f"not installed - needed for {why}",
                    hint=f"pip install -e '.[all]' or pip install {dist_name}",
                )
            )
    return results


def _check_tools() -> List[CheckResult]:
    results = []
    for tool, why in _SYSTEM_TOOLS.items():
        path = shutil.which(tool)
        if path:
            results.append(CheckResult(f"tool: {tool}", OK, f"{path} ({why})"))
        else:
            results.append(
                CheckResult(
                    f"tool: {tool}",
                    UNVERIFIED if tool in ("iw", "vcgencmd") else WARN,
                    f"not found on this host ({why})",
                    hint="on the Pi: sudo apt install iw tcpdump iproute2 mosquitto-clients",
                )
            )
    return results


def _check_interface(config: SentinelConfig) -> CheckResult:
    iface = config.capture.iface
    from sentinel_rf.capture.channel_hopper import iw_list_interfaces

    interfaces = iw_list_interfaces()
    if not interfaces:
        return CheckResult(
            "capture interface",
            UNVERIFIED,
            f"cannot enumerate wireless interfaces (iw absent or no radio); "
            f"configured iface is '{iface}'",
            hint="run again on the Pi; see docs/DEPLOYMENT.md for monitor-mode bring-up",
        )
    if iface in interfaces:
        return CheckResult("capture interface", OK, f"{iface} present: {', '.join(interfaces)}")
    return CheckResult(
        "capture interface",
        FAIL,
        f"configured iface '{iface}' not in {interfaces}",
        hint="create the monitor interface (scripts/monitor_up.sh) or fix capture.iface",
    )


def _check_led() -> CheckResult:
    if (DEFAULT_LED_BASE / "brightness").is_file():
        return CheckResult("ACT LED", OK, f"{DEFAULT_LED_BASE} present")
    return CheckResult(
        "ACT LED",
        UNVERIFIED,
        f"{DEFAULT_LED_BASE} not found on this host",
        hint="expected on the Pi; hot-cold hunting falls back to console output",
    )


def _check_temperature() -> CheckResult:
    temp = read_temperature()
    if temp is not None:
        return CheckResult("SoC temperature", OK, f"{temp:.1f} C")
    return CheckResult(
        "SoC temperature",
        UNVERIFIED,
        "no sysfs thermal zone and no vcgencmd on this host",
        hint="expected on the Pi",
    )


def _check_store(config: SentinelConfig) -> CheckResult:
    path = Path(config.store.path)
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        probe = path.with_suffix(".probe")
        probe.write_bytes(b"")
        probe.unlink()
        return CheckResult("store writable", OK, str(path))
    except OSError as exc:
        return CheckResult("store writable", FAIL, str(exc), hint="fix store.path permissions")


def _check_salt(config: SentinelConfig) -> CheckResult:
    if config.privacy.salt_file is None:
        return CheckResult(
            "MAC hash salt", OK, "ephemeral per-process salt (privacy default, D008)"
        )
    try:
        path = Path(config.privacy.salt_file)
        path.parent.mkdir(parents=True, exist_ok=True)
        if path.exists():
            mode = path.stat().st_mode & 0o777
            if mode != 0o600:
                return CheckResult(
                    "MAC hash salt", WARN, f"{path} has mode {oct(mode)}, expected 0600"
                )
            return CheckResult("MAC hash salt", OK, f"{path} (mode 0600)")
        return CheckResult("MAC hash salt", OK, f"{path} will be created with mode 0600")
    except OSError as exc:
        return CheckResult("MAC hash salt", FAIL, str(exc))


def _check_host() -> CheckResult:
    cpu = os.cpu_count() or 1
    ram = total_ram_mb()
    ram_s = f"{ram:.0f} MB RAM" if ram is not None else "RAM unknown"
    return CheckResult("host", OK, f"{cpu} CPU(s), {ram_s}, {platform.machine()}")


def run_checks(config: Optional[SentinelConfig] = None) -> List[CheckResult]:
    """Run every diagnostic; never raises."""
    from sentinel_rf.config import load_config

    if config is None:
        try:
            config = load_config()
        except Exception as exc:
            return [CheckResult("config", FAIL, str(exc))]
    results = [
        _check_python(),
        _check_package(),
        _check_host(),
    ]
    try:
        results.append(CheckResult("config", OK, "loaded and validated"))
    except Exception:  # pragma: no cover
        results.append(CheckResult("config", FAIL, "unreachable"))
    results += _check_optional_deps()
    results += _check_tools()
    results.append(_check_interface(config))
    results.append(_check_led())
    results.append(_check_temperature())
    results.append(_check_store(config))
    results.append(_check_salt(config))
    for result in results:
        if result.section == "environment" and result.name.startswith(("capture", "ACT", "SoC")):
            result.section = "hardware"
    return results


def format_checks(results: List[CheckResult]) -> str:
    width = max(len(r.name) for r in results) + 2
    lines = [
        "SENTINEL-RF doctor - environment diagnostics",
        "=" * 64,
        "OK = works here · WARN = degraded · FAIL = broken · "
        "UNVERIFIED = needs the Raspberry Pi session",
        "",
    ]
    section = None
    for r in results:
        if r.section != section:
            section = r.section
            lines.append(f"--- {section} ---")
        marker = {"OK": "  OK  ", "WARN": " WARN ", "FAIL": " FAIL ", "UNVERIFIED": "UNVERIF"}[
            r.status
        ]
        lines.append(f"{marker} {r.name:<{width}} {r.detail}")
        if r.hint:
            lines.append(f"         {'':<{width}} -> {r.hint}")
    fails = sum(1 for r in results if r.status == FAIL)
    lines.append("")
    lines.append(
        "HARD RULE 5: hardware items stay UNVERIFIED until real output is pasted into "
        "docs/verification-log.md."
    )
    if fails:
        lines.append(f"{fails} FAIL - fix before running the configured mode.")
    return "\n".join(lines)


def run_doctor(config: Optional[SentinelConfig] = None, as_json: bool = False) -> int:
    """Entry point behind `sentinel doctor`. Returns a process exit code."""
    results = run_checks(config)
    if as_json:
        print(
            json.dumps(
                [{"name": r.name, "status": r.status, "detail": r.detail} for r in results],
                indent=2,
            )
        )
    else:
        print(format_checks(results))
    return 1 if any(r.status == FAIL for r in results) else 0
