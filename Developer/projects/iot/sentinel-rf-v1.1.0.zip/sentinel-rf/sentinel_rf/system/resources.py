"""Process resource monitoring (Phase 2/8) - the Pi's budget guard.

The spec's operating budget: < 50% CPU, < 300 MB RAM, < 2% dropped frames.
This module samples the sentinel process's own CPU seconds (from
/proc/self/stat) and resident memory (from /proc/self/statm) - no psutil
dependency, Linux-only by design (the target is the Pi; laptops running the
dev install also have /proc).

``ResourceMonitor`` runs a small sampler thread during live captures; the
dashboard (Phase 7) exposes the latest sample and any budget violations.
"""

from __future__ import annotations

import logging
import os
import threading
import time
from pathlib import Path
from typing import Dict, List, Optional

__all__ = ["ResourceMonitor", "read_proc_statm_mb", "total_ram_mb"]

log = logging.getLogger(__name__)

_PROC_STAT = Path("/proc/self/stat")
_PROC_STATM = Path("/proc/self/statm")
_PAGE_SIZE = os.sysconf("SC_PAGE_SIZE") if hasattr(os, "sysconf") else 4096
_CLK_TCK = os.sysconf("SC_CLK_TCK") if hasattr(os, "sysconf") else 100


def _proc_cpu_seconds() -> Optional[float]:
    try:
        parts = _PROC_STAT.read_text(encoding="ascii").rsplit(") ", 1)[1].split()
        utime, stime = int(parts[11]), int(parts[12])  # fields 14/15 overall
        return (utime + stime) / _CLK_TCK
    except (OSError, ValueError, IndexError):
        return None


def read_proc_statm_mb() -> Optional[float]:
    """Current resident set size in MB, or None when unreadable."""
    try:
        fields = _PROC_STATM.read_text(encoding="ascii").split()
        resident_pages = int(fields[1])
        return resident_pages * _PAGE_SIZE / (1024.0 * 1024.0)
    except (OSError, ValueError, IndexError):
        return None


def total_ram_mb() -> Optional[float]:
    """Total system RAM in MB (from /proc/meminfo), or None."""
    try:
        for line in Path("/proc/meminfo").read_text(encoding="ascii").splitlines():
            if line.startswith("MemTotal:"):
                return float(line.split()[1]) / 1024.0
    except (OSError, ValueError, IndexError):
        pass
    return None


class ResourceMonitor:
    """Background sampler of the process's CPU% and RSS."""

    def __init__(self, *, interval_s: float = 5.0, history: int = 120) -> None:
        self.interval_s = float(interval_s)
        self._history_max = history
        self.samples: List[Dict] = []
        self._stop = threading.Event()
        self._thread: Optional[threading.Thread] = None
        self._baseline_cpu = _proc_cpu_seconds()
        self._baseline_wall = time.monotonic()

    def sample_once(self) -> Dict:
        """Take one sample right now (also used in tests and on demand)."""
        cpu = _proc_cpu_seconds()
        wall = time.monotonic()
        elapsed = wall - self._baseline_wall
        cpu_pct: Optional[float] = None
        if cpu is not None and elapsed > 0.1:
            cpu_pct = max(0.0, (cpu - (self._baseline_cpu or cpu)) / elapsed * 100.0)
        sample = {
            "ts": time.time(),
            "cpu_percent": round(cpu_pct, 1) if cpu_pct is not None else None,
            "rss_mb": round(v, 1) if (v := read_proc_statm_mb()) is not None else None,
            "threads": threading.active_count(),
        }
        self.samples.append(sample)
        if len(self.samples) > self._history_max:
            del self.samples[: len(self.samples) - self._history_max]
        return sample

    def latest(self) -> Optional[Dict]:
        return self.samples[-1] if self.samples else None

    def peak_rss_mb(self) -> Optional[float]:
        values = [s["rss_mb"] for s in self.samples if s.get("rss_mb") is not None]
        return max(values) if values else None

    def budget_violations(self, *, max_cpu_percent: float, max_ram_mb: float) -> List[str]:
        """Human-readable violations of the operating budget."""
        violations: List[str] = []
        latest = self.latest()
        if latest is None:
            return violations
        if latest.get("rss_mb") is not None and latest["rss_mb"] > max_ram_mb:
            violations.append(f"RSS {latest['rss_mb']} MB > budget {max_ram_mb} MB")
        peak = self.peak_rss_mb()
        if peak is not None and peak > max_ram_mb:
            violations.append(f"peak RSS {peak} MB > budget {max_ram_mb} MB")
        if latest.get("cpu_percent") is not None and latest["cpu_percent"] > max_cpu_percent:
            violations.append(
                f"CPU {latest['cpu_percent']}% > budget {max_cpu_percent}% (single core)"
            )
        return violations

    # -- thread -------------------------------------------------------- #

    def start(self) -> None:
        if self._thread is not None:
            return
        self._stop.clear()
        self._thread = threading.Thread(target=self._run, name="sentinel-resmon", daemon=True)
        self._thread.start()

    def stop(self, timeout: float = 2.0) -> None:
        self._stop.set()
        if self._thread is not None:
            self._thread.join(timeout=timeout)
            self._thread = None

    def _run(self) -> None:
        while not self._stop.wait(self.interval_s):
            try:
                self.sample_once()
            except Exception:  # pragma: no cover - defensive
                log.exception("resource sampling failed")
