"""System layer: LED, temperature, iw plumbing, resources, doctor.

Everything in here touches the host (sysfs, /proc, subprocesses). Pure
software paths are tested on a laptop; hardware-facing behaviour stays
UNVERIFIED until docs/verification-log.md carries real Pi output
(HARD RULE 5).
"""

from sentinel_rf.system.doctor import CheckResult, run_checks, run_doctor
from sentinel_rf.system.led import FakeLed, Led, LedError, SysfsLed
from sentinel_rf.system.resources import ResourceMonitor, total_ram_mb
from sentinel_rf.system.temperature import read_temperature

__all__ = [
    "CheckResult",
    "FakeLed",
    "Led",
    "LedError",
    "ResourceMonitor",
    "SysfsLed",
    "read_temperature",
    "run_checks",
    "run_doctor",
    "total_ram_mb",
]
