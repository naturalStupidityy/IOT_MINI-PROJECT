"""Salted MAC hashing - the privacy core (HARD RULE 3).

Stored and exported MAC addresses are HMAC-SHA256 digests keyed with a
per-session salt; raw addresses never leave live in-memory state. Digest
output is bare lowercase hex without ':' or '-' separators, so
sentinel_rf.privacy.looks_like_raw_mac() can distinguish raw MACs from
hashes without false positives (DECISIONS.md D014).
"""

from __future__ import annotations

import hashlib
import hmac
import re
import secrets
from pathlib import Path
from typing import Union

__all__ = ["load_or_create_salt", "mac_hash", "new_salt", "normalize_mac"]

_BARE_MAC_RE = re.compile(r"[0-9a-f]{12}")


def normalize_mac(mac: str) -> str:
    """Return the canonical bare lowercase form of a MAC address.

    Accepts "AA:BB:CC:DD:EE:FF", "AA-BB-CC-DD-EE-FF", "aabbccddeeff" and
    surrounding whitespace (mixed separators are tolerated). Raises
    ValueError for anything that is not exactly 6 hex octets.

    NOTE: raw addresses must keep their ':' separators while live
    (DECISIONS.md D014); the bare form is used only for hashing and for
    this validation.
    """
    if not isinstance(mac, str):
        raise ValueError(f"MAC address must be a str, got {type(mac).__name__}")
    bare = mac.strip().lower().replace(":", "").replace("-", "")
    if _BARE_MAC_RE.fullmatch(bare) is None:
        raise ValueError(f"not a MAC address: {mac!r}")
    return bare


def new_salt(nbytes: int = 16) -> bytes:
    """Return a fresh cryptographically random session salt (>= 8 bytes)."""
    if not isinstance(nbytes, int) or nbytes < 8:
        raise ValueError(f"salt must be at least 8 bytes, got {nbytes!r}")
    return secrets.token_bytes(nbytes)


def load_or_create_salt(path: Union[str, Path]) -> bytes:
    """Load a persisted salt from *path*, creating it (mode 0600) on first use.

    Only use this when cross-session device continuity is wanted; by default
    the salt is ephemeral (configs/default.yaml: privacy.salt_file).
    """
    p = Path(path)
    if p.exists():
        try:
            salt = bytes.fromhex(p.read_text(encoding="ascii").strip())
        except ValueError as exc:
            raise ValueError(f"{p}: not a hex salt file") from exc
        if len(salt) < 8:
            raise ValueError(f"{p}: salt too short ({len(salt)} bytes)")
        return salt
    salt = new_salt()
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(salt.hex(), encoding="ascii")
    p.chmod(0o600)
    return salt


def mac_hash(mac: str, salt: bytes, truncate: int = 16) -> str:
    """Return the salted HMAC-SHA256 hash of a MAC, hex-truncated to *truncate*.

    *truncate* must be an even number of hex characters between 16 and 64
    (16 chars = 64 bits, collision-safe for realistic device populations).
    12 is deliberately forbidden so a bare 12-hex-char raw MAC can never be
    confused with a hash (DECISIONS.md D009).
    """
    if not isinstance(truncate, int) or not (16 <= truncate <= 64) or truncate % 2 != 0:
        raise ValueError(f"truncate must be an even int in [16, 64], got {truncate!r}")
    if not isinstance(salt, (bytes, bytearray)) or len(salt) < 8:
        raise ValueError("salt must be bytes of at least 8 bytes")
    digest = hmac.new(bytes(salt), normalize_mac(mac).encode("ascii"), hashlib.sha256)
    return digest.hexdigest()[:truncate]
