"""BLE advertisement scanning (Phase 2).

BLE corroboration is a small but useful evidence layer (weight 10/100 by
default): hidden cameras with a companion app or setup beacon often advertise
over BLE while streaming over Wi-Fi.

* :class:`BleakBleScanner` - the real backend, built on bleak/BlueZ.
  **UNVERIFIED on a Pi** until a live scan is recorded in
  docs/verification-log.md (HARD RULE 5). scan_mode "passive" never sends
  scan requests (HARD RULE 1); "active" requests SCAN_RSP to collect local
  names and TX power.
* :class:`FakeBleScanner` - scripted advertisements for laptop development.

The scanner only *receives*; it never connects to a device and never
advertises anything itself.
"""

from __future__ import annotations

import logging
import threading
import time
from typing import Iterable, List, Optional

from sentinel_rf.crypto import mac_hash
from sentinel_rf.parse.observation import Observation
from sentinel_rf.privacy import is_locally_administered

__all__ = ["BleScanner", "BleakBleScanner", "FakeBleScanner"]

log = logging.getLogger(__name__)


class BleScanner:
    """Base class: background thread emitting BLE Observations into a queue."""

    def __init__(
        self, out_queue, *, node_id: str, salt: bytes, truncate: int = 16, allow_raw: bool = False
    ) -> None:
        self._queue = out_queue
        self.node_id = node_id
        self.salt = salt
        self.truncate = truncate
        self.allow_raw = allow_raw
        self.counters = {"emitted": 0, "errors": 0}
        self.errors: List[str] = []
        self._stop = threading.Event()
        self.finished = threading.Event()  # set when the scan loop exits
        self._thread: Optional[threading.Thread] = None

    def start(self) -> None:
        if self._thread is not None:
            return
        self._stop.clear()
        self._thread = threading.Thread(target=self._run, name="sentinel-ble", daemon=True)
        self._thread.start()

    def stop(self, timeout: float = 5.0) -> None:
        self._stop.set()
        if self._thread is not None:
            self._thread.join(timeout=timeout)
            self._thread = None

    @property
    def running(self) -> bool:
        return self._thread is not None and self._thread.is_alive()

    def _run(self) -> None:
        try:
            self._scan_loop()
        except Exception as exc:  # a BLE failure must never kill the pipeline
            self.counters["errors"] += 1
            self.errors.append(f"{type(exc).__name__}: {exc}"[:200])
            log.exception("BLE scanner failed")
        finally:
            self.finished.set()

    def _scan_loop(self) -> None:
        raise NotImplementedError

    def _emit(self, obs: Observation) -> None:
        try:
            self._queue.put_nowait(obs)
            self.counters["emitted"] += 1
        except Exception:  # queue.Full or closed - count and move on
            pass

    def observation_from_advert(
        self,
        *,
        ts: float,
        address: str,
        rssi_dbm: float,
        name: Optional[str] = None,
        tx_power: Optional[float] = None,
        service_uuids: Iterable[str] = (),
        company_id: Optional[int] = None,
        adv_type: Optional[str] = None,
    ) -> Optional[Observation]:
        """Build a BLE Observation from a parsed advertisement."""
        try:
            return Observation.ble(
                ts=ts,
                node_id=self.node_id,
                rssi_dbm=float(rssi_dbm),
                addr_hash=mac_hash(address, self.salt, self.truncate),
                length=0,  # BLE adv length is not reported by the host stack
                addr_is_random=is_locally_administered(address),
                name=name,
                tx_power=tx_power,
                service_uuids=tuple(service_uuids)[:8],
                company_id=company_id,
                adv_type=adv_type,
                raw_addr=address if self.allow_raw else None,
            )
        except (ValueError, TypeError):
            return None


class BleakBleScanner(BleScanner):
    """Real BLE scanner via bleak. UNVERIFIED on Pi hardware.

    bleak drives BlueZ on Linux and CoreBluetooth on macOS (12+); either way
    this node only *receives* advertisements and never connects. On macOS the
    passive/active scanning_mode distinction is advisory (CoreBluetooth
    exposes no such knob); BlueZ honours it.

    Runs bleak's async scanner inside the scanner thread's own event loop;
    ``detection_callback`` converts each advertisement into an Observation.
    ``scan_mode='passive'`` maps to bleak's ``scanning_mode='passive'``.
    """

    def __init__(
        self,
        out_queue,
        *,
        node_id: str,
        salt: bytes,
        truncate: int = 16,
        allow_raw: bool = False,
        scan_mode: str = "active",
    ) -> None:
        super().__init__(
            out_queue, node_id=node_id, salt=salt, truncate=truncate, allow_raw=allow_raw
        )
        self.scan_mode = scan_mode

    def _scan_loop(self) -> None:
        import asyncio

        try:
            from bleak import BleakScanner  # noqa: PLC0415 - optional dep
        except ImportError as exc:
            self.errors.append(f"bleak not installed: {exc}")
            log.error("bleak is not installed; BLE corroboration disabled")
            return

        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)

        def on_detection(device, advertisement_data) -> None:
            manufacturer = advertisement_data.manufacturer_data or {}
            obs = self.observation_from_advert(
                ts=time.time(),
                address=str(device.address),
                rssi_dbm=advertisement_data.rssi if advertisement_data.rssi is not None else -100.0,
                name=advertisement_data.local_name,
                tx_power=advertisement_data.tx_power,
                service_uuids=[str(u) for u in (advertisement_data.service_uuids or [])],
                company_id=next(iter(manufacturer)) if manufacturer else None,
                adv_type="bleak_adv",
            )
            if obs is not None:
                self._emit(obs)

        async def run() -> None:
            scanner = BleakScanner(
                detection_callback=on_detection,
                scanning_mode="passive" if self.scan_mode == "passive" else "active",
            )
            await scanner.start()
            try:
                while not self._stop.is_set():
                    await asyncio.sleep(0.2)
            finally:
                await scanner.stop()

        loop.run_until_complete(run())
        loop.close()


class FakeBleScanner(BleScanner):
    """Scripted BLE advertisements (laptop development / tests)."""

    def __init__(
        self,
        out_queue,
        *,
        node_id: str,
        salt: bytes,
        truncate: int = 16,
        allow_raw: bool = False,
        scripted: Optional[Iterable[Observation]] = None,
        interval_s: float = 0.0,
    ) -> None:
        super().__init__(
            out_queue, node_id=node_id, salt=salt, truncate=truncate, allow_raw=allow_raw
        )
        self.scripted = list(scripted or [])
        self.interval_s = interval_s

    def _scan_loop(self) -> None:
        for obs in self.scripted:
            if self._stop.is_set():
                return
            self._emit(obs)
            if self.interval_s > 0:
                time.sleep(self.interval_s)
