"""CaptureManager: wires backends, channel hopping and a bounded queue.

One place to start/stop the whole capture side: the Wi-Fi monitor, the BLE
scanner and the channel hopper (Scan mode) all run as daemon threads pushing
into a single bounded queue; :meth:`observations` drains it for the
pipeline. Backpressure is explicit: when the queue is full, frames are
dropped and **counted** (the < 2% drop budget is a health metric, HARD
RULE: never block the capture thread).
"""

from __future__ import annotations

import logging
import queue
import threading
import time
from typing import Dict, Iterator, Optional

from sentinel_rf.capture.ble_scanner import BleScanner
from sentinel_rf.capture.channel_hopper import ChannelHopper
from sentinel_rf.capture.wifi_monitor import WifiMonitor
from sentinel_rf.parse.observation import Observation

__all__ = ["CaptureManager"]

log = logging.getLogger(__name__)


class CaptureManager:
    """Own the queue, the backends and the hopper lifecycle."""

    def __init__(
        self,
        *,
        wifi: Optional[WifiMonitor] = None,
        ble: Optional[BleScanner] = None,
        hopper: Optional[ChannelHopper] = None,
        queue_size: int = 4096,
    ) -> None:
        self._queue: "queue.Queue" = queue.Queue(maxsize=queue_size)
        self.wifi = wifi
        self.ble = ble
        self.hopper = hopper
        self._started = False
        self._stopped = threading.Event()
        self.started_at: Optional[float] = None

    # -- lifecycle ---------------------------------------------------- #

    @property
    def queue(self) -> "queue.Queue":
        """The bounded observation queue backends must publish into."""
        return self._queue

    def start(self) -> None:
        if self._started:
            return
        self._started = True
        self._stopped.clear()
        self.started_at = time.time()
        if self.hopper is not None:
            self.hopper.start()
        if self.wifi is not None:
            self.wifi.start()
        if self.ble is not None:
            self.ble.start()
        log.info(
            "capture started (wifi=%s ble=%s hopper=%s)",
            type(self.wifi).__name__ if self.wifi else None,
            type(self.ble).__name__ if self.ble else None,
            type(self.hopper).__name__ if self.hopper else None,
        )

    def stop(self) -> None:
        if not self._started:
            return
        # Stop producers first, then drain naturally.
        if self.wifi is not None:
            self.wifi.stop()
        if self.ble is not None:
            self.ble.stop()
        if self.hopper is not None:
            self.hopper.stop()
        self._stopped.set()
        self._started = False
        log.info("capture stopped after %.1fs", time.time() - (self.started_at or time.time()))

    # -- consumption --------------------------------------------------- #

    def _sources(self):
        return [s for s in (self.wifi, self.ble) if s is not None]

    def all_sources_finished(self) -> bool:
        """True when every configured source has finished its stream.

        Bounded sources (replay, sim, fakes) finish; live sources run until
        stopped, so this only becomes True after stop() in live mode.
        """
        sources = self._sources()
        return bool(sources) and all(s.finished.is_set() for s in sources)

    def poll(self, timeout: float = 0.5) -> Optional[Observation]:
        """Get one observation, or None on timeout (lets callers idle-tick)."""
        try:
            return self._queue.get(timeout=timeout)
        except queue.Empty:
            return None

    def finished(self) -> bool:
        """True when stopped, sourceless, or all sources drained + queue empty."""
        if self._stopped.is_set():
            return True
        if not self._sources():
            return True
        return self.all_sources_finished() and self._queue.empty()

    def observations(self, poll_s: float = 0.25) -> Iterator[Observation]:
        """Drain observations until stopped AND the queue is empty.

        Also ends naturally when every source has finished and the queue is
        drained (replay/sim mode) without an explicit stop().
        """
        while True:
            try:
                item = self._queue.get(timeout=poll_s)
            except queue.Empty:
                if self.finished():
                    return
                continue
            yield item

    # -- health -------------------------------------------------------- #

    def stats(self) -> Dict:
        wifi = self.wifi.counters.snapshot() if self.wifi else {}
        ble = dict(self.ble.counters) if self.ble else {}
        emitted = wifi.get("emitted", 0) + ble.get("emitted", 0)
        dropped = wifi.get("dropped", 0)
        loss_pct = 100.0 * dropped / (dropped + emitted) if (dropped + emitted) else 0.0
        return {
            "started": self._started,
            "uptime_s": round(time.time() - self.started_at, 1) if self.started_at else 0.0,
            "wifi": wifi,
            "ble": ble,
            "hopper": (
                {
                    "visited": len(self.hopper.visited) if self.hopper else 0,
                    "errors": list(self.hopper.errors)[-3:] if self.hopper else [],
                }
                if self.hopper
                else {"visited": 0, "errors": []}
            ),
            "queue_size": self._queue.qsize(),
            "emitted": emitted,
            "dropped": dropped,
            "drop_pct": round(loss_pct, 3),
        }

    def __enter__(self) -> "CaptureManager":
        self.start()
        return self

    def __exit__(self, *exc: object) -> None:
        self.stop()
