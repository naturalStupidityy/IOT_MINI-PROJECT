"""PCAP replay as a capture source (Phase 1/2 seam).

Wraps :func:`sentinel_rf.parse.pcap.iter_pcap_observations` in the
:class:`~sentinel_rf.capture.wifi_monitor.WifiMonitor` interface so replay
and live capture share one code path (the pipeline cannot tell them apart).
``speed=0`` replays as fast as possible; ``speed=1`` re-plays in real time.
"""

from __future__ import annotations

from pathlib import Path
from typing import Dict, Optional, Sequence, Union

from sentinel_rf.capture.wifi_monitor import IteratorWifiSource
from sentinel_rf.parse.pcap import iter_pcap_observations

__all__ = ["ReplayWifiSource", "make_replay_source"]


class ReplayWifiSource(IteratorWifiSource):
    """A WifiMonitor that replays one or more pcap files."""

    def __init__(
        self,
        out_queue,
        *,
        pcaps: Sequence[Union[str, Path]],
        node_id: str,
        salt: bytes,
        truncate: int = 16,
        allow_raw: bool = False,
        speed: float = 0.0,
        counters: Optional[Dict] = None,
    ) -> None:
        self._replay_salt = salt
        self._replay_truncate = truncate
        self._replay_allow_raw = allow_raw
        self.counters_out: Dict = counters if counters is not None else {}
        super().__init__(
            out_queue,
            observations_factory=lambda: self._iterate(pcaps),
            node_id=node_id,
            speed=speed,
            name=f"replay:{len(pcaps)}-file{'s' if len(pcaps) != 1 else ''}",
        )

    def _iterate(self, pcaps: Sequence[Union[str, Path]]):
        for path in pcaps:
            yield from iter_pcap_observations(
                path,
                node_id=self.node_id,
                salt=self._replay_salt,
                truncate=self._replay_truncate,
                allow_raw=self._replay_allow_raw,
                counters=self.counters_out,
            )


def make_replay_source(out_queue, *, pcap, node_id, salt, speed=0.0, counters=None):
    """Convenience constructor for a single pcap file."""
    return ReplayWifiSource(
        out_queue,
        pcaps=[pcap],
        node_id=node_id,
        salt=salt,
        speed=speed,
        counters=counters,
    )
