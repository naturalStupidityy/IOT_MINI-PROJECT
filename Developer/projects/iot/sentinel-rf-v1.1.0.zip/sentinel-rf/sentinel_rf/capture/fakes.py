"""Software fakes for every hardware backend (laptop development).

FakeWifiMonitor (scripted frames), FakeBleScanner, FakeChannelHopper and
FakeLed implement the same interfaces as the real backends so the entire
pipeline runs (and is tested) without a Raspberry Pi. See the working
agreement: anything that needs the real Pi goes behind an interface with a
fake right here. Real hardware paths live in the sibling modules and stay
UNVERIFIED until docs/verification-log.md has evidence (HARD RULE 5).
"""

from __future__ import annotations

from typing import Iterable

from sentinel_rf.capture.ble_scanner import FakeBleScanner as _FakeBleScanner
from sentinel_rf.capture.channel_hopper import (
    ChannelHopper,
)
from sentinel_rf.capture.channel_hopper import (
    FakeChannelHopper as _FakeChannelHopper,
)
from sentinel_rf.capture.wifi_monitor import (
    CaptureCounters,
    IteratorWifiSource,
    NullWifiMonitor,
    WifiMonitor,
)
from sentinel_rf.parse.observation import Observation
from sentinel_rf.system.led import FakeLed, Led, SysfsLed

__all__ = [
    "CaptureCounters",
    "ChannelHopper",
    "FakeBleScanner",
    "FakeChannelHopper",
    "FakeLed",
    "FakeWifiMonitor",
    "IteratorWifiSource",
    "Led",
    "NullWifiMonitor",
    "SysfsLed",
    "WifiMonitor",
]


class FakeWifiMonitor(WifiMonitor):
    """Scripted Wi-Fi source: emits the given observations, then idles.

    ``idle_s`` controls how long the "capture" stays up after the script is
    exhausted (so managers keep draining). Default: stop as soon as done.
    """

    def __init__(
        self,
        out_queue,
        *,
        observations: Iterable[Observation],
        node_id: str,
        idle_s: float = 0.0,
        name: str = "fake-wifi",
    ) -> None:
        super().__init__(out_queue, node_id=node_id, name=name)
        self._script = list(observations)
        self.idle_s = idle_s

    def _capture_loop(self) -> None:
        for obs in self._script:
            if self._stop.is_set():
                return
            self._emit(obs)
        if self.idle_s > 0:
            self._stop.wait(self.idle_s)


# Re-exports so `from sentinel_rf.capture.fakes import ...` is the one-stop shop.
FakeBleScanner = _FakeBleScanner
FakeChannelHopper = _FakeChannelHopper
