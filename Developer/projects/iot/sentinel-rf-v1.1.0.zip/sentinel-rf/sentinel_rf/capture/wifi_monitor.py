"""Monitor-mode Wi-Fi capture backends (Phase 2).

Two real backends and one adapter:

* :class:`TcpdumpWifiMonitor` - spawns ``tcpdump -i mon0 -s <snaplen> -U -w -``
  and parses the pcap stream it writes. **UNVERIFIED on a Pi** until a
  `sentinel doctor` + live session is recorded in docs/verification-log.md
  (HARD RULE 5). The snaplen bound is enforced here AND by config validation
  (HARD RULE 2): payload bytes are never even buffered.
* :class:`IteratorWifiSource` - adapts any iterable of Observations (PCAP
  replay, the simulator, a scripted fake) to the same background-thread /
  bounded-queue interface, with optional real-time pacing.
* :class:`NullWifiMonitor` - a do-nothing backend for BLE-only runs.

Every backend is a producer writing into a bounded ``queue.Queue``; overflow
is counted as dropped frames (a health metric, never a crash). The capture
loop catches per-frame parse errors and keeps going (quality bar).
"""

from __future__ import annotations

import logging
import queue
import subprocess
import threading
import time
from typing import Callable, Iterable, List, Optional

from sentinel_rf.parse.dot11 import build_observation
from sentinel_rf.parse.observation import Observation
from sentinel_rf.parse.pcap import PcapReader
from sentinel_rf.parse.radiotap import RadiotapError, parse_radiotap

__all__ = [
    "CaptureCounters",
    "IteratorWifiSource",
    "NullWifiMonitor",
    "TcpdumpWifiMonitor",
    "WifiMonitor",
]

log = logging.getLogger(__name__)

_SENTINEL = object()


class CaptureCounters:
    """Thread-safe capture health counters."""

    def __init__(self) -> None:
        self._lock = threading.Lock()
        self.emitted = 0
        self.dropped = 0
        self.parse_errors = 0
        self.unsupported = 0
        self.errors: List[str] = []

    def note_error(self, message: str) -> None:
        with self._lock:
            self.errors.append(message[:200])

    def snapshot(self) -> dict:
        with self._lock:
            return {
                "emitted": self.emitted,
                "dropped": self.dropped,
                "parse_errors": self.parse_errors,
                "unsupported": self.unsupported,
                "errors": list(self.errors[-5:]),
            }


class WifiMonitor:
    """Base class: background thread emitting Observations into a queue.

    Subclasses implement :meth:`_capture_loop` (an iterator or a blocking
    loop) and call :meth:`_emit` for each observation. ``stop()`` is always
    safe to call from another thread and from signal handlers.
    """

    def __init__(
        self,
        out_queue: "queue.Queue",
        *,
        node_id: str,
        name: str = "wifi",
    ) -> None:
        self._queue = out_queue
        self.node_id = node_id
        self.name = name
        self.counters = CaptureCounters()
        self._stop = threading.Event()
        self.finished = threading.Event()  # set when the capture loop exits
        self._thread: Optional[threading.Thread] = None

    # -- lifecycle ---------------------------------------------------- #

    def start(self) -> None:
        if self._thread is not None:
            return
        self._stop.clear()
        self._thread = threading.Thread(
            target=self._run, name=f"sentinel-capture-{self.name}", daemon=True
        )
        self._thread.start()

    def stop(self, timeout: float = 5.0) -> None:
        self._stop.set()
        if self._thread is not None:
            self._thread.join(timeout=timeout)
            self._thread = None

    @property
    def running(self) -> bool:
        return self._thread is not None and self._thread.is_alive()

    # -- internals ---------------------------------------------------- #

    def _run(self) -> None:
        try:
            self._capture_loop()
        except Exception as exc:  # never let the thread die silently
            self.counters.note_error(f"{type(exc).__name__}: {exc}")
            log.exception("capture backend %s failed", self.name)
        finally:
            self.finished.set()

    def _capture_loop(self) -> None:
        raise NotImplementedError

    def _emit(self, observation: Observation) -> None:
        try:
            self._queue.put_nowait(observation)
            with self.counters._lock:  # noqa: SLF001 - same-module helper
                self.counters.emitted += 1
        except queue.Full:
            with self.counters._lock:  # noqa: SLF001
                self.counters.dropped += 1

    def _drain_pcap_stream(
        self, reader: PcapReader, *, salt: bytes, truncate: int, allow_raw: bool
    ) -> None:
        """Parse a live pcap stream (used by TcpdumpWifiMonitor and tests)."""
        for ts, packet in reader:
            if self._stop.is_set():
                break
            try:
                meta, dot11_bytes = parse_radiotap(packet)
            except RadiotapError:
                with self.counters._lock:  # noqa: SLF001
                    self.counters.parse_errors += 1
                continue
            obs, _ephemeral = build_observation(
                dot11_bytes,
                meta,
                ts=ts,
                node_id=self.node_id,
                salt=salt,
                truncate=truncate,
                wire_length=reader.last_orig_len,
                allow_raw=allow_raw,
            )
            if obs is None:
                with self.counters._lock:  # noqa: SLF001
                    self.counters.unsupported += 1
                continue
            self._emit(obs)


class TcpdumpWifiMonitor(WifiMonitor):
    """Live monitor-mode capture via tcpdump writing pcap to stdout.

    UNVERIFIED on Raspberry Pi hardware (HARD RULE 5): requires a monitor
    interface (Nexmon mon0 on the Pi 4B's bcm43455c0, or any monitor-mode
    interface on other hosts). The command line enforces the snaplen
    (headers only, HARD RULE 2):

        tcpdump -i <iface> -s <snaplen> -U -w -
    """

    def __init__(
        self,
        out_queue: "queue.Queue",
        *,
        iface: str,
        snaplen: int,
        node_id: str,
        salt: bytes,
        truncate: int = 16,
        allow_raw: bool = False,
        tcpdump_bin: str = "tcpdump",
    ) -> None:
        super().__init__(out_queue, node_id=node_id, name=f"tcpdump:{iface}")
        self.iface = iface
        self.snaplen = int(snaplen)
        self.salt = salt
        self.truncate = truncate
        self.allow_raw = allow_raw
        self.tcpdump_bin = tcpdump_bin
        self._proc: Optional[subprocess.Popen] = None

    def _capture_loop(self) -> None:
        cmd = [
            self.tcpdump_bin,
            "-i",
            self.iface,
            "-s",
            str(self.snaplen),
            "-U",
            "-w",
            "-",
        ]
        log.info("starting capture: %s", " ".join(cmd))
        try:
            self._proc = subprocess.Popen(  # noqa: S603 - fixed argv, no shell
                cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE
            )
        except FileNotFoundError:
            self.counters.note_error(f"{self.tcpdump_bin} not found")
            log.error("tcpdump binary not found; capture cannot start")
            return
        assert self._proc.stdout is not None
        try:
            reader = PcapReader(self._proc.stdout)
            self._drain_pcap_stream(
                reader, salt=self.salt, truncate=self.truncate, allow_raw=self.allow_raw
            )
        finally:
            self._terminate()

    def _terminate(self) -> None:
        if self._proc is None:
            return
        if self._proc.poll() is None:
            self._proc.terminate()
            try:
                self._proc.wait(timeout=5)
            except subprocess.TimeoutExpired:  # pragma: no cover - defensive
                self._proc.kill()
        for stream in (self._proc.stdout, self._proc.stderr):
            if stream is not None:
                stream.close()
        self._proc = None


class IteratorWifiSource(WifiMonitor):
    """Adapt any Iterable[Observation] to the WifiMonitor interface.

    ``speed`` controls pacing: 0 = as fast as possible (replay/tests),
    1.0 = wall-clock speed, 2.0 = twice as fast. Used by PCAP replay, the
    simulator and scripted fakes - one code path, tested on a laptop.
    """

    def __init__(
        self,
        out_queue: "queue.Queue",
        *,
        observations_factory: Callable[[], Iterable[Observation]],
        node_id: str,
        speed: float = 0.0,
        name: str = "iterator",
    ) -> None:
        super().__init__(out_queue, node_id=node_id, name=name)
        self._factory = observations_factory
        self.speed = float(speed)

    def _capture_loop(self) -> None:
        last_ts: Optional[float] = None
        for obs in self._factory():
            if self._stop.is_set():
                break
            if self.speed > 0.0 and last_ts is not None:
                delta_s = max(0.0, obs.ts - last_ts) / self.speed
                if delta_s > 0.0:
                    time.sleep(min(delta_s, 5.0))
            last_ts = obs.ts
            self._emit(obs)


class NullWifiMonitor(WifiMonitor):
    """No-op backend (BLE-only runs, unit tests)."""

    def _capture_loop(self) -> None:  # pragma: no cover - trivial
        while not self._stop.wait(0.5):
            pass


def make_queue(size: int) -> "queue.Queue":
    """Bounded observation queue (capture.queue_size)."""
    return queue.Queue(maxsize=size)
