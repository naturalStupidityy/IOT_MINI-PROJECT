"""Channel hopping (Scan mode) - Phase 2.

Scan mode cycles the monitor interface through the configured channel plan
with ``iw dev <iface> set channel <n>`` and a dwell of ``dwell_ms`` per
channel. Lock mode pins one channel and does not hop (used when the target
network is known). The iw path is **UNVERIFIED on a Pi** until evidence is
recorded in docs/verification-log.md (HARD RULE 5).

Passive only (HARD RULE 1): hopping changes the receive frequency and nothing
else - no frames are ever transmitted by this module.
"""

from __future__ import annotations

import itertools
import logging
import shutil
import subprocess
import threading
import time
from typing import List, Optional, Sequence, Tuple

__all__ = [
    "ChannelHopper",
    "FakeChannelHopper",
    "IwChannelHopper",
    "LockChannel",
    "ensure_monitor_interface",
    "iw_list_interfaces",
    "iw_set_channel",
]

log = logging.getLogger(__name__)


class ChannelHopper:
    """Background thread cycling a monitor interface through channels."""

    def __init__(self, channels: Sequence[int], dwell_ms: int, name: str = "hopper") -> None:
        if not channels:
            raise ValueError("channel plan must not be empty")
        self.channels = [int(c) for c in channels]
        self.dwell_s = max(dwell_ms, 1) / 1000.0
        self.name = name
        self.visited: List[Tuple[float, int]] = []
        self._stop = threading.Event()
        self._thread: Optional[threading.Thread] = None
        self.errors: List[str] = []

    # -- lifecycle ---------------------------------------------------- #

    def start(self) -> None:
        if self._thread is not None:
            return
        self._stop.clear()
        self._thread = threading.Thread(target=self._run, name=f"sentinel-{self.name}", daemon=True)
        self._thread.start()

    def stop(self, timeout: float = 3.0) -> None:
        self._stop.set()
        if self._thread is not None:
            self._thread.join(timeout=timeout)
            self._thread = None

    # -- override points ---------------------------------------------- #

    def _set_channel(self, channel: int) -> bool:
        """Switch the interface; return success. Subclasses override."""
        return True

    # -- loop ---------------------------------------------------------- #

    def _run(self) -> None:
        for channel in itertools.cycle(self.channels):
            if self._stop.is_set():
                return
            ok = self._set_channel(channel)
            self.visited.append((time.time(), channel))
            if not ok and len(self.errors) < 10:
                self.errors.append(f"failed to set channel {channel}")
            if self._stop.wait(self.dwell_s):
                return


class IwChannelHopper(ChannelHopper):
    """Real hopper via iw. UNVERIFIED on Pi hardware (needs mon0 + Nexmon)."""

    def __init__(
        self,
        channels: Sequence[int],
        dwell_ms: int,
        *,
        iface: str,
        iw_bin: str = "iw",
    ) -> None:
        super().__init__(channels, dwell_ms, name=f"iw-hopper:{iface}")
        self.iface = iface
        self.iw_bin = iw_bin

    def _set_channel(self, channel: int) -> bool:
        ok, _err = iw_set_channel(self.iface, channel, iw_bin=self.iw_bin)
        return ok


class FakeChannelHopper(ChannelHopper):
    """Hopper with no hardware: records visits, sets nothing."""

    def __init__(self, channels: Sequence[int], dwell_ms: int = 10) -> None:
        super().__init__(channels, dwell_ms, name="fake-hopper")


class LockChannel:
    """Lock mode: pin one channel (no thread, no hopping)."""

    def __init__(self, channel: int, *, iface: str, iw_bin: str = "iw") -> None:
        self.channel = int(channel)
        self.iface = iface
        self.iw_bin = iw_bin

    def start(self) -> bool:
        ok, err = iw_set_channel(self.iface, self.channel, iw_bin=self.iw_bin)
        if ok:
            log.info("locked %s to channel %d", self.iface, self.channel)
        else:
            log.error("could not lock %s to channel %d: %s", self.iface, self.channel, err)
        return ok

    def stop(self) -> None:  # symmetry with ChannelHopper
        pass

    @property
    def visited(self) -> List[Tuple[float, int]]:
        return [(0.0, self.channel)]


# --------------------------------------------------------------------------- #
# iw plumbing (all UNVERIFIED on a Pi until docs/verification-log.md says so)
# --------------------------------------------------------------------------- #


def _run(cmd: Sequence[str], timeout: float = 5.0) -> Tuple[int, str, str]:
    try:
        proc = subprocess.run(  # noqa: S603 - fixed argv, no shell
            cmd, capture_output=True, text=True, timeout=timeout
        )
        return proc.returncode, proc.stdout, proc.stderr
    except FileNotFoundError:
        return 127, "", f"{cmd[0]}: binary not found"
    except subprocess.TimeoutExpired:
        return 124, "", f"{cmd[0]}: timed out"


def iw_set_channel(iface: str, channel: int, *, iw_bin: str = "iw") -> Tuple[bool, str]:
    """Set the interface channel. Returns (ok, error). UNVERIFIED on Pi."""
    rc, _out, err = _run([iw_bin, "dev", iface, "set", "channel", str(int(channel))])
    return rc == 0, err.strip()


def iw_list_interfaces(iw_bin: str = "iw") -> List[str]:
    """List wireless interface names via ``iw dev`` (empty if iw is absent)."""
    if shutil.which(iw_bin) is None:
        return []
    rc, out, _err = _run([iw_bin, "dev"])
    if rc != 0:
        return []
    interfaces = []
    for line in out.splitlines():
        line = line.strip()
        if line.startswith("Interface "):
            interfaces.append(line.split(None, 1)[1])
    return interfaces


def ensure_monitor_interface(
    *,
    base_iface: str = "wlan0",
    mon_iface: str = "mon0",
    iw_bin: str = "iw",
    ip_bin: str = "ip",
) -> Tuple[bool, str]:
    """Create and raise a monitor interface (Scan-mode bring-up).

    ``iw dev wlan0 interface add mon0 type monitor && ip link set mon0 up``.
    UNVERIFIED on Raspberry Pi OS with the built-in Wi-Fi: stock kernels
    refuse monitor mode on the bcm43455c0; Nexmon-patched firmware is the
    primary path (see TODO.md and docs/DEPLOYMENT.md). Failures are returned,
    never raised, so `sentinel doctor` can report them.
    """
    rc, out, err = _run(
        [iw_bin, "dev", base_iface, "interface", "add", mon_iface, "type", "monitor"]
    )
    if rc != 0:
        return False, f"iw interface add failed: {err.strip() or out.strip()}"
    rc, out, err = _run([ip_bin, "link", "set", mon_iface, "up"])
    if rc != 0:
        return False, f"ip link set up failed: {err.strip() or out.strip()}"
    return True, f"{mon_iface} up (monitor mode)"
