"""Capture backends (Phase 2; hardware paths UNVERIFIED).

One interface, several sources: live monitor-mode Wi-Fi (tcpdump subprocess,
UNVERIFIED on Pi), live BLE scanning (bleak, UNVERIFIED), PCAP replay, the
simulator, and software fakes for laptop development. The CaptureManager
wires them to a bounded queue with drop accounting. Live backends are not
considered working on a Pi until `sentinel doctor` evidence is recorded in
docs/verification-log.md.
"""

from sentinel_rf.capture.channel_hopper import (
    ChannelHopper,
    FakeChannelHopper,
    IwChannelHopper,
    LockChannel,
)
from sentinel_rf.capture.manager import CaptureManager
from sentinel_rf.capture.wifi_monitor import (
    CaptureCounters,
    IteratorWifiSource,
    NullWifiMonitor,
    TcpdumpWifiMonitor,
    WifiMonitor,
)

__all__ = [
    "CaptureCounters",
    "CaptureManager",
    "ChannelHopper",
    "FakeChannelHopper",
    "IteratorWifiSource",
    "IwChannelHopper",
    "LockChannel",
    "NullWifiMonitor",
    "TcpdumpWifiMonitor",
    "WifiMonitor",
]
