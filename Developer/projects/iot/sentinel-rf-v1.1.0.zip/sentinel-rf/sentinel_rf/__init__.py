"""SENTINEL-RF: passive RF sensing on a Raspberry Pi 4B.

Detects and locates Wi-Fi/BLE devices behaving like live-streaming hidden
cameras, using header-only passive capture. See README.md for the hard rules
(passive-only, headers-only, privacy-by-design) and the phase plan.

Development is laptop-first: every hardware-facing path sits behind an
interface with a software fake, and anything not yet verified on a real
Raspberry Pi is marked UNVERIFIED (docs/verification-log.md).
"""

from sentinel_rf.config import ConfigError, SentinelConfig, load_config
from sentinel_rf.crypto import load_or_create_salt, mac_hash, new_salt, normalize_mac
from sentinel_rf.defaults import default_config
from sentinel_rf.parse.observation import (
    OBSERVATION_SCHEMA_VERSION,
    Observation,
    Role,
    Source,
)
from sentinel_rf.privacy import (
    PrivacyViolation,
    assert_no_raw_mac,
    is_locally_administered,
    looks_like_raw_mac,
)
from sentinel_rf.transport.store import InMemoryStore, Store

__version__ = "1.1.0"

__all__ = [
    "OBSERVATION_SCHEMA_VERSION",
    "Observation",
    "Role",
    "Source",
    "ConfigError",
    "SentinelConfig",
    "load_config",
    "default_config",
    "PrivacyViolation",
    "assert_no_raw_mac",
    "is_locally_administered",
    "looks_like_raw_mac",
    "load_or_create_salt",
    "mac_hash",
    "new_salt",
    "normalize_mac",
    "InMemoryStore",
    "Store",
    "__version__",
]
