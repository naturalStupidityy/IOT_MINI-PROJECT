"""SSID pattern scoring (Phase 3) - priors evidence for Wi-Fi networks.

Scores the (memory-only) SSID of an access point against the watchlist.
The SSID is payload: the rule book sees it live, returns a score and
plain-English reasons, and the SSID itself is dropped immediately after
(HARD RULE 2/3; DECISIONS.md D019).
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import List, Optional

from sentinel_rf.intel.watchlist import Watchlist

__all__ = ["RuleResult", "SsidRuleBook"]


@dataclass(frozen=True)
class RuleResult:
    """A priors-layer score with human-readable evidence."""

    score: float  # 0..100 contribution to the priors component
    reasons: List[str] = field(default_factory=list)
    matched: List[str] = field(default_factory=list)

    @classmethod
    def empty(cls) -> "RuleResult":
        return cls(score=0.0)


class SsidRuleBook:
    """Match SSIDs against watchlist patterns (case-insensitive regexes)."""

    def __init__(self, watchlist: Watchlist) -> None:
        self._patterns = watchlist.ssid_patterns
        self._empty_score = watchlist.empty_ssid_score

    def score(self, ssid: Optional[str]) -> RuleResult:
        if ssid is None:
            return RuleResult.empty()
        reasons: List[str] = []
        matched: List[str] = []
        total = 0.0
        if ssid == "" and self._empty_score > 0:
            total += self._empty_score
            reasons.append(
                "Network broadcasts a hidden (blank) SSID - sometimes used to stay inconspicuous"
            )
            matched.append("<hidden ssid>")
            return RuleResult(score=min(total, 100.0), reasons=reasons, matched=matched)
        for pattern in self._patterns:
            hit = pattern.regex.search(ssid)
            if hit:
                total += pattern.score
                reasons.append(pattern.reason + f" (matched '{hit.group(0)}')")
                matched.append(pattern.regex.pattern)
        return RuleResult(score=min(total, 100.0), reasons=reasons, matched=matched)
