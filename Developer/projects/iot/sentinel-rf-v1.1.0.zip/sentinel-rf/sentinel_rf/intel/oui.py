"""Offline OUI (organizationally unique identifier) lookup (Phase 3).

Maps the first three bytes of a raw MAC address to a vendor name and a
coarse category. The packaged CSV is a small curated subset of the public
IEEE registry (see the file header for the caveat); the authoritative
registry can be imported offline with :func:`import_ieee_csv`.

Only ever used on raw MACs that are live in memory (parse time); the vendor
name feeds the priors evidence layer and is never persisted alongside the
salted hash (DECISIONS.md D025).
"""

from __future__ import annotations

import csv
import io
import logging
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, Optional, Tuple, Union

__all__ = ["OuiDb", "VendorInfo", "import_ieee_csv", "load_packaged_oui"]

log = logging.getLogger(__name__)

# Prior scores per category (0..1) - how strongly the vendor alone suggests
# "could be a streaming camera". Strong vendors make dedicated surveillance
# gear; weak vendors' chips appear in cheap cameras AND countless other IoT
# devices, so they only nudge the prior.
CATEGORY_SCORES = {
    "camera_strong": 1.0,
    "camera_weak": 0.35,
    "infrastructure": 0.0,
    "client": 0.0,
    "sbc": 0.05,  # a Pi *can* be a hidden camera; usually it is a maker box
}


@dataclass(frozen=True)
class VendorInfo:
    vendor: str
    category: str

    @property
    def prior_score(self) -> float:
        return CATEGORY_SCORES.get(self.category, 0.0)


class OuiDb:
    """Prefix -> VendorInfo lookup (AA:BB:CC form, case-insensitive)."""

    def __init__(self, entries: Dict[str, VendorInfo]) -> None:
        self._entries = {prefix.upper(): info for prefix, info in entries.items()}

    def __len__(self) -> int:
        return len(self._entries)

    def lookup(self, mac: str) -> Optional[VendorInfo]:
        """Vendor of the OUI prefix of *mac* (None when unknown)."""
        prefix = mac.strip().upper()[:8]
        if len(prefix) < 8 or prefix[2] != ":" or prefix[5] != ":":
            # tolerate bare form too (24:0a:c4 vs 240ac4)
            bare = mac.strip().lower().replace(":", "").replace("-", "")
            if len(bare) >= 6:
                prefix = f"{bare[0:2]}:{bare[2:4]}:{bare[4:6]}".upper()
            else:
                return None
        return self._entries.get(prefix)

    def categories(self) -> Dict[str, int]:
        counts: Dict[str, int] = {}
        for info in self._entries.values():
            counts[info.category] = counts.get(info.category, 0) + 1
        return counts


def _parse_csv(text: str) -> Dict[str, VendorInfo]:
    entries: Dict[str, VendorInfo] = {}
    reader = csv.reader(io.StringIO(text))
    for row in reader:
        if not row or row[0].lstrip().startswith("#"):
            continue
        if row[0].strip().lower() == "prefix":  # curated-file header
            continue
        if len(row) < 3:
            continue
        prefix, vendor, category = row[0].strip(), row[1].strip(), row[2].strip()
        if category not in CATEGORY_SCORES:
            log.warning("OUI row with unknown category skipped: %r", row)
            continue
        bare = prefix.replace(":", "").replace("-", "")
        if len(bare) != 6:
            continue
        canonical = f"{bare[0:2]}:{bare[2:4]}:{bare[4:6]}".upper()
        entries[canonical] = VendorInfo(vendor=vendor, category=category)
    return entries


def load_packaged_oui() -> OuiDb:
    """Load the curated subset shipped inside the package."""
    from importlib import resources

    ref = resources.files("sentinel_rf.intel").joinpath("data/oui.csv")
    with resources.as_file(ref) as path:
        text = Path(path).read_text(encoding="utf-8")
    return OuiDb(_parse_csv(text))


def import_ieee_csv(path: Union[str, Path], *, extra_only: bool = False) -> Tuple[OuiDb, int]:
    """Extend the packaged DB from an IEEE registry CSV (offline, user-supplied).

    The IEEE file (oui.csv from standards-oui.ieee.org) has columns:
    registry, assignment (the prefix), organization name. Vendors whose
    names match known surveillance brands get camera_strong; others land in
    a neutral category unless already known. Returns (db, new_entries).
    """
    base = load_packaged_oui()
    existing = dict(base._entries)  # noqa: SLF001 - same-module helper
    text = Path(path).read_text(encoding="utf-8", errors="replace")
    reader = csv.reader(io.StringIO(text))
    added = 0
    for row in reader:
        if not row or len(row) < 3:
            continue
        if row[0].strip().lower() not in ("oui", "ma-l", "ma-m", "iab", "oui36"):
            continue
        prefix, organization = row[1].strip().upper(), row[2].strip()
        bare = prefix.replace(":", "").replace("-", "")
        if len(bare) != 6:
            continue
        canonical = f"{bare[0:2]}:{bare[2:4]}:{bare[4:6]}"
        if canonical in existing and extra_only:
            continue
        lowered = organization.lower()
        if any(
            brand in lowered
            for brand in (
                "hikvision",
                "dahua",
                "axis comm",
                "vivotek",
                "foscam",
                "reolink",
                "amcrest",
                "dropcam",
                "nest labs",
            )
        ):
            category = "camera_strong"
        elif any(chip in lowered for chip in ("espressif", "realtek semiconductor")):
            category = "camera_weak"
        else:
            category = "client"
        existing[canonical] = VendorInfo(vendor=organization[:60], category=category)
        added += 1
    return OuiDb(existing), added


def vendor_lookup_factory(db: Optional[OuiDb] = None):
    """Callable[str, Optional[str]] suitable for the dot11 builder hook."""

    db = db or load_packaged_oui()

    def lookup(mac: str) -> Optional[str]:
        info = db.lookup(mac)
        return info.vendor if info else None

    return lookup
