"""BLE advertisement pattern scoring (Phase 3) - priors evidence.

Scores the structured BLE fields the Observation model already carries
(local name, service UUIDs, manufacturer company id, randomized address)
against the watchlist. This is corroboration only (default fusion weight
10/100): a camera-like BLE tag near a streaming Wi-Fi device strengthens
the case; absence proves nothing.
"""

from __future__ import annotations

from typing import Iterable, List, Optional

from sentinel_rf.intel.ssid_rules import RuleResult
from sentinel_rf.intel.watchlist import Watchlist

__all__ = ["BleRuleBook"]


class BleRuleBook:
    """Match BLE advertisement fields against watchlist patterns."""

    def __init__(self, watchlist: Watchlist) -> None:
        self._name_patterns = watchlist.ble_name_patterns
        self._uuid_scores = watchlist.ble_service_uuid_scores
        self._company_ids = watchlist.ble_company_ids
        self._random_score = watchlist.ble_random_mac_score

    def score(
        self,
        name: Optional[str],
        service_uuids: Iterable[str] = (),
        company_id: Optional[int] = None,
        addr_is_random: bool = False,
    ) -> RuleResult:
        reasons: List[str] = []
        matched: List[str] = []
        total = 0.0
        if name:
            for pattern in self._name_patterns:
                hit = pattern.regex.search(name)
                if hit:
                    total += pattern.score
                    reasons.append(pattern.reason + f" (matched '{hit.group(0)}')")
                    matched.append(pattern.regex.pattern)
        for uuid in service_uuids:
            bonus = self._uuid_scores.get(str(uuid).lower())
            if bonus:
                total += float(bonus)
                reasons.append(f"Advertised service UUID {uuid} is on the watchlist")
                matched.append(str(uuid))
        if company_id is not None:
            entry = self._company_ids.get(int(company_id))
            if entry:
                total += float(entry.get("score", 0))
                vendor = entry.get("vendor", "unknown vendor")
                reasons.append(
                    f"Manufacturer is {vendor} - common in low-cost camera boards (weak signal)"
                )
                matched.append(f"company:{company_id}")
        if addr_is_random and self._random_score > 0:
            # NOTE: randomized addresses are the privacy default on phones;
            # many cheap cameras keep factory addresses. Keep the bonus tiny.
            total += self._random_score
        return RuleResult(score=min(total, 100.0), reasons=reasons, matched=matched)

    def score_observation_fields(self, obs) -> RuleResult:
        """Score directly from a BLE Observation's whitelisted fields."""
        return self.score(
            name=obs.name,
            service_uuids=obs.service_uuids,
            company_id=obs.company_id,
            addr_is_random=obs.addr_is_random,
        )
