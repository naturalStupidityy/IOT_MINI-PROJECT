"""Intel: priors evidence from OUI, SSID and BLE watchlists (Phase 3).

Everything here produces PRIORS, never verdicts: a watchlist match only
shifts the fusion input (default weight 15/100). Data files are offline and
user-extensible; nothing is fetched at runtime. SSIDs and vendor OUIs live
only in the in-memory IntelCache and are never persisted (HARD RULE 2/3).
"""

from sentinel_rf.intel.ble_rules import BleRuleBook
from sentinel_rf.intel.cache import DeviceIntel, IntelCache
from sentinel_rf.intel.oui import OuiDb, VendorInfo, import_ieee_csv, load_packaged_oui
from sentinel_rf.intel.ssid_rules import RuleResult, SsidRuleBook
from sentinel_rf.intel.watchlist import Watchlist, load_watchlist

__all__ = [
    "BleRuleBook",
    "DeviceIntel",
    "IntelCache",
    "OuiDb",
    "RuleResult",
    "SsidRuleBook",
    "VendorInfo",
    "Watchlist",
    "import_ieee_csv",
    "load_packaged_oui",
    "load_watchlist",
]
