"""Live intel cache: per-device priors inputs, in memory only (Phase 3).

Collects the memory-only evidence the priors layer needs per device hash:
OUI vendor (computed at parse time from the raw MAC, before hashing),
the latest SSID seen in beacons, and BLE local names. Nothing here is ever
serialized - the store and exports only ever see Observation dicts and
component scores (HARD RULE 2/3; DECISIONS.md D019, D025).
"""

from __future__ import annotations

import threading
from dataclasses import dataclass
from typing import Dict, Optional

from sentinel_rf.intel.oui import OuiDb, VendorInfo, load_packaged_oui
from sentinel_rf.parse.observation import Observation, Source

__all__ = ["DeviceIntel", "IntelCache"]


@dataclass
class DeviceIntel:
    """Priors inputs for one device (all Optional, all memory-only)."""

    vendor: Optional[str] = None
    vendor_category: Optional[str] = None
    ssid: Optional[str] = None
    ble_name: Optional[str] = None

    def as_dict(self) -> Dict[str, Optional[str]]:
        # Deliberately excludes nothing else: vendor/ssid/ble_name are coarse
        # priors inputs; safe to show on the dashboard, never stored.
        return {
            "vendor": self.vendor,
            "ssid": self.ssid,
            "ble_name": self.ble_name,
        }


class IntelCache:
    """Thread-safe accumulation of per-device priors inputs."""

    def __init__(self, oui_db: Optional[OuiDb] = None) -> None:
        self._oui = oui_db if oui_db is not None else load_packaged_oui()
        self._lock = threading.Lock()
        self._by_device: Dict[str, DeviceIntel] = {}

    @property
    def oui_db(self) -> OuiDb:
        return self._oui

    def vendor_of(self, raw_mac: str) -> Optional[VendorInfo]:
        """Vendor lookup for a raw MAC (parse-time only)."""
        return self._oui.lookup(raw_mac)

    def update(self, obs: Observation, ephemeral=None) -> None:
        """Fold one observation (+ optional parse-time ephemeral) into the cache."""
        with self._lock:
            entry = self._by_device.setdefault(obs.addr_hash, DeviceIntel())
            if ephemeral is not None:
                vendor = getattr(ephemeral, "vendor", None)
                if vendor:
                    entry.vendor = vendor
                category = getattr(ephemeral, "vendor_category", None)
                if category:
                    entry.vendor_category = category
                ssid = getattr(ephemeral, "ssid", None)
                if ssid is not None:
                    entry.ssid = ssid
            if obs.source is Source.BLE and obs.name:
                entry.ble_name = obs.name

    def seed(self, addr_hash: str, intel: DeviceIntel, *, override: bool = False) -> None:
        """Pre-populate intel for a device (simulator ground truth path).

        Merges by default (first writer wins); override=True replaces every
        non-None field - used by tests to stage specific prior situations.
        """
        with self._lock:
            current = self._by_device.setdefault(addr_hash, DeviceIntel())
            pairs = (
                ("vendor", intel.vendor),
                ("vendor_category", intel.vendor_category),
                ("ssid", intel.ssid),
                ("ble_name", intel.ble_name),
            )
            for attr, value in pairs:
                if value is None:
                    continue
                if override or getattr(current, attr) is None:
                    setattr(current, attr, value)

    def get(self, addr_hash: str) -> DeviceIntel:
        with self._lock:
            return self._by_device.get(addr_hash, DeviceIntel())

    def devices(self) -> int:
        with self._lock:
            return len(self._by_device)
