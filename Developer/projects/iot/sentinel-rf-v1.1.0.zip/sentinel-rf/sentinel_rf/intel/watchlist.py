"""Watchlist loading (Phase 3) - patterns that feed the priors layer.

The canonical watchlist is ``configs/watchlist.yaml``; this module keeps a
code default in sync (the same pattern as config defaults, DECISIONS.md
D011) so an installed package still works without the repo checkout.
Resolution order: explicit path, ``$SENTINEL_RF_WATCHLIST``,
``./configs/watchlist.yaml``, then the built-in default.

Every pattern is a heuristic PRIOR, never a verdict: a match only nudges
the fusion input (default weight 15/100); an alert still needs traffic or
stimulus evidence. Scores are 0..100 contributions to the priors component.
"""

from __future__ import annotations

import os
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, List, Optional, Union

import yaml

__all__ = ["DEFAULT_WATCHLIST", "Watchlist", "load_watchlist"]

DEFAULT_WATCHLIST: Dict = {
    "wifi": {
        "ssid_patterns": [
            {
                "pattern": "(?i)\\bIPCAM\\b",
                "score": 40,
                "reason": "SSID contains 'IPCAM', a common IP-camera naming convention",
            },
            {
                "pattern": "(?i)\\bIPC[-_ ]?[0-9A-F]{2,}",
                "score": 35,
                "reason": "SSID looks like a default IP-camera hotspot name (IPC-xxxx)",
            },
            {
                "pattern": "(?i)^(HC|HDX)[-_ ]?[0-9]",
                "score": 30,
                "reason": "Matches the default AP name of several camera lines (HCx/HDx)",
            },
            {
                "pattern": "(?i)YCC365",
                "score": 45,
                "reason": "Default SSID of a widely-sold low-cost camera family",
            },
            {
                "pattern": "(?i)\\bV380\\b",
                "score": 45,
                "reason": "Default SSID of a widely-sold low-cost camera family",
            },
            {
                "pattern": "(?i)\\b(Yoosee|SriCam|CamHi|LookCam|AWCAM)\\b",
                "score": 40,
                "reason": "Matches known consumer camera app/hotspot names",
            },
            {
                "pattern": "(?i)\\bcamera\\b",
                "score": 25,
                "reason": "SSID mentions 'camera' outright",
            },
            {
                "pattern": "(?i)\\b(spy|hidden)\\b",
                "score": 35,
                "reason": "SSID uses concealment-flavoured wording",
            },
            {
                "pattern": "(?i)^HD[-_ ]?[0-9]{1,4}$",
                "score": 25,
                "reason": "Generic default name used by several cheap camera lines",
            },
        ],
        "empty_ssid_score": 15,
    },
    "ble": {
        "name_patterns": [
            {
                "pattern": "(?i)\\bIPC[-_ ]?[0-9A-F]{2,}",
                "score": 40,
                "reason": "BLE name looks like a camera companion tag (IPC-xxxx)",
            },
            {
                "pattern": "(?i)\\bcam(era)?\\b",
                "score": 30,
                "reason": "BLE local name mentions 'cam'/'camera'",
            },
            {
                "pattern": "(?i)\\b(Yoosee|SriCam|CamHi|YCC|V380)\\b",
                "score": 35,
                "reason": "Matches known camera companion app names",
            },
        ],
        "service_uuids": {},  # no verified camera-specific UUIDs yet (D024)
        "company_ids": {
            "89": {
                "vendor": "Nordic Semiconductor",
                "score": 10,
                "reason": "BLE SoC common in low-cost camera boards (weak signal)",
            },
        },
        "random_mac_score": 5,
    },
}


@dataclass(frozen=True)
class SsidPattern:
    regex: "re.Pattern[str]"
    score: float
    reason: str


@dataclass(frozen=True)
class NamePattern:
    regex: "re.Pattern[str]"
    score: float
    reason: str


@dataclass(frozen=True)
class Watchlist:
    """Validated watchlist ready for the rule books."""

    ssid_patterns: List[SsidPattern] = field(default_factory=list)
    empty_ssid_score: float = 15.0
    ble_name_patterns: List[NamePattern] = field(default_factory=list)
    ble_service_uuid_scores: Dict[str, float] = field(default_factory=dict)
    ble_company_ids: Dict[int, Dict[str, object]] = field(default_factory=dict)
    ble_random_mac_score: float = 5.0

    @classmethod
    def from_dict(cls, data: Dict) -> "Watchlist":
        wifi = data.get("wifi") or {}
        ble = data.get("ble") or {}
        ssid_patterns = []
        for entry in wifi.get("ssid_patterns") or []:
            try:
                regex = re.compile(entry["pattern"])
            except re.error as exc:
                raise ValueError(f"invalid SSID pattern {entry.get('pattern')!r}: {exc}") from exc
            ssid_patterns.append(
                SsidPattern(
                    regex=regex,
                    score=float(entry.get("score", 20)),
                    reason=str(entry.get("reason", "watchlist SSID pattern matched")),
                )
            )
        name_patterns = []
        for entry in ble.get("name_patterns") or []:
            try:
                regex = re.compile(entry["pattern"])
            except re.error as exc:
                raise ValueError(
                    f"invalid BLE name pattern {entry.get('pattern')!r}: {exc}"
                ) from exc
            name_patterns.append(
                NamePattern(
                    regex=regex,
                    score=float(entry.get("score", 20)),
                    reason=str(entry.get("reason", "watchlist BLE name matched")),
                )
            )
        company_ids: Dict[int, Dict[str, object]] = {}
        for key, value in (ble.get("company_ids") or {}).items():
            try:
                company_ids[int(key)] = dict(value)
            except (TypeError, ValueError) as exc:
                raise ValueError(f"invalid BLE company id {key!r}") from exc
        return cls(
            ssid_patterns=ssid_patterns,
            empty_ssid_score=float(wifi.get("empty_ssid_score", 15)),
            ble_name_patterns=name_patterns,
            ble_service_uuid_scores={
                str(k): float(v) for k, v in (ble.get("service_uuids") or {}).items()
            },
            ble_company_ids=company_ids,
            ble_random_mac_score=float(ble.get("random_mac_score", 5)),
        )


def load_watchlist(path: Optional[Union[str, Path]] = None) -> Watchlist:
    """Load and validate the watchlist (resolution chain, never fetches)."""
    resolved: Optional[Path] = None
    if path is not None:
        resolved = Path(path)
    elif os.environ.get("SENTINEL_RF_WATCHLIST"):
        resolved = Path(os.environ["SENTINEL_RF_WATCHLIST"])
    elif Path("configs/watchlist.yaml").is_file():
        resolved = Path("configs/watchlist.yaml")
    if resolved is not None:
        data = yaml.safe_load(resolved.read_text(encoding="utf-8"))
        if not isinstance(data, dict):
            raise ValueError(f"{resolved}: watchlist must be a mapping")
        return Watchlist.from_dict(data)
    return Watchlist.from_dict(DEFAULT_WATCHLIST)
