"""Pipeline: capture -> features/intel -> detection -> store/transport.

One object wires the whole sensing path together and exposes live state
for the CLI console renderer and the FastAPI dashboard:

    source (manager) -> tracker + intel cache + stimulus tracker
                     -> detector (every detect interval)
                     -> store (batched) + MQTT summaries + alert list

Event-time detection ticks keep replay/sim deterministic; a wall-clock
fallback ticks live captures even when no frames arrive. Every stage is
fail-soft: a store or transport error is logged and counted, never allowed
to stop sensing (quality bar).
"""

from __future__ import annotations

import logging
import threading
import time
from typing import Any, Callable, Dict, List, Optional

from sentinel_rf.capture.manager import CaptureManager
from sentinel_rf.config import SentinelConfig
from sentinel_rf.detect.engine import Alert, Detector
from sentinel_rf.detect.stimulus import StimulusSession, StimulusTracker
from sentinel_rf.features.windows import DeviceTracker
from sentinel_rf.intel.cache import IntelCache
from sentinel_rf.locate.anchors import RoomProfile
from sentinel_rf.locate.grid import GridLocator
from sentinel_rf.locate.lsq import wls_estimate
from sentinel_rf.locate.pathloss import median_rssi
from sentinel_rf.parse.observation import Observation
from sentinel_rf.privacy import assert_no_raw_mac
from sentinel_rf.system.resources import ResourceMonitor

__all__ = ["Pipeline"]

log = logging.getLogger(__name__)


class Pipeline:
    """Owns the sensing path and the live state the UI reads."""

    def __init__(
        self,
        config: SentinelConfig,
        *,
        manager: CaptureManager,
        detector: Detector,
        tracker: Optional[DeviceTracker] = None,
        intel: Optional[IntelCache] = None,
        store=None,
        room_profile: Optional[RoomProfile] = None,
        mesh_collector=None,
        mqtt=None,
        thingspeak=None,
        resources: Optional[ResourceMonitor] = None,
        detect_interval_s: float = 5.0,
        allow_raw: bool = False,
    ) -> None:
        self.config = config
        self.manager = manager
        self.detector = detector
        self.tracker = tracker if tracker is not None else DeviceTracker(allow_raw=allow_raw)
        self.intel = intel if intel is not None else IntelCache()
        self.store = store
        self.room_profile = room_profile
        self.mesh_collector = mesh_collector
        self.mqtt = mqtt
        self.thingspeak = thingspeak
        self.resources = resources if resources is not None else ResourceMonitor()
        self.detect_interval_s = float(detect_interval_s)
        self.allow_raw = bool(allow_raw)

        self.stimulus_session = StimulusSession(config.detect.stimulus)
        self.stimulus_tracker = StimulusTracker(self.stimulus_session)
        if self.detector.stimulus is None:
            self.detector.stimulus = self.stimulus_tracker

        self.started_at: Optional[float] = None
        self.alerts: List[Alert] = []
        self._stop = threading.Event()
        self._lock = threading.Lock()
        self.counters = {"processed": 0, "store_errors": 0, "transport_errors": 0}
        self._next_event_tick: Optional[float] = None
        self._last_wall_tick = 0.0

    # ------------------------------------------------------------------ #
    # Main loop
    # ------------------------------------------------------------------ #

    def run(
        self,
        *,
        duration_s: Optional[float] = None,
        on_tick: Optional[Callable[["Pipeline"], None]] = None,
    ) -> None:
        """Blocking sensing loop (call from a thread under the dashboard)."""
        self.manager.start()
        self.resources.start()
        self.started_at = time.time()
        self._stop.clear()
        self._next_event_tick = None
        self._last_wall_tick = time.time()
        last_event_ts: Optional[float] = None
        deadline = (time.time() + duration_s) if duration_s else None
        log.info("pipeline running (interval %.1fs)", self.detect_interval_s)
        try:
            while not self._stop.is_set():
                if deadline is not None and time.time() >= deadline:
                    break
                item = self.manager.poll(0.5)
                if item is None:
                    if self.manager.finished():
                        break
                    # live idle: wall-clock detection tick
                    if self.idle_tick() and on_tick:
                        on_tick(self)
                    continue
                last_event_ts = item.ts
                if self.feed(item) and on_tick:
                    on_tick(self)
        except KeyboardInterrupt:  # pragma: no cover - interactive
            log.info("interrupted; shutting down pipeline")
        finally:
            self._detect_tick(last_event_ts or time.time())
            self.shutdown()

    def feed(self, observation: Observation) -> bool:
        """Process one observation; run a detection tick when due.

        Ticks on EVENT time (deterministic for replay/sim, however fast the
        stream is played back). Returns True when a tick ran.
        """
        self._process(observation)
        if self._next_event_tick is None or observation.ts >= self._next_event_tick:
            self._next_event_tick = observation.ts + self.detect_interval_s
            self._last_wall_tick = time.time()
            self._detect_tick(observation.ts)
            return True
        return False

    def idle_tick(self) -> bool:
        """Wall-clock tick for quiet live captures; True when a tick ran."""
        if time.time() - self._last_wall_tick >= self.detect_interval_s:
            self._last_wall_tick = time.time()
            self._detect_tick(time.time())
            return True
        return False

    def stop(self) -> None:
        self._stop.set()

    def shutdown(self) -> None:
        self.manager.stop()
        self.resources.stop()
        if self.store is not None:
            try:
                self.store.flush()
            except Exception:  # pragma: no cover - defensive
                log.exception("store flush failed at shutdown")
        if self.mqtt is not None:
            self.mqtt.disconnect()

    def _process(self, obs: Observation) -> None:
        try:
            self.tracker.update(obs)
            self.intel.update(obs)
            self.stimulus_tracker.update(obs)
        except Exception:  # pragma: no cover - defensive
            log.exception("failed to process observation; skipping")
            return
        self.counters["processed"] += 1
        if self.store is not None:
            try:
                self.store.add_observation(obs)
            except Exception:
                self.counters["store_errors"] += 1
                log.exception("store write failed (counted, continuing)")

    def _detect_tick(self, now: float) -> None:
        try:
            raised = self.detector.process(self.tracker, self.intel, now)
        except Exception:  # pragma: no cover - defensive
            log.exception("detection tick failed")
            return
        if raised:
            with self._lock:
                self.alerts.extend(raised)
                del self.alerts[: max(0, len(self.alerts) - 200)]
            for alert in raised:
                log.warning(
                    "ALERT %s score=%.1f band=%s: %s",
                    alert.addr_hash,
                    alert.score,
                    alert.band,
                    "; ".join(alert.reasons[:3]),
                )
            if self.store is not None:
                for alert in raised:
                    try:
                        self.store.add_alert(alert.to_dict())
                    except Exception:
                        self.counters["store_errors"] += 1
        self._publish_summaries()
        self._publish_telemetry()

    # ------------------------------------------------------------------ #
    # Transport
    # ------------------------------------------------------------------ #

    def _publish_summaries(self) -> None:
        if self.mqtt is None:
            return
        devices = []
        for addr_hash, score in self.detector.latest.items():
            window = self.tracker.window(addr_hash)
            rssis = [o.rssi_dbm for o in window.long] if window else []
            payload = {
                "addr_hash": addr_hash,
                "role": score.features.get("role_ap", 0.0) >= 0.5 and "ap" or "sta",
                "rssi_median": median_rssi(rssis) if rssis else None,
                "score": score.score,
                "band": score.band,
            }
            try:
                assert_no_raw_mac(payload, where="pipeline.summary")
            except Exception:  # pragma: no cover - defensive
                continue
            devices.append(payload)
        message = {
            "node_id": self.config.mqtt.node_id,
            "ts": time.time(),
            "devices": devices[:100],
        }
        try:
            self.mqtt.publish_devices(message)
        except Exception:
            self.counters["transport_errors"] += 1
            log.exception("MQTT publish failed (counted, continuing)")

    def _publish_telemetry(self) -> None:
        if self.thingspeak is None or not self.alerts:
            return
        latest = max(self.alerts, key=lambda a: a.ts) if self.alerts else None
        if latest is None:
            return
        try:
            self.thingspeak.send(
                {
                    "field1": round(latest.score, 1),
                    "field2": len(self.alerts),
                    "field3": round(self.manager.stats().get("drop_pct", 0.0), 3),
                }
            )
        except Exception:  # pragma: no cover - defensive
            log.exception("telemetry publish failed")

    # ------------------------------------------------------------------ #
    # Live state (API/CLI)
    # ------------------------------------------------------------------ #

    def state(self, *, reveal: bool = False) -> Dict[str, Any]:
        capture = self.manager.stats()
        resources = self.resources.latest() or {}
        devices = []
        for addr_hash, score in sorted(
            self.detector.latest.items(), key=lambda kv: kv[1].score, reverse=True
        ):
            device = score.to_dict()
            window = self.tracker.window(addr_hash)
            device["last_seen"] = window.last_seen if window else None
            device["n_frames"] = int(score.features.get("n_frames", 0.0))
            device["vendor"] = self.intel.get(addr_hash).vendor
            device["ble_name"] = self.intel.get(addr_hash).ble_name
            device["raw_addr"] = (
                self.tracker.raw_mac(addr_hash) if (reveal and self.allow_raw) else None
            )
            devices.append(device)
        return {
            "version": _version(),
            "uptime_s": round(time.time() - self.started_at, 1) if self.started_at else 0.0,
            "counters": self.counters,
            "capture": capture,
            "resources": resources,
            "privacy": {
                "allow_raw_mac_live": self.allow_raw,
                "salt_file_configured": self.config.privacy.salt_file is not None,
            },
            "stimulus": {
                "phase": self.stimulus_session.phase.value,
                "n_marks": len(self.stimulus_session.marks),
                "baseline_s": self.stimulus_session.config.baseline_s,
            },
            "devices": devices,
            "alerts": [a.to_dict() for a in reversed(self.alerts[-50:])],
            "n_devices": len(devices),
        }

    # ------------------------------------------------------------------ #
    # Stimulus control (API/CLI)
    # ------------------------------------------------------------------ #

    def stimulus_action(self, action: str) -> Dict[str, Any]:
        session = self.stimulus_session
        action = action.strip().lower()
        try:
            if action == "start":
                session.start()
                return {
                    "ok": True,
                    "phase": session.phase.value,
                    "message": (
                        f"baseline running ({session.config.baseline_s}s) - " "keep the room still"
                    ),
                }
            if action == "mark_on":
                session.mark(True)
                return {"ok": True, "phase": session.phase.value, "message": "stimulus ON marked"}
            if action == "mark_off":
                session.mark(False)
                return {"ok": True, "phase": session.phase.value, "message": "stimulus OFF marked"}
            if action == "end":
                session.end()
                return {
                    "ok": True,
                    "phase": session.phase.value,
                    "message": "session ended; stimulus evidence now feeds fusion",
                }
        except RuntimeError as exc:
            return {"ok": False, "phase": session.phase.value, "message": str(exc)}
        return {"ok": False, "phase": session.phase.value, "message": f"unknown action {action!r}"}

    # ------------------------------------------------------------------ #
    # Localization (API)
    # ------------------------------------------------------------------ #

    def locate(self, addr_hash: str) -> Dict[str, Any]:
        """Grid (+WLS) estimate for a device from live tracker or mesh data."""
        if self.room_profile is None:
            return {"error": "no room profile configured (locate.room / --room)"}
        measurements: Dict[str, float] = {}
        if self.mesh_collector is not None:
            measurements = self.mesh_collector.measurement_sets().get(addr_hash, {})
        if not measurements:
            window = self.tracker.window(addr_hash)
            if window is None:
                return {"error": "unknown device"}
            per_node: Dict[str, List[float]] = {}
            for obs in window.long:
                per_node.setdefault(obs.node_id, []).append(obs.rssi_dbm)
            measurements = {node: median_rssi(v) for node, v in per_node.items()}
        locator = GridLocator(self.room_profile, self.config.locate.grid_resolution_m)
        if len(measurements) >= 2:
            result: Dict[str, Any] = {"grid": locator.estimate(measurements).to_dict()}
            result["heatmap"] = locator.heatmap(measurements)
            try:
                result["wls"] = wls_estimate(measurements, self.room_profile).to_dict()
            except Exception:
                result["wls"] = None
            return result
        if len(measurements) == 1:
            node_id, rssi = next(iter(measurements.items()))
            try:
                single = locator.single_node_estimate(node_id, rssi).to_dict()
            except ValueError as exc:
                return {"error": str(exc)}
            return {
                "single_node": single,
                "note": "single anchor: distance only (a ring, not a point)",
            }
        return {"error": "no measurements for this device"}


def _version() -> str:
    import sentinel_rf

    return sentinel_rf.__version__
