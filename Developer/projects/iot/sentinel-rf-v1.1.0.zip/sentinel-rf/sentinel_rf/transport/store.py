"""Storage boundary: in-memory (Phase 0) and SQLite (Phase 6) stores.

Every payload crossing this boundary is checked with
sentinel_rf.privacy.assert_no_raw_mac: raw MAC addresses must never reach
storage (HARD RULE 3). The SQLite store keeps the same boundary calls as
the in-memory store, so the Phase-0 privacy acceptance test keeps holding
by construction.

Schema (v1):
  observations(ts, source, node_id, channel, rssi, addr_hash, bssid_hash,
              role, frame_type, frame_subtype, length, retry, name)
  devices(addr_hash PRIMARY KEY, first_ts, last_ts, n_frames, role,
          last_score, last_verdict, updated)
  alerts(id, ts, addr_hash, score, verdict, reasons_json, components_json)
  events(id, ts, kind, detail_json)
  kv(key, value)  -- schema version etc.

Writes are batched (store.batch_size) to spare the SD card; a retention
purge drops rows older than store.retention_days.
"""

from __future__ import annotations

import json
import logging
import sqlite3
import threading
import time
from collections import deque
from pathlib import Path
from typing import Any, Deque, Dict, List, Mapping, Optional, Protocol, Tuple, Union

from sentinel_rf.parse.observation import Observation
from sentinel_rf.privacy import assert_no_raw_mac

__all__ = ["InMemoryStore", "SqliteStore", "Store"]

log = logging.getLogger(__name__)

_SCHEMA_VERSION = 1

_SCHEMA = """
CREATE TABLE IF NOT EXISTS observations (
    ts REAL NOT NULL,
    source TEXT NOT NULL,
    node_id TEXT NOT NULL,
    channel INTEGER,
    rssi REAL NOT NULL,
    addr_hash TEXT NOT NULL,
    bssid_hash TEXT,
    role TEXT,
    frame_type INTEGER,
    frame_subtype INTEGER,
    length INTEGER NOT NULL,
    retry INTEGER,
    name TEXT
);
CREATE INDEX IF NOT EXISTS idx_obs_hash_ts ON observations(addr_hash, ts);
CREATE INDEX IF NOT EXISTS idx_obs_ts ON observations(ts);

CREATE TABLE IF NOT EXISTS devices (
    addr_hash TEXT PRIMARY KEY,
    first_ts REAL NOT NULL,
    last_ts REAL NOT NULL,
    n_frames INTEGER NOT NULL,
    role TEXT,
    last_score REAL,
    last_verdict TEXT,
    updated REAL NOT NULL
);

CREATE TABLE IF NOT EXISTS alerts (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    ts REAL NOT NULL,
    addr_hash TEXT NOT NULL,
    score REAL NOT NULL,
    verdict TEXT NOT NULL,
    reasons_json TEXT NOT NULL,
    components_json TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_alerts_ts ON alerts(ts);

CREATE TABLE IF NOT EXISTS events (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    ts REAL NOT NULL,
    kind TEXT NOT NULL,
    detail_json TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS kv (
    key TEXT PRIMARY KEY,
    value TEXT NOT NULL
);
"""

# Observation columns persisted (a deliberate subset: rate/freq/uuids are
# derivable or bulky; NOTHING here can carry a raw address). Maps SQL
# column -> Observation.to_dict() key ("rssi" stores "rssi_dbm").
_OBS_COLUMNS = (
    "ts",
    "source",
    "node_id",
    "channel",
    "rssi",
    "addr_hash",
    "bssid_hash",
    "role",
    "frame_type",
    "frame_subtype",
    "length",
    "retry",
    "name",
)
_OBS_KEYS = tuple({"rssi": "rssi_dbm"}.get(c, c) for c in _OBS_COLUMNS)


class Store(Protocol):  # type: ignore[misc]
    """Minimal storage interface (both stores implement this)."""

    def add_observation(self, observation: Observation) -> None:
        """Serialize and persist one observation (privacy-checked)."""
        ...

    def add_payload(self, payload: Mapping[str, Any]) -> None:
        """Persist one already-serialized payload (privacy-checked)."""
        ...

    def observations(self) -> tuple:
        """Return stored rows (serialized form)."""
        ...


class InMemoryStore:
    """Bounded in-memory stand-in (tests, laptop demos).

    Enforces the privacy boundary on every insert: raw MACs or raw-address
    keys raise PrivacyViolation instead of being stored.
    """

    def __init__(self, max_observations: int = 100_000) -> None:
        self._rows: Deque[Dict[str, Any]] = deque(maxlen=max_observations)

    def add_observation(self, observation: Observation) -> None:
        self.add_payload(observation.to_dict())

    def add_payload(self, payload: Mapping[str, Any]) -> None:
        assert_no_raw_mac(payload, where="InMemoryStore.add_payload")
        self._rows.append(dict(payload))

    def observations(self) -> tuple:
        return tuple(self._rows)

    def __len__(self) -> int:
        return len(self._rows)


class SqliteStore:
    """SQLite persistence with the same privacy boundary as InMemoryStore.

    Thread-safe (connection + lock); WAL journaling; batched writes with an
    explicit :meth:`flush`; retention purge on demand. ``path=":memory:"``
    gives an in-process database for tests.
    """

    def __init__(self, path: Union[str, Path], *, batch_size: int = 200) -> None:
        self.path = str(path)
        self._batch_size = max(1, int(batch_size))
        self._lock = threading.Lock()
        self._buffer: List[Tuple] = []
        if self.path != ":memory:":
            Path(self.path).parent.mkdir(parents=True, exist_ok=True)
        self._db = sqlite3.connect(self.path, check_same_thread=False)
        self._db.execute("PRAGMA journal_mode=WAL")
        self._db.executescript(_SCHEMA)
        self._db.execute(
            "INSERT OR REPLACE INTO kv(key, value) VALUES('schema_version', ?)",
            (str(_SCHEMA_VERSION),),
        )
        self._db.commit()

    # -- boundary -------------------------------------------------------- #

    def add_observation(self, observation: Observation) -> None:
        payload = observation.to_dict()
        assert_no_raw_mac(payload, where=f"SqliteStore[{self.path}].add_observation")
        with self._lock:
            self._buffer.append(tuple(payload.get(k) for k in _OBS_KEYS))
            if len(self._buffer) >= self._batch_size:
                self._flush_locked()

    def add_payload(self, payload: Mapping[str, Any]) -> None:
        """Persist an arbitrary privacy-checked payload (as an event row)."""
        assert_no_raw_mac(payload, where=f"SqliteStore[{self.path}].add_payload")
        self.add_event("payload", dict(payload))

    # -- events / alerts / devices ---------------------------------------- #

    def add_event(self, kind: str, detail: Mapping[str, Any]) -> None:
        assert_no_raw_mac(detail, where="SqliteStore.add_event")
        with self._lock:
            self._db.execute(
                "INSERT INTO events(ts, kind, detail_json) VALUES (?, ?, ?)",
                (time.time(), str(kind), json.dumps(dict(detail), default=str)),
            )
            self._db.commit()

    def add_alert(self, alert: Mapping[str, Any]) -> None:
        assert_no_raw_mac(alert, where="SqliteStore.add_alert")
        with self._lock:
            self._db.execute(
                "INSERT INTO alerts(ts, addr_hash, score, verdict, reasons_json, "
                "components_json) VALUES (?, ?, ?, ?, ?, ?)",
                (
                    float(alert.get("ts", time.time())),
                    str(alert["addr_hash"]),
                    float(alert.get("score", 0.0)),
                    str(alert.get("band", "unknown")),
                    json.dumps(list(alert.get("reasons", [])), ensure_ascii=False),
                    json.dumps(alert.get("components", {}), default=str),
                ),
            )
            self._db.commit()

    def upsert_device(
        self,
        addr_hash: str,
        *,
        first_ts: float,
        last_ts: float,
        n_frames: int,
        role: Optional[str],
        last_score: Optional[float] = None,
        last_verdict: Optional[str] = None,
    ) -> None:
        assert_no_raw_mac({"addr_hash": addr_hash}, where="SqliteStore.upsert_device")
        with self._lock:
            self._db.execute(
                """
                INSERT INTO devices(addr_hash, first_ts, last_ts, n_frames, role,
                                    last_score, last_verdict, updated)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                ON CONFLICT(addr_hash) DO UPDATE SET
                    last_ts=excluded.last_ts,
                    n_frames=excluded.n_frames,
                    role=excluded.role,
                    last_score=excluded.last_score,
                    last_verdict=excluded.last_verdict,
                    updated=excluded.updated
                """,
                (
                    addr_hash,
                    float(first_ts),
                    float(last_ts),
                    int(n_frames),
                    role,
                    last_score,
                    last_verdict,
                    time.time(),
                ),
            )
            self._db.commit()

    # -- queries ----------------------------------------------------------- #

    def observations(
        self, *, limit: int = 100, addr_hash: Optional[str] = None
    ) -> Tuple[Dict[str, Any], ...]:
        with self._lock:
            self._flush_locked()
            if addr_hash:
                cursor = self._db.execute(
                    "SELECT {} FROM observations WHERE addr_hash=? ORDER BY ts DESC "
                    "LIMIT ?".format(",".join(_OBS_COLUMNS)),
                    (addr_hash, int(limit)),
                )
            else:
                cursor = self._db.execute(
                    "SELECT {} FROM observations ORDER BY ts DESC LIMIT ?".format(
                        ",".join(_OBS_COLUMNS)
                    ),
                    (int(limit),),
                )
            rows = cursor.fetchall()
        return tuple(dict(zip(_OBS_COLUMNS, row)) for row in rows)

    def devices(self, *, limit: int = 100) -> List[Dict[str, Any]]:
        with self._lock:
            cursor = self._db.execute(
                "SELECT addr_hash, first_ts, last_ts, n_frames, role, last_score, "
                "last_verdict FROM devices ORDER BY last_ts DESC LIMIT ?",
                (int(limit),),
            )
            rows = cursor.fetchall()
        keys = (
            "addr_hash",
            "first_ts",
            "last_ts",
            "n_frames",
            "role",
            "last_score",
            "last_verdict",
        )
        return [dict(zip(keys, row)) for row in rows]

    def alerts(self, *, since: float = 0.0, limit: int = 100) -> List[Dict[str, Any]]:
        with self._lock:
            cursor = self._db.execute(
                "SELECT id, ts, addr_hash, score, verdict, reasons_json, components_json "
                "FROM alerts WHERE ts >= ? ORDER BY ts DESC LIMIT ?",
                (float(since), int(limit)),
            )
            rows = cursor.fetchall()
        out = []
        for row in rows:
            out.append(
                {
                    "id": row[0],
                    "ts": row[1],
                    "addr_hash": row[2],
                    "score": row[3],
                    "verdict": row[4],
                    "reasons": json.loads(row[5]),
                    "components": json.loads(row[6]),
                }
            )
        return out

    def events(self, *, since: float = 0.0, limit: int = 100) -> List[Dict[str, Any]]:
        with self._lock:
            cursor = self._db.execute(
                "SELECT id, ts, kind, detail_json FROM events WHERE ts >= ? "
                "ORDER BY ts DESC LIMIT ?",
                (float(since), int(limit)),
            )
            rows = cursor.fetchall()
        return [{"id": r[0], "ts": r[1], "kind": r[2], "detail": json.loads(r[3])} for r in rows]

    def counts(self) -> Dict[str, int]:
        with self._lock:
            self._flush_locked()
            obs = self._db.execute("SELECT COUNT(*) FROM observations").fetchone()[0]
            dev = self._db.execute("SELECT COUNT(*) FROM devices").fetchone()[0]
            alerts = self._db.execute("SELECT COUNT(*) FROM alerts").fetchone()[0]
            events = self._db.execute("SELECT COUNT(*) FROM events").fetchone()[0]
        return {"observations": obs, "devices": dev, "alerts": alerts, "events": events}

    # -- maintenance -------------------------------------------------------- #

    def flush(self) -> None:
        with self._lock:
            self._flush_locked()

    def _flush_locked(self) -> None:
        if not self._buffer:
            return
        self._db.executemany(
            "INSERT INTO observations({}) VALUES ({})".format(
                ",".join(_OBS_COLUMNS), ",".join("?" * len(_OBS_COLUMNS))
            ),
            self._buffer,
        )
        self._buffer.clear()
        self._db.commit()

    def purge_older_than(self, days: float) -> int:
        cutoff = time.time() - days * 86400.0
        with self._lock:
            self._flush_locked()
            cursor = self._db.execute("DELETE FROM observations WHERE ts < ?", (cutoff,))
            self._db.execute("DELETE FROM events WHERE ts < ?", (cutoff,))
            removed = cursor.rowcount or 0
            self._db.commit()
        return removed

    def close(self) -> None:
        with self._lock:
            self._flush_locked()
            self._db.close()

    def __enter__(self) -> "SqliteStore":
        return self

    def __exit__(self, *exc: object) -> None:
        self.close()

    def __len__(self) -> int:
        return self.counts()["observations"]
