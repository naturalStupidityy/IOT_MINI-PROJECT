"""Transport: SQLite store, MQTT mesh, optional ThingSpeak telemetry (Phase 6).

Every outbound boundary (store insert, MQTT publish, cloud telemetry)
passes sentinel_rf.privacy.assert_no_raw_mac - raw MACs never leave live
memory (HARD RULE 3). MQTT credentials come from the environment only.
"""

from sentinel_rf.transport.mqtt import (
    MeshCollector,
    MqttError,
    MqttTransport,
    decode_node_message,
    devices_topic,
    encode_node_message,
)
from sentinel_rf.transport.store import InMemoryStore, SqliteStore, Store
from sentinel_rf.transport.thingspeak import ThingSpeakPublisher

__all__ = [
    "InMemoryStore",
    "MeshCollector",
    "MqttError",
    "MqttTransport",
    "SqliteStore",
    "Store",
    "ThingSpeakPublisher",
    "decode_node_message",
    "devices_topic",
    "encode_node_message",
]
