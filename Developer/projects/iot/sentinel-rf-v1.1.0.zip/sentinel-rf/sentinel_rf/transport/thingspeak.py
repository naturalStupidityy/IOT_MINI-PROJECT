"""ThingSpeak telemetry publisher (Phase 6, optional).

Publishes ONLY coarse aggregates - never observations, never raw or hashed
addresses of bystanders' devices: alert counts, the top score band and
capture health. The write API key comes from the environment
(SENTINEL_THINGSPEAK_KEY) and is never logged.

Rate-limited to ThingSpeak's free-tier ~15 s update interval; a failed or
missing key degrades to a no-op (telemetry must never break sensing).
"""

from __future__ import annotations

import logging
import os
import time
import urllib.parse
import urllib.request
from typing import Dict

__all__ = ["ThingSpeakPublisher"]

log = logging.getLogger(__name__)

_API_BASE = "https://api.thingspeak.com/update.json"
_MIN_INTERVAL_S = 15.0


class ThingSpeakPublisher:
    """Minimal ThingSpeak channel updater (fields 1..8, key from env)."""

    def __init__(self, *, api_key_env: str = "SENTINEL_THINGSPEAK_KEY") -> None:
        self._key_env = api_key_env
        self._last_send = 0.0
        self.stats = {"sent": 0, "skipped": 0, "errors": 0}

    @property
    def enabled(self) -> bool:
        return bool(os.environ.get(self._key_env))

    def build_payload(self, fields: Dict[str, object]) -> Dict[str, str]:
        """Validate + stringify fields into a ThingSpeak payload (no key yet)."""
        payload: Dict[str, str] = {}
        for name, value in fields.items():
            if not (len(name) == 6 and name.startswith("field") and name[5].isdigit()):
                raise ValueError(f"ThingSpeak fields must be 'field1'..'field8': {name!r}")
            if value is None:
                continue
            payload[name] = str(value)
        return payload

    def send(self, fields: Dict[str, object]) -> bool:
        """POST one update; respects the rate limit and swallows all errors."""
        if not self.enabled:
            self.stats["skipped"] += 1
            return False
        now = time.monotonic()
        if now - self._last_send < _MIN_INTERVAL_S:
            self.stats["skipped"] += 1
            return False
        payload = self.build_payload(fields)
        payload["api_key"] = os.environ[self._key_env]
        data = urllib.parse.urlencode(payload).encode("ascii")
        request = urllib.request.Request(  # noqa: S310 - fixed https endpoint
            _API_BASE, data=data, method="POST"
        )
        try:
            with urllib.request.urlopen(request, timeout=10) as response:  # noqa: S310
                body = response.read(200)
            self._last_send = now
            self.stats["sent"] += 1
            log.debug("thingspeak update accepted: %s", body[:60])
            return True
        except Exception as exc:  # network errors must not break sensing
            self.stats["errors"] += 1
            log.warning("thingspeak update failed: %s", exc)
            return False
