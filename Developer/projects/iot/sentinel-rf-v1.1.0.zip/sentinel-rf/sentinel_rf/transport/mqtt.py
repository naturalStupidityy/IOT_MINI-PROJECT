"""MQTT transport for multi-node mesh operation (Phase 6).

Topic scheme (site/node ids are validated to contain no MQTT wildcards):

    sentinel/<site>/<node_id>/devices     node -> collector: device summaries
    sentinel/<site>/collector/status      collector -> nodes (Phase 7)

Each node publishes per-device summaries: salted hash, role, vendor, the
median RSSI *this node* sees, and the fused score. The collector merges
summaries from >= 2 nodes into per-device measurement sets and runs the
grid locator - that is the mesh localization path.

Privacy: every outbound message passes assert_no_raw_mac (HARD RULE 3);
credentials come from the environment only (SENTINEL_MQTT_USER /
SENTINEL_MQTT_PASS), never from the repo. TLS is optional.

paho-mqtt is an optional extra (`pip install -e '.[transport]'`); the
encode/decode layer is pure stdlib so message formats are fully tested
without a broker.
"""

from __future__ import annotations

import json
import logging
import os
import threading
import time
from pathlib import Path
from typing import Callable, Dict, List, Optional

from sentinel_rf.config import MqttConfig
from sentinel_rf.privacy import assert_no_raw_mac

__all__ = [
    "MeshCollector",
    "MqttTransport",
    "decode_node_message",
    "devices_topic",
    "encode_node_message",
]

log = logging.getLogger(__name__)


class MqttError(RuntimeError):
    """Raised for configuration or connection problems."""


def devices_topic(config: MqttConfig, node_id: Optional[str] = None) -> str:
    """Topic for a node's device summaries (wildcard '+' when node_id is None)."""
    who = node_id if node_id is not None else "+"
    return f"sentinel/{config.site}/{who}/devices"


def encode_node_message(payload: Dict) -> str:
    """Serialize a node message, refusing anything that carries a raw MAC."""
    assert_no_raw_mac(payload, where="mqtt.encode_node_message")
    return json.dumps(payload, separators=(",", ":"), default=str)


def decode_node_message(text: str) -> Dict:
    """Parse a node message; raises ValueError on malformed JSON."""
    payload = json.loads(text)
    if not isinstance(payload, dict):
        raise ValueError("node message must be a JSON object")
    if "node_id" not in payload or "devices" not in payload:
        raise ValueError("node message needs 'node_id' and 'devices'")
    return payload


class MqttTransport:
    """Thin paho-mqtt wrapper: connect, publish, subscribe, disconnect.

    Connection happens lazily and failures are reported, never raised into
    the capture path: a broker outage degrades the mesh, it does not stop
    sensing.
    """

    def __init__(self, config: MqttConfig) -> None:
        self.config = config
        self._client = None
        self._lock = threading.Lock()
        self._connected = False
        self.stats = {"published": 0, "received": 0, "errors": 0}
        self._on_message_handlers: List[Callable[[str, Dict], None]] = []

    # -- wiring ----------------------------------------------------------- #

    def _require_paho(self):
        try:
            import paho.mqtt.client as mqtt  # noqa: PLC0415 - optional dep
        except ImportError as exc:
            raise MqttError(
                "paho-mqtt is required for MQTT transport; "
                "install with: pip install -e '.[transport]' (or '.[all]')"
            ) from exc
        return mqtt

    def on_message(self, handler: Callable[[str, Dict], None]) -> None:
        """Register a callback(topic, payload_dict) for subscribed messages."""
        self._on_message_handlers.append(handler)

    # -- lifecycle --------------------------------------------------------- #

    def connect(self, timeout_s: float = 5.0) -> bool:
        mqtt = self._require_paho()
        with self._lock:
            if self._client is not None:
                return self._connected
            client = mqtt.Client(client_id=f"sentinel-{self.config.node_id}")
            username = os.environ.get("SENTINEL_MQTT_USER")
            password = os.environ.get("SENTINEL_MQTT_PASS")
            if username:
                client.username_pw_set(username, password)
            if self.config.tls.enabled:
                ca = Path(self.config.tls.ca) if self.config.tls.ca else None
                client.tls_set(ca_certs=str(ca) if ca else None)
            client.on_message = self._handle_message
            client.on_connect = self._handle_connect
            try:
                client.connect(
                    self.config.host, self.config.port, keepalive=self.config.keepalive_s
                )
                client.loop_start()
            except Exception as exc:
                self.stats["errors"] += 1
                log.warning(
                    "MQTT connect to %s:%s failed: %s", self.config.host, self.config.port, exc
                )
                return False
            self._client = client
        deadline = time.time() + timeout_s
        while time.time() < deadline and not self._connected:
            time.sleep(0.05)
        return self._connected

    def _handle_connect(self, client, userdata, flags, rc, *args):  # noqa: ANN001
        self._connected = int(rc) == 0
        if self._connected:
            log.info("MQTT connected to %s:%s", self.config.host, self.config.port)
            topic = devices_topic(self.config, node_id=None)
            client.subscribe(topic)
        else:
            self.stats["errors"] += 1
            log.warning("MQTT connection refused (rc=%s)", rc)

    def _handle_message(self, client, userdata, msg):  # noqa: ANN001
        try:
            payload = decode_node_message(msg.payload.decode("utf-8"))
        except (ValueError, UnicodeDecodeError):
            self.stats["errors"] += 1
            log.warning("dropping malformed MQTT message on %s", msg.topic)
            return
        self.stats["received"] += 1
        for handler in self._on_message_handlers:
            try:
                handler(msg.topic, payload)
            except Exception:  # a bad handler must not break the loop
                log.exception("MQTT message handler failed")

    # -- publish ------------------------------------------------------------ #

    def publish_devices(self, payload: Dict) -> bool:
        """Publish a device-summary message (privacy-checked)."""
        if self._client is None or not self._connected:
            return False
        text = encode_node_message(payload)
        topic = devices_topic(self.config, self.config.node_id)
        info = self._client.publish(topic, text, qos=0)
        if info.rc == 0:
            self.stats["published"] += 1
            return True
        self.stats["errors"] += 1
        return False

    def disconnect(self) -> None:
        with self._lock:
            if self._client is not None:
                try:
                    self._client.loop_stop()
                    self._client.disconnect()
                except Exception:  # pragma: no cover - defensive
                    log.exception("MQTT disconnect failed")
                self._client = None
            self._connected = False


class MeshCollector:
    """Merge node device-summaries into per-device measurement sets.

    Feeds :class:`~sentinel_rf.locate.grid.GridLocator` with
    ``{node_id: median rssi}`` per device hash once >= 2 nodes have spoken.
    Pure in-memory logic, so it is fully unit-testable without a broker.
    """

    def __init__(self, *, max_age_s: float = 120.0) -> None:
        self.max_age_s = float(max_age_s)
        # {addr_hash: {node_id: (ts, rssi, score)}}
        self._measurements: Dict[str, Dict[str, tuple]] = {}

    def ingest(self, message: Dict) -> int:
        """Fold one decoded node message in; returns devices updated."""
        node_id = str(message["node_id"])
        ts = float(message.get("ts", time.time()))
        updated = 0
        for device in message.get("devices", []):
            addr_hash = device.get("addr_hash")
            rssi = device.get("rssi_median")
            if not addr_hash or rssi is None:
                continue
            entry = self._measurements.setdefault(addr_hash, {})
            entry[node_id] = (ts, float(rssi), device.get("score"))
            updated += 1
        self._evict_stale()
        return updated

    def _evict_stale(self) -> None:
        cutoff = time.time() - self.max_age_s
        for addr_hash, nodes in list(self._measurements.items()):
            for node_id, (ts, _r, _s) in list(nodes.items()):
                if ts < cutoff:
                    del nodes[node_id]
            if not nodes:
                del self._measurements[addr_hash]

    def measurement_sets(self, *, min_nodes: int = 2) -> Dict[str, Dict[str, float]]:
        """{addr_hash: {node_id: rssi}} for devices seen by >= min_nodes."""
        out: Dict[str, Dict[str, float]] = {}
        for addr_hash, nodes in self._measurements.items():
            if len(nodes) >= min_nodes:
                out[addr_hash] = {n: r for n, (_t, r, _s) in nodes.items()}
        return out

    def device_summaries(self) -> List[Dict]:
        """Flattened per-device view (dashboard): best score, node count."""
        summaries = []
        for addr_hash, nodes in self._measurements.items():
            scores = [s for (_t, _r, s) in nodes.values() if s is not None]
            rssis = [r for (_t, r, _s) in nodes.values()]
            summaries.append(
                {
                    "addr_hash": addr_hash,
                    "nodes": len(nodes),
                    "best_score": max(scores) if scores else None,
                    "median_rssi": sorted(rssis)[len(rssis) // 2] if rssis else None,
                }
            )
        return summaries
