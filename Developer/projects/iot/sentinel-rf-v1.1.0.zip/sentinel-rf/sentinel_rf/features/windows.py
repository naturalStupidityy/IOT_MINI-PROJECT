"""Sliding-window device tracking (Phase 3).

The tracker keeps, per salted device hash, the recent Observations needed
for the three configured windows (short/medium/long) plus first/last seen
and role majority. It is the ONLY cross-window state in the detection
path and is thread-safe: capture threads update, the detection loop
snapshots.

Memory hygiene: each device's deque is bounded both by the long window
(seconds) and by a hard cap on stored observations; stale devices are
evicted by :meth:`sweep`.
"""

from __future__ import annotations

import threading
import time
from collections import deque
from dataclasses import dataclass, field
from typing import Deque, Dict, List, Optional, Tuple

from sentinel_rf.config import WindowsConfig
from sentinel_rf.parse.observation import Observation, Role, Source

__all__ = ["DeviceIntelView", "DeviceTracker", "DeviceWindow"]


@dataclass
class DeviceWindow:
    """A point-in-time view of one device's recent traffic."""

    addr_hash: str
    short: List[Observation] = field(default_factory=list)  # e.g. 1 s
    medium: List[Observation] = field(default_factory=list)  # e.g. 10 s
    long: List[Observation] = field(default_factory=list)  # e.g. 60 s
    first_seen: float = 0.0
    last_seen: float = 0.0
    role_majority: Role = Role.UNKNOWN
    sources: Tuple[Source, ...] = ()

    @property
    def is_ble_only(self) -> bool:
        return bool(self.sources) and all(s is Source.BLE for s in self.sources)

    @property
    def has_wifi(self) -> bool:
        return Source.WIFI in self.sources


class DeviceIntelView:
    """Pass-through holder so windows can carry memory-only intel (Phase 4 glue)."""

    def __init__(self) -> None:
        self.vendor: Optional[str] = None
        self.ssid: Optional[str] = None
        self.ble_name: Optional[str] = None


class _DeviceState:
    __slots__ = ("obs", "first_seen", "last_seen", "roles", "sources", "raw_mac")

    def __init__(self, max_len: int) -> None:
        self.obs: Deque[Observation] = deque(maxlen=max_len)
        self.first_seen: float = float("inf")
        self.last_seen: float = 0.0
        self.roles: Dict[Role, int] = {}
        self.sources: Dict[Source, int] = {}
        self.raw_mac: Optional[str] = None


class DeviceTracker:
    """Per-device bounded observation history with window slicing."""

    def __init__(
        self,
        config: Optional[WindowsConfig] = None,
        *,
        max_per_device: int = 20_000,
        allow_raw: bool = False,
    ) -> None:
        self.config = config or WindowsConfig()
        self._allow_raw = allow_raw
        self._max_len = max_per_device
        self._devices: Dict[str, _DeviceState] = {}
        self._lock = threading.Lock()

    # -- ingestion ------------------------------------------------------ #

    def update(self, obs: Observation, ephemeral=None) -> None:
        """Record one observation (ephemeral intel is consumed by the caller)."""
        with self._lock:
            state = self._devices.get(obs.addr_hash)
            if state is None:
                state = _DeviceState(self._max_len)
                self._devices[obs.addr_hash] = state
            state.obs.append(obs)
            state.first_seen = min(state.first_seen, obs.ts)
            state.last_seen = max(state.last_seen, obs.ts)
            state.roles[obs.role] = state.roles.get(obs.role, 0) + 1
            state.sources[obs.source] = state.sources.get(obs.source, 0) + 1
            if obs.raw_addr is not None:
                state.raw_mac = obs.raw_addr

    # -- queries --------------------------------------------------------- #

    def devices(self) -> List[str]:
        with self._lock:
            return list(self._devices)

    def __contains__(self, addr_hash: str) -> bool:
        with self._lock:
            return addr_hash in self._devices

    def __len__(self) -> int:
        with self._lock:
            return len(self._devices)

    def _slice(self, obs: Deque[Observation], now: float, window_s: float) -> List[Observation]:
        out: List[Observation] = []
        for item in reversed(obs):
            if now - item.ts >= window_s:
                break
            out.append(item)
        out.reverse()
        return out

    def window(self, addr_hash: str, now: Optional[float] = None) -> Optional[DeviceWindow]:
        """Latest window view for a device (None if unknown)."""
        with self._lock:
            state = self._devices.get(addr_hash)
            if state is None:
                return None
            t_now = now if now is not None else state.last_seen
            roles = (
                max(state.roles.items(), key=lambda kv: kv[1])[0] if state.roles else Role.UNKNOWN
            )
            return DeviceWindow(
                addr_hash=addr_hash,
                short=self._slice(state.obs, t_now, self.config.short_s),
                medium=self._slice(state.obs, t_now, self.config.medium_s),
                long=self._slice(state.obs, t_now, self.config.long_s),
                first_seen=state.first_seen if state.first_seen != float("inf") else 0.0,
                last_seen=state.last_seen,
                role_majority=roles,
                sources=tuple(state.sources),
            )

    def snapshot(self, now: Optional[float] = None) -> Dict[str, DeviceWindow]:
        """Window views for every tracked device."""
        with self._lock:
            hashes = list(self._devices)
        return {h: w for h in hashes if (w := self.window(h, now)) is not None and w.long}

    def raw_mac(self, addr_hash: str) -> Optional[str]:
        """Raw MAC if remembered AND privacy allows (live dashboard only)."""
        if not self._allow_raw:
            return None
        with self._lock:
            state = self._devices.get(addr_hash)
            return state.raw_mac if state else None

    # -- hygiene ---------------------------------------------------------- #

    def sweep(self, now: Optional[float] = None, stale_s: float = 300.0) -> int:
        """Drop devices not seen for *stale_s*; returns the number evicted."""
        t_now = now if now is not None else time.time()
        with self._lock:
            stale = [h for h, s in self._devices.items() if t_now - s.last_seen > stale_s]
            for h in stale:
                del self._devices[h]
            return len(stale)
