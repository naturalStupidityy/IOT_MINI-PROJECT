"""Per-device traffic statistics (Phase 3).

Pure functions from a :class:`~sentinel_rf.features.windows.DeviceWindow`
to a flat feature dict - the single feature vocabulary shared by the rule
baseline and the ML classifier (Phase 4). Keeping it a pure function makes
the analytic unit tests possible: build a window with known traffic, assert
exact feature values.

Feature groups (see FEATURE_NAMES):
  rate          frames_per_s, bytes_per_s (short window)
  direction     uplink_share (To-DS bytes / data bytes), data_ratio
  video-shape   qos_share, retry_rate, mean/p90 frame size, large_frame_share,
                iat_mean_ms, iat_cv, duty_cycle, burst_periodicity
  radio         mean_rate_mbps, rssi_mean, rssi_var, rssi_drift_db_min,
                channel_changes
  identity      is_ble, ble_adv_rate, ble_named, role_ap
  volume        n_frames (long window)

All values are finite floats; degenerate windows yield zeros, never NaN.
"""

from __future__ import annotations

import math
from typing import Dict, List, Sequence

import numpy as np

from sentinel_rf.features.windows import DeviceWindow
from sentinel_rf.parse.observation import Observation, Role, Source

__all__ = ["FEATURE_NAMES", "compute_features", "feature_vector"]

FEATURE_NAMES: Sequence[str] = (
    "frames_per_s",
    "bytes_per_s",
    "uplink_share",
    "data_ratio",
    "qos_share",
    "retry_rate",
    "mean_frame_size",
    "p90_frame_size",
    "large_frame_share",
    "iat_mean_ms",
    "iat_cv",
    "duty_cycle",
    "burst_periodicity",
    "mean_rate_mbps",
    "rssi_mean",
    "rssi_var",
    "rssi_drift_db_min",
    "channel_changes",
    "is_ble",
    "ble_adv_rate",
    "ble_named",
    "role_ap",
    "n_frames",
)

_LARGE_FRAME_B = 1000  # "large" data frame threshold (~ video payload size)
_BUCKET_MS = 100  # burst/duty bucket granularity


def _span(obs_list: List[Observation]) -> float:
    if len(obs_list) < 1:
        return 0.0
    return max(obs_list[-1].ts - obs_list[0].ts, 1e-6)


def _data_frames(obs_list: List[Observation]) -> List[Observation]:
    return [o for o in obs_list if o.source is Source.WIFI and o.frame_type == 2]


def _safe_div(numerator: float, denominator: float, default: float = 0.0) -> float:
    return numerator / denominator if denominator else default


def _pearson(x: np.ndarray, y: np.ndarray) -> float:
    if len(x) < 2:
        return 0.0
    xs, ys = x - x.mean(), y - y.mean()
    denom = math.sqrt(float(xs @ xs) * float(ys @ ys))
    if denom <= 1e-12:
        return 0.0
    return float(xs @ ys) / denom


def _bucket_counts(obs_list: List[Observation], bucket_ms: int = _BUCKET_MS) -> np.ndarray:
    """Bytes observed per equal bucket over the window span."""
    if not obs_list:
        return np.zeros(1)
    t0 = obs_list[0].ts
    span_s = _span(obs_list)
    n_buckets = int(span_s * 1000.0 / bucket_ms) + 1
    counts = np.zeros(max(n_buckets, 1))
    for o in obs_list:
        idx = int((o.ts - t0) * 1000.0 / bucket_ms)
        if 0 <= idx < len(counts):
            counts[idx] += o.length
    return counts


def compute_features(window: DeviceWindow) -> Dict[str, float]:
    """Compute the full feature vector for one device window."""
    long_obs = window.long
    medium_obs = window.medium
    short_obs = window.short
    features: Dict[str, float] = {}

    # ---- rate (short window, but fall back to long for sparse devices) ----
    rate_source = short_obs if len(short_obs) >= 2 else long_obs
    rate_span = _span(rate_source) if rate_source else 1.0
    features["frames_per_s"] = _safe_div(len(rate_source), rate_span)
    features["bytes_per_s"] = _safe_div(sum(o.length for o in rate_source), rate_span)

    # ---- direction & shape (long window) -------------------------------- #
    data = _data_frames(long_obs)
    total_bytes = sum(o.length for o in data)
    uplink_bytes = sum(o.length for o in data if o.to_ds)
    features["uplink_share"] = _safe_div(uplink_bytes, total_bytes)
    features["data_ratio"] = _safe_div(len(data), len(long_obs))
    qos = [o for o in data if o.frame_subtype == 8]
    features["qos_share"] = _safe_div(len(qos), len(data))
    retried = [o for o in data if o.retry]
    features["retry_rate"] = _safe_div(len(retried), len(data))

    # ---- frame sizes (medium) -------------------------------------------- #
    sizes = np.array([o.length for o in _data_frames(medium_obs) or medium_obs], dtype=float)
    if len(sizes):
        features["mean_frame_size"] = float(sizes.mean())
        features["p90_frame_size"] = float(np.percentile(sizes, 90))
        features["large_frame_share"] = float((sizes > _LARGE_FRAME_B).mean())
    else:
        features["mean_frame_size"] = features["p90_frame_size"] = 0.0
        features["large_frame_share"] = 0.0

    # ---- inter-arrival (medium, data frames) ------------------------------ #
    data_medium = _data_frames(medium_obs)
    if len(data_medium) >= 2:
        ts = np.array([o.ts for o in data_medium])
        iat = np.diff(ts) * 1000.0  # ms
        mean = float(iat.mean())
        features["iat_mean_ms"] = mean
        features["iat_cv"] = float(iat.std() / mean) if mean > 1e-9 else 0.0
    else:
        features["iat_mean_ms"] = 0.0
        features["iat_cv"] = 0.0

    # ---- airtime shape (long) --------------------------------------------- #
    buckets = _bucket_counts(long_obs)
    active = float((buckets > 0).sum())
    features["duty_cycle"] = _safe_div(active, len(buckets))
    # burst periodicity: strongest positive autocorrelation for lags 0.5-6 s
    # (video keyframe periods). Cameras peak near their GOP; bulk transfers
    # and web bursts do not.
    lag_buckets = max(1, int(500 / _BUCKET_MS))
    max_lag = min(int(6000 / _BUCKET_MS), max(1, len(buckets) // 2))
    best = 0.0
    for lag in range(lag_buckets, max_lag + 1):
        r = _pearson(buckets[:-lag], buckets[lag:])
        if r > best:
            best = r
    features["burst_periodicity"] = best

    # ---- radio (long) ------------------------------------------------------ #
    rates = [o.rate_mbps for o in long_obs if o.rate_mbps is not None]
    features["mean_rate_mbps"] = float(np.mean(rates)) if rates else 0.0
    rssi = np.array([o.rssi_dbm for o in long_obs], dtype=float)
    features["rssi_mean"] = float(rssi.mean()) if len(rssi) else 0.0
    features["rssi_var"] = float(rssi.var()) if len(rssi) else 0.0
    if len(rssi) >= 2:
        t = np.array([o.ts for o in long_obs], dtype=float)
        t = t - t[0]
        slope_per_s = float(np.polyfit(t, rssi, 1)[0]) if t[-1] > 0 else 0.0
        features["rssi_drift_db_min"] = slope_per_s * 60.0
    else:
        features["rssi_drift_db_min"] = 0.0
    channels = {o.channel for o in long_obs if o.channel}
    features["channel_changes"] = float(len(channels))

    # ---- identity ----------------------------------------------------------- #
    ble_obs = [o for o in long_obs if o.source is Source.BLE]
    features["is_ble"] = 1.0 if ble_obs else 0.0
    ble_span = _span(ble_obs) if ble_obs else 1.0
    features["ble_adv_rate"] = _safe_div(len(ble_obs), ble_span)
    features["ble_named"] = 1.0 if any(o.name for o in ble_obs) else 0.0
    features["role_ap"] = 1.0 if window.role_majority is Role.AP else 0.0
    features["n_frames"] = float(len(long_obs))

    # NaN guard: every feature must be finite (quality bar)
    for name, value in features.items():
        if not math.isfinite(value):
            features[name] = 0.0
    return features


def feature_vector(window: DeviceWindow) -> np.ndarray:
    """Features as an ordered array (FEATURE_NAMES order; Phase 4 model input)."""
    features = compute_features(window)
    return np.array([features[name] for name in FEATURE_NAMES], dtype=float)
