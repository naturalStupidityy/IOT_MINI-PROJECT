"""Features: sliding-window statistics per device (Phase 3).

Pure functions over Observation streams; unit-testable on a laptop with
analytic expectations on simulated traffic.
"""

from sentinel_rf.features.stats import FEATURE_NAMES, compute_features, feature_vector
from sentinel_rf.features.windows import DeviceTracker, DeviceWindow

__all__ = [
    "FEATURE_NAMES",
    "DeviceTracker",
    "DeviceWindow",
    "compute_features",
    "feature_vector",
]
