"""Logging setup: stdlib only, configured from LoggingConfig.

All module loggers live under the "sentinel_rf" tree. setup_logging() is
idempotent (safe to call again, e.g. in tests or on config reload). The
logger keeps propagate=True so pytest's caplog and Phase 7's uvicorn logging
still see records (DECISIONS.md D015). Structured JSON logging is Phase 8.
"""

from __future__ import annotations

import logging
from pathlib import Path

from sentinel_rf.config import LoggingConfig

__all__ = ["setup_logging"]

_FORMAT = "%(asctime)s %(levelname)-8s %(name)s: %(message)s"


def setup_logging(cfg: LoggingConfig) -> logging.Logger:
    """(Re)configure the "sentinel_rf" logger tree and return that logger."""
    logger = logging.getLogger("sentinel_rf")
    logger.setLevel(cfg.level)
    for handler in list(logger.handlers):
        logger.removeHandler(handler)
        handler.close()
    formatter = logging.Formatter(_FORMAT)
    stream = logging.StreamHandler()
    stream.setFormatter(formatter)
    logger.addHandler(stream)
    if cfg.file is not None:
        Path(cfg.file).parent.mkdir(parents=True, exist_ok=True)
        file_handler = logging.FileHandler(cfg.file, encoding="utf-8")
        file_handler.setFormatter(formatter)
        logger.addHandler(file_handler)
    return logger
