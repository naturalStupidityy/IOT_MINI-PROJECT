"""FastAPI service (Phase 7): REST + WebSocket + static dashboard.

Runs the pipeline in a background thread and serves:

    GET  /api/status                  live state (capture, resources, stimulus)
    GET  /api/devices?reveal=0        per-device scores (+raw MAC only when
                                      privacy.allow_raw_mac_live AND reveal=1)
    GET  /api/devices/{hash}/evidence full reasons + component breakdown
    GET  /api/alerts?since=&limit=    alert history
    GET  /api/observations?device=&limit=   stored observations (hashes only)
    POST /api/stimulus/{action}       start | mark_on | mark_off | end
    GET  /api/locate/{hash}           grid/WLS estimate (+heatmap payload)
    WS   /ws                          pushes the state document every second

FastAPI/uvicorn are optional extras (`pip install -e '.[web]'`); tests use
TestClient without opening a port.
"""

from __future__ import annotations

import asyncio
import logging
import time
from pathlib import Path
from typing import Optional

from fastapi import FastAPI, HTTPException, Query, WebSocket
from fastapi.responses import JSONResponse
from fastapi.staticfiles import StaticFiles

from sentinel_rf.config import SentinelConfig
from sentinel_rf.pipeline import Pipeline

__all__ = ["create_app"]

log = logging.getLogger(__name__)

_STATIC_DIR = Path(__file__).parent / "static"


def create_app(pipeline: Pipeline, config: SentinelConfig) -> FastAPI:
    """Build the dashboard app around a running (or about-to-run) pipeline."""
    from contextlib import asynccontextmanager

    @asynccontextmanager
    async def lifespan(_app: FastAPI):
        if not pipeline.started_at:
            loop = asyncio.get_running_loop()
            pipeline.resources.start()
            pipeline.manager.start()
            pipeline.started_at = time.time()
            _app.state.runner = loop.run_in_executor(None, _run_pipeline_until_stopped, pipeline)
        yield
        pipeline.stop()

    app = FastAPI(title="SENTINEL-RF", version="1.0.0", lifespan=lifespan)
    app.state.pipeline = pipeline
    app.state.config = config

    @app.get("/api/status")
    def status() -> dict:
        return pipeline.state()

    @app.get("/api/devices")
    def devices(
        reveal: bool = Query(False, description="include raw MACs (privacy-gated)"),
    ) -> dict:
        state = pipeline.state(reveal=reveal and pipeline.allow_raw)
        return {
            "privacy_allows_raw": pipeline.allow_raw,
            "devices": state["devices"],
        }

    @app.get("/api/devices/{addr_hash}/evidence")
    def evidence(addr_hash: str) -> dict:
        score = pipeline.detector.latest.get(addr_hash)
        if score is None:
            raise HTTPException(status_code=404, detail="unknown device")
        payload = score.to_dict()
        payload["components_detail"] = {
            name: {
                "available": c.available,
                "score": c.score,
                "reasons": c.reasons,
            }
            for name, c in score.components.items()
        }
        return payload

    @app.get("/api/alerts")
    def alerts(since: float = 0.0, limit: int = 50) -> dict:
        return {"alerts": [a.to_dict() for a in pipeline.alerts if a.ts >= since][:limit]}

    @app.get("/api/observations")
    def observations(
        device: Optional[str] = None, limit: int = Query(200, le=2000)
    ) -> JSONResponse:
        if pipeline.store is None:
            return JSONResponse({"observations": [], "note": "no store configured"})
        rows = pipeline.store.observations(limit=limit, addr_hash=device)
        return JSONResponse({"observations": rows})

    @app.post("/api/stimulus/{action}")
    def stimulus(action: str) -> dict:
        result = pipeline.stimulus_action(action)
        if not result.get("ok"):
            raise HTTPException(status_code=409, detail=result.get("message", "conflict"))
        return result

    @app.get("/api/locate/{addr_hash}")
    def locate(addr_hash: str) -> dict:
        result = pipeline.locate(addr_hash)
        if "error" in result:
            raise HTTPException(status_code=404, detail=result["error"])
        return result

    @app.websocket("/ws")
    async def stream(websocket: "WebSocket") -> None:
        await websocket.accept()
        try:
            while True:
                await websocket.send_json(pipeline.state())
                await asyncio.sleep(1.0)
        except Exception:  # client disconnected
            pass

    # Static dashboard LAST so /api/* routes win.
    if _STATIC_DIR.is_dir():
        app.mount("/", StaticFiles(directory=str(_STATIC_DIR), html=True), name="dashboard")

    return app


def _run_pipeline_until_stopped(pipeline: Pipeline) -> None:
    """Drain loop for the dashboard's background thread (no duration limit).

    Shares the pipeline's feed/idle_tick logic so detection ticks fire on
    event time however fast the source replays, and on wall time when a
    live capture goes quiet. A final tick runs when the stream ends so the
    dashboard always shows the complete picture.
    """
    last_event_ts = None
    while not pipeline._stop.is_set():
        item = pipeline.manager.poll(0.5)
        if item is None:
            if pipeline.manager.finished():
                break
            pipeline.idle_tick()
            continue
        last_event_ts = item.ts
        pipeline.feed(item)
    if last_event_ts is not None:
        pipeline._detect_tick(last_event_ts)
