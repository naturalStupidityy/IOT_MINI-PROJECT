/* SENTINEL-RF dashboard logic (vanilla JS, no build step). */
"use strict";

const $ = (id) => document.getElementById(id);
let reveal = false;
let privacyAllowsRaw = false;
let selectedHash = null;
let chart = null;
const scoreHistory = {}; // hash -> [{t, score}]

function bandClass(band) {
  if (band === "likely") return "band-likely";
  if (band === "watch") return "band-watch";
  return "band-ignore";
}

async function post(path) {
  try {
    const res = await fetch(path, { method: "POST" });
    const body = await res.json();
    $("stim-message").textContent = body.message || body.detail || "";
  } catch (err) {
    $("stim-message").textContent = String(err);
  }
}

async function refresh() {
  let state;
  try {
    const res = await fetch(reveal && privacyAllowsRaw ? "/api/devices?reveal=1" : "/api/devices");
    const payload = await res.json();
    privacyAllowsRaw = payload.privacy_allows_raw;
    state = await (await fetch("/api/status")).json();
  } catch (err) {
    return; // server restarting
  }
  $("version").textContent = "v" + state.version;
  $("uptime").textContent = "⏱ " + Math.round(state.uptime_s) + "s";
  $("frames").textContent = "Frames " + state.counters.processed;
  const dropPct = (state.capture.drop_pct || 0).toFixed(2);
  $("drops").textContent = "Drops " + dropPct + "%";
  $("drops").className = dropPct > 2 ? "bad" : "";
  $("devices-count").textContent = "Devices " + state.n_devices;
  $("stimulus-phase").textContent = "stimulus: " + state.stimulus.phase;

  renderDevices(state.devices);
  renderAlerts(state.alerts);
  updateHistory(state.devices);
  $("privacy-note").textContent = privacyAllowsRaw
    ? "privacy.allow_raw_mac_live=true: the Reveal button can show raw MACs on this local dashboard only."
    : "Raw MAC display disabled by policy (privacy.allow_raw_mac_live=false). Devices appear as per-session salted hashes.";
  $("btn-reveal").textContent = "Reveal MACs: " + (reveal ? "on" : "off");
  $("btn-reveal").disabled = !privacyAllowsRaw;
}

function renderDevices(devices) {
  const rows = $("device-rows");
  rows.innerHTML = "";
  for (const d of devices.slice(0, 30)) {
    const tr = document.createElement("tr");
    tr.className = d.addr_hash === selectedHash ? "selected" : "";
    const label = d.raw_addr || d.addr_hash;
    tr.innerHTML =
      `<td class="mono">${label}</td>` +
      `<td><div class="score-bar"><div class="${bandClass(d.band)}" style="width:${d.score}%"></div></div> ${d.score.toFixed(1)}</td>` +
      `<td><span class="pill ${bandClass(d.band)}">${d.band}</span></td>` +
      `<td>${d.n_frames}</td>` +
      `<td>${d.vendor || "-"}</td>` +
      `<td>${d.ble_name ? "BLE: " + d.ble_name : (d.features && d.features.role_ap >= 0.5 ? "wi-fi AP" : "wi-fi")}</td>` +
      `<td><button class="ghost small-btn" data-hash="${d.addr_hash}">evidence</button></td>`;
    rows.appendChild(tr);
  }
  for (const btn of rows.querySelectorAll("button")) {
    btn.onclick = () => selectDevice(btn.dataset.hash);
  }
}

function renderAlerts(alerts) {
  const box = $("alerts");
  $("alerts-count").textContent = alerts.length ? `(${alerts.length})` : "";
  if (!alerts.length) {
    box.innerHTML = '<p class="dim">No alerts. Remember: no alerts is NOT proof of no cameras.</p>';
    return;
  }
  box.innerHTML = "";
  for (const a of alerts.slice(0, 8)) {
    const div = document.createElement("div");
    div.className = "alert " + bandClass(a.band);
    const when = new Date(a.ts * 1000).toLocaleTimeString();
    div.innerHTML =
      `<div><span class="pill ${bandClass(a.band)}">${a.band}</span> ` +
      `<span class="mono">${a.addr_hash}</span> - score ${a.score.toFixed(1)} at ${when}</div>` +
      `<ul>${a.reasons.slice(0, 4).map((r) => `<li>${r}</li>`).join("")}</ul>`;
    box.appendChild(div);
  }
}

function updateHistory(devices) {
  const now = Date.now();
  for (const d of devices.slice(0, 5)) {
    const series = (scoreHistory[d.addr_hash] = scoreHistory[d.addr_hash] || []);
    series.push({ t: now, score: d.score });
    if (series.length > 120) series.shift();
  }
  if (chart) {
    chart.data.labels = (scoreHistory[selectedHash] || []).map((p) =>
      new Date(p.t).toLocaleTimeString()
    );
    const series = scoreHistory[selectedHash] || [];
    chart.data.datasets = selectedHash
      ? [{ label: "score", data: series.map((p) => p.score), borderColor: "#e05d44", fill: false, tension: 0.2 }]
      : [];
    chart.update("none");
  }
}

async function selectDevice(hash) {
  selectedHash = hash;
  $("evidence-panel").hidden = false;
  $("evidence-hash").textContent = hash;
  try {
    const res = await fetch(`/api/devices/${hash}/evidence`);
    const ev = await res.json();
    $("evidence-score").textContent = ev.score.toFixed(1) + " (" + ev.band + ")";
    const bar = $("evidence-bar");
    bar.className = bandClass(ev.band);
    bar.style.width = ev.score + "%";
    const reasons = $("evidence-reasons");
    reasons.innerHTML = ev.reasons.map((r) => `<li>${r}</li>`).join("");
    if (!reasons.firstChild) reasons.innerHTML = '<li class="dim">No contributing evidence yet.</li>';
  } catch (err) {
    /* evidence unavailable */
  }
  try {
    const res = await fetch(`/api/locate/${hash}`);
    const loc = await res.json();
    renderLocation(loc);
  } catch (err) {
    $("locate-detail").textContent = "location unavailable";
  }
}

function renderLocation(loc) {
  const canvas = $("heat-canvas");
  const ctx = canvas.getContext("2d");
  ctx.clearRect(0, 0, canvas.width, canvas.height);
  const detail = $("locate-detail");
  if (loc.heatmap) {
    const grid = loc.heatmap.posterior;
    const shape = loc.heatmap.shape;
    const cellW = canvas.width / shape[1];
    const cellH = canvas.height / shape[0];
    let max = 0;
    for (const row of grid) for (const v of row) max = Math.max(max, v);
    for (let y = 0; y < shape[0]; y++) {
      for (let x = 0; x < shape[1]; x++) {
        const p = grid[y][x] / (max || 1);
        ctx.fillStyle = `rgba(224,93,68,${(0.15 + 0.85 * p).toFixed(3)})`;
        ctx.fillRect(x * cellW, (shape[0] - 1 - y) * cellH, cellW + 1, cellH + 1);
      }
    }
    for (const a of loc.heatmap.anchors || []) {
      const x = (a.x / loc.heatmap.extent[1]) * canvas.width;
      const y = canvas.height - (a.y / loc.heatmap.extent[3]) * canvas.height;
      ctx.fillStyle = "#8fb7d9";
      ctx.beginPath();
      ctx.arc(x, y, 5, 0, Math.PI * 2);
      ctx.fill();
    }
    const est = loc.grid;
    const ex = (est.x / loc.heatmap.extent[1]) * canvas.width;
    const ey = canvas.height - (est.y / loc.heatmap.extent[3]) * canvas.height;
    ctx.strokeStyle = "#fff";
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.arc(ex, ey, 9, 0, Math.PI * 2);
    ctx.stroke();
    detail.textContent =
      `grid: (${est.x.toFixed(2)}, ${est.y.toFixed(2)}) m, sigma ${est.sigma_m.toFixed(2)} m` +
      (loc.wls ? ` | wls: (${loc.wls.x.toFixed(2)}, ${loc.wls.y.toFixed(2)}) m` : "");
  } else if (loc.single_node) {
    const s = loc.single_node;
    detail.textContent =
      `single anchor (${s.node_ids}): ~${(0).toFixed(0)} distance estimate ` +
      `at (${s.x.toFixed(2)}, ${s.y.toFixed(2)}) m - ${loc.note}`;
    ctx.fillStyle = "#8fb7d9";
    ctx.fillRect(10, canvas.height - 20, 20, 10);
  } else {
    detail.textContent = loc.note || "no location data";
  }
}

function initChart() {
  if (typeof Chart === "undefined") {
    const el = $("score-chart");
    if (el) el.replaceWith(Object.assign(document.createElement("p"), {
      className: "dim small",
      textContent: "Chart.js CDN unavailable offline - score timeline disabled.",
    }));
    return;
  }
  chart = new Chart($("score-chart"), {
    type: "line",
    data: { labels: [], datasets: [] },
    options: {
      animation: false,
      scales: { y: { min: 0, max: 100 } },
      plugins: { legend: { display: false } },
    },
  });
}

window.addEventListener("DOMContentLoaded", () => {
  initChart();
  $("btn-reveal").onclick = () => {
    reveal = !reveal;
    $("btn-reveal").textContent = "Reveal MACs: " + (reveal ? "on" : "off");
    refresh();
  };
  $("btn-stim-start").onclick = () => post("/api/stimulus/start");
  $("btn-stim-on").onclick = () => post("/api/stimulus/mark_on");
  $("btn-stim-off").onclick = () => post("/api/stimulus/mark_off");
  $("btn-stim-end").onclick = () => post("/api/stimulus/end");
  refresh();
  setInterval(refresh, 1000);

  let ws;
  const connect = () => {
    try {
      ws = new WebSocket(`ws://${location.host}/ws`);
      ws.onclose = () => setTimeout(connect, 2000);
      ws.onmessage = (event) => {
        const state = JSON.parse(event.data);
        renderDevices(state.devices);
        renderAlerts(state.alerts);
        updateHistory(state.devices);
      };
    } catch (err) {
      /* polling fallback already runs */
    }
  };
  connect();
});
