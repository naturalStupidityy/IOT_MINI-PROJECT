"""UI: CLI and web dashboard (Phase 7 for the dashboard)."""

__all__: list = []
