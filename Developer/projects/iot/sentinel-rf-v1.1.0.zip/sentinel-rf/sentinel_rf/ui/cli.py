"""CLI entry point (``sentinel``).

Commands arrive with their phases and none is advertised before it works.
Hardware-facing commands (monitor, hotcold --live) are UNVERIFIED on a Pi
until docs/verification-log.md carries evidence (HARD RULE 5); everything
else runs on a laptop: replay/sim (parse-level), demo (full pipeline on
the simulator), serve (dashboard), train, calibrate, locate, report.
"""

from __future__ import annotations

import argparse
import sys
import time
from pathlib import Path
from typing import List, Optional

import sentinel_rf

__all__ = ["build_parser", "main"]


def build_parser() -> argparse.ArgumentParser:
    """Build the top-level argument parser."""
    parser = argparse.ArgumentParser(
        prog="sentinel",
        description=(
            "SENTINEL-RF: passive streaming-camera detection and localization on a "
            "Raspberry Pi 4B (headers-only capture, privacy-by-design)."
        ),
    )
    parser.add_argument(
        "--version",
        action="version",
        version=f"sentinel-rf {sentinel_rf.__version__}",
    )
    sub = parser.add_subparsers(dest="command")

    # ---- Phase 1: parse-level -------------------------------------------- #
    p_replay = sub.add_parser(
        "replay",
        help="parse a radiotap pcap file into observations and print a summary",
    )
    p_replay.add_argument("pcap", nargs="+", help="pcap file(s) captured with -s 128 on mon0")
    p_replay.add_argument("--node-id", default="replay-1", help="node id stamped on observations")
    p_replay.add_argument("--limit", type=int, default=0, help="stop after N observations (0=all)")
    p_replay.add_argument(
        "--salt-file", default=None, help="optional persisted salt file (stable hashes)"
    )

    p_sim = sub.add_parser(
        "sim", help="run the deterministic RF simulator and print a traffic summary"
    )
    p_sim.add_argument("--seed", type=int, default=42)
    p_sim.add_argument("--seconds", type=float, default=60.0)
    p_sim.add_argument(
        "--no-camera", action="store_true", help="drop camera devices (negative-control run)"
    )
    p_sim.add_argument(
        "--stimulus",
        action="store_true",
        help="camera bitrate follows a 10 s on/off light square wave",
    )
    p_sim.add_argument("--out-pcap", default=None, help="also write observations to a pcap file")
    p_sim.add_argument("--salt-file", default=None, help="optional persisted salt file")

    # ---- Phase 2: doctor --------------------------------------------------- #
    p_doctor = sub.add_parser(
        "doctor",
        help="environment diagnostics; hardware items report UNVERIFIED on a laptop",
    )
    p_doctor.add_argument("--json", action="store_true", help="machine-readable output")

    # ---- Phase 4: train ---------------------------------------------------- #
    p_train = sub.add_parser(
        "train", help="train the ML traffic classifier on simulator data (extras: 'ml')"
    )
    p_train.add_argument("--envs", type=int, default=8, help="simulated environments")
    p_train.add_argument("--seconds", type=float, default=120.0, help="seconds per environment")
    p_train.add_argument("--seed", type=int, default=1000, help="base simulator seed")
    p_train.add_argument("--out-dir", default="models", help="output directory for model + card")
    p_train.add_argument("--salt-file", default=None, help="optional persisted salt file")

    # ---- Phase 5: calibrate ------------------------------------------------- #
    p_cal = sub.add_parser(
        "calibrate", help="fit the room path-loss model (P0, n) and write the room profile"
    )
    p_cal.add_argument("--room", default="configs/rooms/lab.yaml", help="room profile to update")
    p_cal.add_argument(
        "--measurements",
        default=None,
        help="distance:rssi pairs from a live run, e.g. '1:-52.3,2:-59.1,4:-66.8'",
    )
    p_cal.add_argument(
        "--simulate",
        action="store_true",
        help="demo mode: synthesize measurements from a hidden truth model and fit them",
    )
    p_cal.add_argument("--seed", type=int, default=7, help="seed for --simulate")

    # ---- Phase 7: pipeline + dashboard -------------------------------------- #
    p_demo = sub.add_parser(
        "demo", help="run the full pipeline on the simulator (laptop-safe demo)"
    )
    p_demo.add_argument("--seed", type=int, default=42)
    p_demo.add_argument("--seconds", type=float, default=120.0)
    p_demo.add_argument("--interval", type=float, default=5.0, help="detection interval (s)")
    p_demo.add_argument(
        "--stimulus",
        action="store_true",
        help="auto-run the stimulus protocol during the demo (simulated light)",
    )
    p_demo.add_argument(
        "--web", action="store_true", help="serve the dashboard instead of the console table"
    )
    p_demo.add_argument("--port", type=int, default=8000)
    p_demo.add_argument("--db", default=None, help="persist observations to this SQLite file")
    p_demo.add_argument("--salt-file", default=None, help="optional persisted salt file")
    p_demo.add_argument(
        "--speed",
        type=float,
        default=4.0,
        help="simulator playback speed vs wall clock (0 = unpaced flood)",
    )

    p_monitor = sub.add_parser(
        "monitor",
        help="live monitor-mode capture through the full pipeline (UNVERIFIED on Pi; "
        "needs a monitor interface - see scripts/monitor_up.sh)",
    )
    p_monitor.add_argument(
        "--iface", default=None, help="monitor interface (default: capture.iface)"
    )
    p_monitor.add_argument(
        "--lock-channel",
        type=int,
        default=None,
        help="pin one channel instead of hopping (Lock mode)",
    )
    p_monitor.add_argument("--no-hop", action="store_true", help="disable channel hopping")
    p_monitor.add_argument("--ble", action="store_true", help="also run the BLE scanner")
    p_monitor.add_argument(
        "--no-wifi",
        action="store_true",
        help="disable Wi-Fi capture (BLE-only node; e.g. a macOS laptop via CoreBluetooth)",
    )
    p_monitor.add_argument("--serve", action="store_true", help="serve the dashboard")
    p_monitor.add_argument("--port", type=int, default=8000)
    p_monitor.add_argument("--duration", type=float, default=None, help="stop after N seconds")
    p_monitor.add_argument("--db", default=None, help="persist observations to this SQLite file")
    p_monitor.add_argument("--room", default=None, help="room profile for localization")
    p_monitor.add_argument("--salt-file", default=None, help="optional persisted salt file")

    p_serve = sub.add_parser(
        "serve", help="serve the dashboard on an already-configured demo/monitor pipeline"
    )
    p_serve.add_argument("--demo", action="store_true", help="source = simulator (laptop demo)")
    p_serve.add_argument("--seed", type=int, default=42)
    p_serve.add_argument("--seconds", type=float, default=3600.0)
    p_serve.add_argument("--port", type=int, default=8000)
    p_serve.add_argument("--db", default=None)
    p_serve.add_argument("--room", default=None)
    p_serve.add_argument("--salt-file", default=None)

    p_stim = sub.add_parser(
        "stimulus", help="control the stimulus experiment on a running dashboard server"
    )
    p_stim.add_argument("--url", default="http://127.0.0.1:8000", help="server base URL")
    p_stim.add_argument("action", choices=["start", "on", "off", "end"])

    p_locate = sub.add_parser(
        "locate", help="estimate a device's position from stored observations"
    )
    p_locate.add_argument("--db", default="data/sentinel.sqlite3", help="SQLite database")
    p_locate.add_argument("--target", required=True, help="addr_hash of the device")
    p_locate.add_argument("--room", default="configs/rooms/lab.yaml", help="room profile")
    p_locate.add_argument("--recent", type=float, default=120.0, help="use the last N seconds")

    p_report = sub.add_parser(
        "report", help="summarize a session store (counts, alerts, top devices) as Markdown"
    )
    p_report.add_argument("--db", default="data/sentinel.sqlite3")
    p_report.add_argument("--out", default=None, help="write to a file instead of stdout")

    p_hotcold = sub.add_parser("hotcold", help="hot-cold proximity hunting for one target device")
    p_hotcold.add_argument("--target", required=True, help="addr_hash of the target")
    p_hotcold.add_argument(
        "--simulate",
        action="store_true",
        help="laptop demo: walk a simulated path toward the target",
    )
    p_hotcold.add_argument("--seed", type=int, default=5)
    p_hotcold.add_argument("--iface", default=None, help="live monitor interface (UNVERIFIED)")
    p_hotcold.add_argument(
        "--led",
        choices=["real", "fake"],
        default="fake",
        help="ACT LED backend (real = sysfs, UNVERIFIED on laptop)",
    )
    p_hotcold.add_argument("--salt-file", default=None)

    p_collect = sub.add_parser(
        "collect", help="mesh collector: merge node summaries over MQTT and localize"
    )
    p_collect.add_argument("--room", default="configs/rooms/lab.yaml")
    p_collect.add_argument("--host", default=None, help="broker host (default: mqtt config)")

    return parser


# --------------------------------------------------------------------------- #
# Shared helpers
# --------------------------------------------------------------------------- #


def _load_salt(salt_file: Optional[str]) -> bytes:
    from sentinel_rf.crypto import load_or_create_salt, new_salt

    if salt_file:
        return load_or_create_salt(salt_file)
    return new_salt()


def _load_config(path: Optional[str] = None):
    from sentinel_rf.config import load_config

    return load_config(path)


def _load_model(config, model_path: Optional[str] = None):
    """Load the trained traffic model if present (extras 'ml')."""
    from sentinel_rf.detect.model import TrafficModel

    path = Path(model_path or "models/traffic_rf.joblib")
    if not path.is_file():
        return None
    try:
        model = TrafficModel.load(path)
        print(
            f"loaded traffic model {path} "
            f"(trained {model.card.dataset.get('n_samples', '?')} samples)"
        )
        return model
    except ImportError:
        print("NOTE: scikit-learn not installed; using the explainable rule baseline only")
        return None
    except Exception as exc:
        print(f"NOTE: could not load {path} ({exc}); using rules only")
        return None


def _build_detector(config, *, model=None, allow_raw: bool = False):
    from sentinel_rf.detect.engine import Detector
    from sentinel_rf.detect.rules import PriorsEngine
    from sentinel_rf.intel.ble_rules import BleRuleBook
    from sentinel_rf.intel.ssid_rules import SsidRuleBook
    from sentinel_rf.intel.watchlist import load_watchlist

    watchlist = load_watchlist()
    return Detector(
        config,
        priors=PriorsEngine(SsidRuleBook(watchlist), BleRuleBook(watchlist)),
        model=model,
        ble_rules=BleRuleBook(watchlist),
        min_frames=50,
        cooldown_s=120.0,
    )


def _open_store(config, db_override: Optional[str]):
    if not db_override:
        return None
    from sentinel_rf.transport.store import SqliteStore

    store = SqliteStore(db_override, batch_size=config.store.batch_size)
    print(f"persisting observations to {db_override}")
    return store


def _load_room(room_arg: Optional[str], config):
    from sentinel_rf.locate.anchors import RoomProfile

    path = room_arg or (str(config.locate.anchors_file) if config.locate.anchors_file else None)
    if path and Path(path).is_file():
        return RoomProfile.load(path)
    if Path("configs/rooms/lab.yaml").is_file():
        return RoomProfile.load("configs/rooms/lab.yaml")
    return None


def _print_top_talkers(observations, top: int = 12) -> None:
    by_device: dict = {}
    for obs in observations:
        entry = by_device.setdefault(
            obs.addr_hash,
            {"frames": 0, "bytes": 0, "role": obs.role.value, "ble": obs.source.value},
        )
        entry["frames"] += 1
        entry["bytes"] += obs.length
    ranked = sorted(by_device.items(), key=lambda kv: kv[1]["bytes"], reverse=True)[:top]
    print(f"\nTop talkers (of {len(by_device)} devices, by observed bytes):")
    print(f"{'addr_hash':<18} {'frames':>8} {'bytes':>12}  role    src")
    for addr_hash, e in ranked:
        print(f"{addr_hash:<18} {e['frames']:>8} {e['bytes']:>12}  {e['role']:<7} {e['ble']}")


# --------------------------------------------------------------------------- #
# Command implementations
# --------------------------------------------------------------------------- #


def cmd_replay(args: argparse.Namespace) -> int:
    from sentinel_rf.parse.pcap import iter_pcap_observations

    salt = _load_salt(args.salt_file)
    counters: dict = {}
    collected = []
    for path in args.pcap:
        try:
            for obs in iter_pcap_observations(
                path, node_id=args.node_id, salt=salt, counters=counters
            ):
                collected.append(obs)
                if args.limit and len(collected) >= args.limit:
                    break
            print(f"replayed {path}")
        except (OSError, ValueError) as exc:
            print(f"skipped {path}: {exc}")
            counters["file_errors"] = counters.get("file_errors", 0) + 1
    print(
        f"packets={counters.get('packets', 0)} parsed={counters.get('parsed', 0)} "
        f"radiotap_errors={counters.get('radiotap_errors', 0)} "
        f"unsupported={counters.get('unsupported', 0)}"
    )
    _print_top_talkers(collected)
    print(
        "\nNOTE: replay shows parse-level summaries only; run `sentinel demo` or "
        "`sentinel serve --demo` for the full scoring pipeline. Devices appear as "
        "salted hashes - raw MACs are never printed."
    )
    return 0


def cmd_sim(args: argparse.Namespace) -> int:
    from sentinel_rf.parse.pcap import write_observations_pcap
    from sentinel_rf.sim.generator import RfSimulator, square_wave, standard_devices

    salt = _load_salt(args.salt_file)
    stimulus = (lambda t: square_wave(t, period=10.0)) if args.stimulus else None
    sim = RfSimulator(
        seed=args.seed,
        duration_s=args.seconds,
        salt=salt,
        devices=standard_devices(with_camera=not args.no_camera),
        stimulus_signal=stimulus,
        allow_raw=bool(args.out_pcap),
    )
    observations = list(sim.observations())
    wifi = sum(1 for o in observations if o.source.value == "wifi")
    ble = len(observations) - wifi
    print(f"sim seed={args.seed} duration={args.seconds:g}s nodes={len(sim.node_positions)}")
    print(f"observations={len(observations)} (wifi={wifi}, ble={ble})")
    print("\nEvents per device kind:")
    for kind, count in sorted(sim.summary().items()):
        print(f"  {kind:<24} {count:>8}")
    _print_top_talkers(observations)
    if args.out_pcap:
        written = write_observations_pcap(args.out_pcap, observations, snaplen=128)
        print(f"\nwrote {written} Wi-Fi records to {args.out_pcap} (headers-only, snaplen 128)")
    return 0


def cmd_doctor(args: argparse.Namespace) -> int:
    from sentinel_rf.system.doctor import run_doctor

    return run_doctor(as_json=args.json)


def cmd_train(args: argparse.Namespace) -> int:
    from sentinel_rf.detect.dataset import build_training_data, dataset_summary
    from sentinel_rf.detect.model import TrafficModel, lodo_cross_validate

    salt = _load_salt(args.salt_file)
    print(f"building dataset: {args.envs} environments x {args.seconds:g}s ...")
    X, y, groups, meta = build_training_data(
        n_envs=args.envs, base_seed=args.seed, duration_s=args.seconds, salt=salt
    )
    summary = dataset_summary(meta, y)
    print(
        f"dataset: {summary['n_samples']} samples "
        f"({summary['n_positives']} camera-like / {summary['n_negatives']} other) "
        f"from {summary['n_devices']} devices in {summary['n_environments']} environments"
    )
    if summary["n_positives"] == 0 or summary["n_negatives"] == 0:
        print("ERROR: dataset needs both classes; check simulator configuration")
        return 1

    print("leave-one-device-out cross validation ...")
    metrics = lodo_cross_validate(X, y, groups)
    for name in ("accuracy", "precision", "recall", "f1", "roc_auc"):
        print(f"  {name:<10} {metrics[name]}")
    print(f"  samples    {metrics['n_samples']}  devices {metrics['n_devices']}")

    print("training final model on the full dataset ...")
    model = TrafficModel.train(X, y, seed=args.seed, dataset_info=summary)
    model.card.metrics = {"lodo_cv": metrics}
    out_dir = Path(args.out_dir)
    model.save(out_dir / "traffic_rf.joblib", out_dir / "model_card.yaml")
    print(f"saved {out_dir / 'traffic_rf.joblib'}")
    print(f"saved {out_dir / 'model_card.yaml'}")
    print(
        "\nNOTE: trained on SIMULATOR data (synthetic). Field performance must be "
        "re-validated on real captures before any operational claim."
    )
    return 0


def cmd_calibrate(args: argparse.Namespace) -> int:
    import numpy as np

    from sentinel_rf.locate.anchors import RoomProfile
    from sentinel_rf.locate.pathloss import PathLossModel, fit

    if bool(args.measurements) == bool(args.simulate):
        print("specify exactly one of --measurements or --simulate")
        return 2

    if args.simulate:
        rng = np.random.default_rng(args.seed)
        truth = PathLossModel(p0_dbm=float(rng.uniform(-46, -36)), n=float(rng.uniform(2.2, 3.4)))
        distances = [1.0, 2.0, 4.0, 8.0]
        data = [(d, truth.rssi_at(d) + rng.normal(0.0, 1.0)) for d in distances]
        print("--simulate: synthetic demo of the calibration flow (hidden truth below)")
        print(f"  hidden truth: P0={truth.p0_dbm:.1f} dBm, n={truth.n:.2f}")
    else:
        data = []
        for pair in args.measurements.split(","):
            distance_str, _, rssi_str = pair.partition(":")
            try:
                data.append((float(distance_str), float(rssi_str)))
            except ValueError as exc:
                print(f"cannot parse measurement {pair!r} (expected distance:rssi)")
                raise SystemExit(2) from exc
        if len(data) < 2:
            print("need at least two distance:rssi pairs")
            return 2

    print("calibration measurements:")
    for distance, rssi in data:
        print(f"  {distance:>5.2f} m  ->  {rssi:>6.1f} dBm")
    try:
        model = fit(data)
    except ValueError as exc:
        print(f"calibration failed: {exc}")
        return 1
    print(
        f"\nfitted: P0 = {model.p0_dbm:.2f} dBm at 1 m, n = {model.n:.3f}, "
        f"residual sigma = {model.sigma_db:.2f} dB"
    )
    print(
        "sanity: rssi(1m)={:.1f} rssi(2m)={:.1f} rssi(4m)={:.1f} rssi(8m)={:.1f}".format(
            model.rssi_at(1), model.rssi_at(2), model.rssi_at(4), model.rssi_at(8)
        )
    )

    profile = RoomProfile.load(args.room)
    RoomProfile(
        name=profile.name,
        width_m=profile.width_m,
        height_m=profile.height_m,
        pathloss=model,
        anchors=profile.anchors,
    ).save(args.room)
    print(f"room profile updated: {args.room}")
    if args.simulate:
        print("(simulated values - do NOT use this profile for real localization)")
    return 0


# ---- pipeline commands ------------------------------------------------------ #


def _sim_source(config, manager, *, seed, seconds, salt, stimulus_signal, speed=0.0):
    from sentinel_rf.capture.wifi_monitor import IteratorWifiSource
    from sentinel_rf.sim.generator import RfSimulator

    sim = RfSimulator(
        seed=seed,
        duration_s=seconds,
        salt=salt,
        stimulus_signal=stimulus_signal,
        allow_raw=False,
    )
    source = IteratorWifiSource(
        manager.queue,
        observations_factory=sim.observations,
        node_id="sim",
        speed=speed,
        name="simulator",
    )
    return sim, source


def _console_tick(pipeline) -> None:
    """Compact console rendering for `sentinel demo`."""
    state = pipeline.state()
    print(
        f"\n[t+{state['uptime_s']:>6.1f}s] frames={state['counters']['processed']} "
        f"devices={state['n_devices']} drops={state['capture'].get('drop_pct', 0)}% "
        f"stimulus={state['stimulus']['phase']}"
    )
    for device in state["devices"][:6]:
        marker = {"likely": "!!", "watch": "? ", "ignore": "  "}.get(device["band"], "  ")
        vendor = f" vendor={device['vendor']}" if device["vendor"] else ""
        print(
            f"  {marker} {device['addr_hash']}  score={device['score']:>5.1f} "
            f"({device['band']:<6}) frames={device['n_frames']}{vendor}"
        )
    for alert in state["alerts"][:2]:
        print(
            f"  ALERT {alert['addr_hash']} score={alert['score']} - "
            f"{'; '.join(alert['reasons'][:2])}"
        )


def _auto_stimulus(session, config, started_at: float) -> None:
    """Demo helper: run the stimulus protocol automatically on sim time."""
    elapsed = time.monotonic() - started_at
    baseline = config.detect.stimulus.baseline_s
    marks = [
        (baseline, True),
        (baseline + 5, False),
        (baseline + 10, True),
        (baseline + 15, False),
        (baseline + 20, True),
        (baseline + 25, False),
        (baseline + 30, True),
        (baseline + 35, False),
    ]
    if session.phase.value == "idle" and elapsed >= 1.0:
        session.start()
    for mark_at, on in marks:
        if elapsed >= mark_at and not getattr(session, "_auto_marks", set()) & {mark_at}:
            if session.phase.value == "baseline" and elapsed < baseline:
                continue
            try:
                session.mark(on)
                getattr(session, "_auto_marks", set()).add(mark_at)
            except RuntimeError:
                pass
    if elapsed >= baseline + 40 and session.phase.value != "done":
        session.end()


def _run_demo(args, config, serve: bool) -> int:
    from sentinel_rf.capture.manager import CaptureManager
    from sentinel_rf.intel.cache import IntelCache
    from sentinel_rf.pipeline import Pipeline
    from sentinel_rf.sim.generator import square_wave

    salt = _load_salt(args.salt_file)
    allow_raw = config.privacy.allow_raw_mac_live
    model = _load_model(config)
    detector = _build_detector(config, model=model)
    manager = CaptureManager(queue_size=config.capture.queue_size)
    stimulus_signal = (lambda t: square_wave(t - 60.0, period=10.0)) if args.stimulus else None
    sim, source = _sim_source(
        config,
        manager,
        seed=args.seed,
        seconds=args.seconds,
        salt=salt,
        stimulus_signal=stimulus_signal,
        speed=getattr(args, "speed", 4.0),
    )
    manager.wifi = source
    intel = IntelCache()
    sim.seed_intel(intel)
    store = _open_store(config, args.db)
    room = _load_room(getattr(args, "room", None), config)

    pipeline = Pipeline(
        config,
        manager=manager,
        detector=detector,
        intel=intel,
        store=store,
        room_profile=room,
        detect_interval_s=args.interval,
        allow_raw=allow_raw,
    )
    print(
        f"demo: simulator seed={args.seed} duration={args.seconds:g}s "
        f"interval={args.interval:g}s model={'yes' if model else 'rules-only'}"
    )
    if args.stimulus:
        print("stimulus: auto-running the protocol at t=60s (simulated light on/off)")
    print("devices appear as salted hashes (privacy by design)\n")

    if serve:
        return _serve_pipeline(pipeline, config, args.port)

    started = time.monotonic()

    def tick(pipe: Pipeline) -> None:
        if args.stimulus:
            _auto_stimulus(pipe.stimulus_session, config, started)
        _console_tick(pipe)

    pipeline.run(on_tick=tick)

    print("\n=== final state ===")
    _console_tick(pipeline)
    if store is not None:
        store.flush()
        print(f"\nstore: {store.counts()}")
        store.close()
    return 0


def _serve_pipeline(pipeline, config, port: int) -> int:
    try:
        import uvicorn
    except ImportError:
        print("uvicorn/fastapi not installed; install with: pip install -e '.[web]'")
        return 1
    from sentinel_rf.ui.api import create_app

    app = create_app(pipeline, config)
    print(f"dashboard: http://127.0.0.1:{port}/  (Ctrl-C to stop)")
    uvicorn.run(app, host=config.dashboard.host, port=port, log_level="warning")
    pipeline.stop()
    return 0


def cmd_demo(args: argparse.Namespace) -> int:
    config = _load_config()
    return _run_demo(args, config, serve=args.web)


def cmd_serve(args: argparse.Namespace) -> int:
    if not args.demo:
        print(
            "serve needs a source: use `sentinel serve --demo` (laptop) or "
            "`sentinel monitor --serve` (live capture, UNVERIFIED on Pi)"
        )
        return 2
    config = _load_config()
    args.interval = 5.0
    args.stimulus = False
    if not hasattr(args, "speed"):
        args.speed = 4.0
    return _run_demo(args, config, serve=True)


def cmd_monitor(args: argparse.Namespace) -> int:
    from sentinel_rf.capture.ble_scanner import BleakBleScanner
    from sentinel_rf.capture.channel_hopper import FakeChannelHopper, IwChannelHopper, LockChannel
    from sentinel_rf.capture.manager import CaptureManager
    from sentinel_rf.capture.wifi_monitor import TcpdumpWifiMonitor
    from sentinel_rf.intel.cache import IntelCache
    from sentinel_rf.pipeline import Pipeline
    from sentinel_rf.system.led import FakeLed  # noqa: F401 - re-export hint

    config = _load_config()
    salt = _load_salt(args.salt_file)
    iface = args.iface or config.capture.iface
    allow_raw = config.privacy.allow_raw_mac_live
    model = _load_model(config)
    detector = _build_detector(config, model=model)
    manager = CaptureManager(queue_size=config.capture.queue_size)

    if args.no_wifi:
        from sentinel_rf.capture.wifi_monitor import NullWifiMonitor

        manager.wifi = NullWifiMonitor(manager.queue, node_id=config.mqtt.node_id)
        print("Wi-Fi capture disabled: BLE-only node (receive-only, never connects)")
    else:
        print(f"live capture on {iface} (snaplen {config.capture.snaplen}, headers only)")
        print("UNVERIFIED on hardware until a session is recorded in docs/verification-log.md")
        manager.wifi = TcpdumpWifiMonitor(
            manager.queue,
            iface=iface,
            snaplen=config.capture.snaplen,
            node_id=config.mqtt.node_id,
            salt=salt,
            allow_raw=allow_raw,
        )
    if args.ble:
        manager.ble = BleakBleScanner(
            manager.queue,
            node_id=config.mqtt.node_id,
            salt=salt,
            allow_raw=allow_raw,
            scan_mode=config.capture.ble.scan_mode,
        )
    if args.no_wifi:
        manager.hopper = FakeChannelHopper([1], dwell_ms=1000)  # no radio to hop
    elif args.lock_channel:
        manager.hopper = None
        lock = LockChannel(args.lock_channel, iface=iface)
        print(f"lock mode: pinning {iface} to channel {args.lock_channel}")
        lock.start()
    elif not args.no_hop:
        manager.hopper = IwChannelHopper(
            list(config.capture.channel_plan.channels_2g),
            config.capture.channel_plan.dwell_ms,
            iface=iface,
        )
    else:
        manager.hopper = FakeChannelHopper([1], dwell_ms=1000)  # no-op pacing

    store = _open_store(config, args.db)
    room = _load_room(args.room, config)
    pipeline = Pipeline(
        config,
        manager=manager,
        detector=detector,
        intel=IntelCache(),
        store=store,
        room_profile=room,
        detect_interval_s=5.0,
        allow_raw=allow_raw,
    )
    if args.serve:
        return _serve_pipeline(pipeline, config, args.port)
    try:
        pipeline.run(duration_s=args.duration, on_tick=_console_tick)
    except KeyboardInterrupt:
        pipeline.stop()
    print("\n=== final state ===")
    _console_tick(pipeline)
    return 0


def cmd_stimulus(args: argparse.Namespace) -> int:
    import json
    import urllib.request

    action = {"start": "start", "on": "mark_on", "off": "mark_off", "end": "end"}[args.action]
    url = f"{args.url.rstrip('/')}/api/stimulus/{action}"
    try:
        request = urllib.request.Request(url, method="POST", data=b"")  # noqa: S310
        with urllib.request.urlopen(request, timeout=10) as response:  # noqa: S310
            payload = json.loads(response.read().decode("utf-8"))
    except Exception as exc:
        print(f"could not reach the dashboard at {args.url}: {exc}")
        print("start one first, e.g. `sentinel serve --demo` or `sentinel monitor --serve`")
        return 1
    print(payload.get("message", payload))
    return 0


def cmd_locate(args: argparse.Namespace) -> int:
    import math
    from collections import defaultdict

    from sentinel_rf.locate.anchors import RoomProfile
    from sentinel_rf.locate.grid import GridLocator
    from sentinel_rf.locate.lsq import wls_estimate
    from sentinel_rf.locate.pathloss import median_rssi
    from sentinel_rf.transport.store import SqliteStore

    if not Path(args.db).is_file():
        print(f"no store at {args.db}; run a session with --db first (e.g. `sentinel demo --db`)")
        return 1
    profile = RoomProfile.load(args.room)
    store = SqliteStore(args.db)
    rows = store.observations(limit=20000, addr_hash=args.target)
    store.close()
    if not rows:
        print(f"no stored observations for {args.target}")
        return 1
    cutoff = max(r["ts"] for r in rows) - args.recent
    per_node = defaultdict(list)
    for row in rows:
        if row["ts"] >= cutoff:
            per_node[row["node_id"]].append(row["rssi"])
    measurements = {node: median_rssi(v) for node, v in per_node.items()}
    print(f"target {args.target}")
    print(f"measurements (median of last {args.recent:g}s):")
    for node, rssi in sorted(measurements.items()):
        print(f"  {node:<10} {rssi:>7.1f} dBm  (n={len(per_node[node])})")

    locator = GridLocator(profile, grid_resolution_m=0.25)
    if len(measurements) >= 2:
        estimate = locator.estimate(measurements)
        print(
            f"\ngrid estimate: ({estimate.x:.2f}, {estimate.y:.2f}) m  "
            f"sigma={estimate.sigma_m:.2f} m  nodes={list(estimate.node_ids)}"
        )
        try:
            wls = wls_estimate(measurements, profile)
            print(f"wls cross-check: ({wls.x:.2f}, {wls.y:.2f}) m")
            gap = math.hypot(wls.x - estimate.x, wls.y - estimate.y)
            print(
                f"estimator gap: {gap:.2f} m"
                + ("  (large - treat with caution)" if gap > 1.5 else "")
            )
        except Exception as exc:
            print(f"wls cross-check unavailable: {exc}")
    else:
        node, rssi = next(iter(measurements.items()))
        estimate = locator.single_node_estimate(node, rssi)
        print(
            f"\nsingle anchor ({node}): ~{profile.pathloss.distance_from(rssi):.1f} m away "
            f"(a distance ring, not a point)"
        )
    return 0


def cmd_report(args: argparse.Namespace) -> int:
    from sentinel_rf.transport.store import SqliteStore

    if not Path(args.db).is_file():
        print(f"no store at {args.db}; run a session with --db first")
        return 1
    store = SqliteStore(args.db)
    counts = store.counts()
    devices = store.devices(limit=15)
    alerts = store.alerts(limit=20)
    events = store.events(limit=50)
    store.close()

    lines = [
        "# SENTINEL-RF session report",
        "",
        f"- observations: {counts['observations']}",
        f"- devices tracked: {counts['devices']}",
        f"- alerts: {counts['alerts']}",
        f"- events: {counts['events']}",
        "",
        "## Alerts",
        "",
    ]
    if alerts:
        for a in alerts:
            reasons = "; ".join(a["reasons"][:3])
            lines.append(
                f"- `{a['addr_hash']}` score {a['score']:.1f} ({a['verdict']}) - {reasons}"
            )
    else:
        lines.append("_None. This is NOT evidence that no cameras are present._")
    lines += [
        "",
        "## Most recently active devices",
        "",
        "| addr_hash | role | last verdict | last score |",
        "|---|---|---|---|",
    ]
    for d in devices:
        lines.append(
            f"| `{d['addr_hash']}` | {d['role'] or '-'} | {d['last_verdict'] or '-'} | "
            f"{d['last_score'] if d['last_score'] is None else round(d['last_score'], 1)} |"
        )
    stimulus_events = [e for e in events if "stimulus" in e["kind"]]
    if stimulus_events:
        lines += ["", "## Stimulus events", ""]
        for e in stimulus_events[:10]:
            lines.append(f"- {e['detail']}")
    text = "\n".join(lines) + "\n"
    if args.out:
        Path(args.out).write_text(text, encoding="utf-8")
        print(f"wrote {args.out}")
    else:
        print(text)
    return 0


def cmd_hotcold(args: argparse.Namespace) -> int:
    from sentinel_rf.capture.manager import CaptureManager
    from sentinel_rf.capture.wifi_monitor import TcpdumpWifiMonitor
    from sentinel_rf.locate.hotcold import HotColdGuide, console_blink
    from sentinel_rf.system.led import FakeLed, SysfsLed

    salt = _load_salt(args.salt_file)
    led = SysfsLed() if args.led == "real" else FakeLed()
    config = _load_config()

    if args.simulate:
        import numpy as np

        rng = np.random.default_rng(args.seed)
        path_distances = np.concatenate(
            [np.linspace(8.0, 4.0, 20), np.linspace(4.0, 1.2, 20), np.linspace(1.2, 2.5, 10)]
        )
        with HotColdGuide(led, render=console_blink) as guide:
            for distance in path_distances:
                rssi = -40.0 - 25.0 * np.log10(max(distance, 0.5)) + rng.normal(0, 2.0)
                guide.update(float(rssi))
                time.sleep(0.25)
        print("\n(simulated walk: approach, get close, step back)")
        return 0

    iface = args.iface or config.capture.iface
    manager = CaptureManager(queue_size=1024)
    manager.wifi = TcpdumpWifiMonitor(
        manager.queue,
        iface=iface,
        snaplen=config.capture.snaplen,
        node_id="hotcold",
        salt=salt,
    )
    manager.start()
    print(f"hot-cold hunting {args.target} on {iface}; walk the room (Ctrl-C to stop)")
    try:
        with HotColdGuide(led, render=console_blink, use_signals=True) as guide:
            while True:
                obs = manager.poll(0.5)
                if obs is not None and obs.addr_hash == args.target:
                    guide.update(obs)
    except (KeyboardInterrupt, SystemExit):
        pass
    finally:
        manager.stop()
    print()
    return 0


def cmd_collect(args: argparse.Namespace) -> int:
    from sentinel_rf.locate.anchors import RoomProfile
    from sentinel_rf.locate.grid import GridLocator
    from sentinel_rf.transport.mqtt import MeshCollector, MqttTransport

    config = _load_config()
    mqtt_config = config.mqtt
    if args.host:
        import dataclasses

        mqtt_config = dataclasses.replace(mqtt_config, host=args.host, enabled=True)
    if not mqtt_config.enabled:
        print("MQTT disabled in config (mqtt.enabled=false); a collector needs a broker")
        return 2
    profile = RoomProfile.load(args.room)
    locator = GridLocator(profile, grid_resolution_m=0.25)
    collector = MeshCollector()
    transport = MqttTransport(mqtt_config)
    transport.on_message(lambda topic, message: collector.ingest(message))
    print(f"collecting from broker {mqtt_config.host}:{mqtt_config.port} ...")
    if not transport.connect():
        print("could not connect to the broker (see logs)")
        return 1
    try:
        while True:
            time.sleep(5)
            for addr_hash, measurements in collector.measurement_sets().items():
                estimate = locator.estimate(measurements)
                summaries = {s["addr_hash"]: s for s in collector.device_summaries()}
                score = summaries.get(addr_hash, {}).get("best_score")
                print(
                    f"{addr_hash} score={score} -> "
                    f"({estimate.x:.2f}, {estimate.y:.2f}) m sigma={estimate.sigma_m:.2f}"
                )
    except KeyboardInterrupt:
        pass
    finally:
        transport.disconnect()
    return 0


def main(argv: Optional[List[str]] = None) -> int:
    """CLI entry point (console script)."""
    parser = build_parser()
    args = parser.parse_args(argv)
    handlers = {
        "replay": cmd_replay,
        "sim": cmd_sim,
        "doctor": cmd_doctor,
        "train": cmd_train,
        "calibrate": cmd_calibrate,
        "demo": cmd_demo,
        "monitor": cmd_monitor,
        "serve": cmd_serve,
        "stimulus": cmd_stimulus,
        "locate": cmd_locate,
        "report": cmd_report,
        "hotcold": cmd_hotcold,
        "collect": cmd_collect,
    }
    handler = handlers.get(args.command)
    if handler is None:
        parser.print_help()
        return 0
    return handler(args)


if __name__ == "__main__":  # pragma: no cover
    sys.exit(main())
