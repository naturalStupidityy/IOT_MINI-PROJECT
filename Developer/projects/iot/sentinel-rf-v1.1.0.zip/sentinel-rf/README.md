# SENTINEL-RF

Passive RF sensing on a Raspberry Pi 4B: spot Wi-Fi/BLE devices behaving like
**live-streaming hidden cameras**, explain every alert with a transparent
evidence score, and narrow down where the device is using RSSI
multilateration. ETCS338 (Internet of Things) mini project.

![dashboard](docs/images/dashboard.png)

> **This is a screening aid, not proof.** Detecting nothing is NOT evidence
> that no cameras are present; physical inspection is the confirmation.
> Cameras that only record to SD card, wired cameras and cellular cameras are
> invisible to this system by design.

## Hard rules (never violated)

1. **Passive only.** No packet injection, deauthentication, password cracking
   or joining other networks. Nexmon's injection capability is never exposed.
2. **Headers only.** Capture uses a small snap length (~128 bytes, bounded to
   64-256 in config validation). Payload bytes are never stored or logged.
3. **Privacy by design.** MAC addresses are stored and exported only as
   salted hashes (per-session salt, configurable). Raw MACs appear only in
   live in-memory state and the local dashboard behind an opt-in flag.
4. **No new hardware.** The Pi's built-in radio is the only required sensor;
   extras (more Pis, power bank, LED) degrade gracefully.
5. **Be honest.** Nothing is claimed to work on the Pi without pasted-back
   evidence recorded in [docs/verification-log.md](docs/verification-log.md).
   Unverified hardware paths are marked UNVERIFIED.
6. **Out of scope:** SD-only / wired / cellular cameras, traffic decryption.
7. A missing stimulus response means **inconclusive**, never "clear".

## Status

| Phase | Scope | State |
|---|---|---|
| 0 | scaffold, Observation model, privacy core, config, logging | **done** (v0.1.0) |
| 1 | Radiotap/802.11 parsers, PCAP replay, deterministic simulator | **done** (v0.2.0) |
| 2 | live capture, channel hopper, BLE, `sentinel doctor` - first Pi session | **done** (v0.3.0, hardware paths UNVERIFIED) |
| 3 | features + intel (OUI, SSID, BLE watchlists) | **done** (v0.4.0) |
| 4 | detection: rules, ML, stimulus correlator, fusion, ablation | **done** (v0.5.0, ML is simulator-trained) |
| 5 | localization: calibration, grid, WLS, survey, mesh, hot-cold LED | **done** (v0.6.0; ACT LED UNVERIFIED) |
| 6 | SQLite store, MQTT, multi-node collector | **done** (v0.7.0) |
| 7 | CLI subcommands + FastAPI dashboard | **done** (v0.8.0) |
| 8 | hardening: systemd, soak+fuzz tests, coverage gate | **done** (v0.9.0; deployment UNVERIFIED) |
| 9 | documentation + report kit | **done** (v1.0.0) |

Headline measured results (simulator, deterministic seeds -
[docs/EXPERIMENTS.md](docs/EXPERIMENTS.md)): alert **precision 1.000 /
recall 0.778** end-to-end with the ML model; stimulus correlator **6/6
cameras responsive** (mean |r| = 0.62, p ≤ 0.001) vs 11/12 unrelated
devices inconclusive; localization **0.48 m mean error** with four
anchors; 0% frame drops in the soak test. Coverage floors: parse 94 /
features 97 / detect 93 / locate 94 %. **No hardware session has happened
yet** - every hardware path is UNVERIFIED (rule 5).

## Quick start (laptop, no Pi needed)

Works the same on macOS, Linux and the Pi; see the platform matrix below
for what each OS can and cannot do.

```bash
git clone <this-repo> && cd sentinel-rf
python3 -m venv .venv && source .venv/bin/activate
python3 -m pip install --upgrade pip "setuptools>=61,<80" wheel   # macOS: REQUIRED once per venv
pip install -e ".[all,dev]"
scripts/test.sh                       # ruff + black + pytest (fast gate)

sentinel demo                         # full pipeline on the simulator, console
sentinel demo --stimulus --seconds 150  # ...including the light on/off protocol
sentinel serve --demo                 # the dashboard at http://127.0.0.1:8000
sentinel doctor                       # honest environment diagnostics
```

On macOS you can also run `bash scripts/setup_macos.sh`, which does all of
the above (including the pip upgrade that old macOS venvs need) and prints
what works locally. If you skip the pip upgrade and your pip is older than
21.3, the `setup.py` compatibility shim in the repo root upgrades
setuptools for you automatically; with a modern pip the shim is inert.

## Platform matrix

| Capability | macOS (dev/demo) | Kali (kali-fallback branch) | Raspberry Pi OS (main) |
|---|---|---|---|
| install + test suite | yes | yes | yes |
| simulator / demo / dashboard | yes | yes | yes |
| PCAP replay + report kit | yes | yes | yes |
| ML training (LODO CV) | yes | yes | yes |
| real BLE scanning (receive-only) | yes (CoreBluetooth, macOS 12+) | yes (BlueZ) | yes (BlueZ) |
| BLE-only mesh node | yes: `monitor --no-wifi --ble` | yes | yes |
| monitor-mode Wi-Fi capture | no (no public API) | expected out of the box (UNVERIFIED) | Nexmon kernels <= 5.15 only |
| channel hopping (iw) | no | yes | with Nexmon |
| ACT LED hot-cold hunting | no | no | yes |
| /proc resource sampling | no (nulls, harmless) | yes | yes |

Rule of thumb: **capture on Kali/Pi, develop and present on macOS.** Copy a
PCAP from the capture node to any Mac and `sentinel replay <file.pcap>` walks
the same parser/feature/detection path the live node uses.

The privacy boundary in 30 seconds:

```python
from sentinel_rf import InMemoryStore, Observation, mac_hash, new_salt

salt = new_salt()                                   # fresh per-session salt
obs = Observation.wifi(
    ts=1.0, node_id="n1", rssi_dbm=-55.0,
    addr_hash=mac_hash("AA:BB:CC:DD:EE:FF", salt),  # stored form: salted hash
    length=1200, raw_addr="AA:BB:CC:DD:EE:FF",      # live-only, never stored
)
store = InMemoryStore()
store.add_observation(obs)
print(store.observations()[0]["addr_hash"])   # hash only; raw_addr never serialized
```

## CLI map

| command | what it does | needs hardware? |
|---|---|---|
| `sentinel demo [--stimulus] [--web]` | full pipeline on the simulator | no |
| `sentinel serve --demo` | dashboard on the simulator | no |
| `sentinel replay <pcap...>` | parse-level pcap summaries | no |
| `sentinel sim` | traffic summary of a simulated environment | no |
| `sentinel doctor [--json]` | environment diagnostics (UNVERIFIED-aware) | no |
| `sentinel train` | train the ML model + model card (LODO CV) | no |
| `sentinel calibrate --measurements '...'` | fit room path-loss P0/n | measurements |
| `sentinel stimulus --url ... on\|off` | control a running server's experiment | no |
| `sentinel locate --db ... --target HASH` | grid+WLS position from a store | no |
| `sentinel report --db ...` | Markdown session summary | no |
| `sentinel hotcold --target HASH [--simulate]` | proximity hunting (LED + console) | live: yes |
| `sentinel monitor [--serve]` | live monitor-mode capture (UNVERIFIED) | yes |
| `sentinel monitor --no-wifi --ble [--serve]` | BLE-only receive node (macOS works) | BLE radio |
| `sentinel collect` | MQTT mesh collector + localization | broker |

## Layout

```
sentinel-rf/
  sentinel_rf/
    __init__.py  config.py  crypto.py  defaults.py  logging_setup.py  privacy.py
                 pipeline.py
    parse/       observation.py  radiotap.py  dot11.py  ble_adv.py  pcap.py
    capture/     wifi_monitor.py  ble_scanner.py  channel_hopper.py
                 manager.py  pcap_replay.py  fakes.py
    features/    windows.py  stats.py
    intel/       oui.py  watchlist.py  ssid_rules.py  ble_rules.py  cache.py
                 data/oui.csv
    detect/      rules.py  model.py  stimulus.py  fusion.py  engine.py
                 dataset.py  ablation.py
    locate/      pathloss.py  anchors.py  grid.py  lsq.py  survey.py  hotcold.py
    transport/   store.py  mqtt.py  thingspeak.py
    ui/          cli.py  api.py  static/ (dashboard)
    sim/         generator.py
    system/      led.py  temperature.py  resources.py  doctor.py
  configs/       default.yaml  watchlist.yaml  rooms/lab.yaml  mosquitto/
  scripts/       test.sh  test_full.sh  check_coverage.py  run_experiments.py
                 setup_pi.sh  setup_macos.sh  monitor_up.sh  monitor_down.sh
  systemd/       sentinel-monitor.service  sentinel-demo.service
  docs/          REPORT.md  ARCHITECTURE.md  PRIVACY_SAFETY.md  DEPLOYMENT.md
                 CALIBRATION.md  EXPERIMENTS.md  verification-log.md
                 explainer.pdf  presentation-script.docx
                 results/  images/
  tests/         398 tests incl. privacy acceptance, fuzz, soak
```

## Documentation

- **[docs/REPORT.md](docs/REPORT.md)** - the course report (results, methods,
  limitations).
- **[docs/ARCHITECTURE.md](docs/ARCHITECTURE.md)** - layers, data model,
  failure philosophy.
- **[docs/PRIVACY_SAFETY.md](docs/PRIVACY_SAFETY.md)** - the seven rules in
  engineering terms; what is stored where.
- **[docs/DEPLOYMENT.md](docs/DEPLOYMENT.md)** - Pi bring-up (UNVERIFIED),
  the kernel question, systemd, mesh.
- **[docs/CALIBRATION.md](docs/CALIBRATION.md)** - path-loss calibration,
  waypoint survey, hot-cold hunting.
- **[docs/EXPERIMENTS.md](docs/EXPERIMENTS.md)** - every measured number and
  how to reproduce it.
- **[docs/explainer.pdf](docs/explainer.pdf)** - first-principles explainer,
  final-day runbook (Kali ARM / macOS focus) and the ETCS338 syllabus
  mapping, as a single PDF.
- **[docs/presentation-script.docx](docs/presentation-script.docx)** - the
  4-speaker, 12-minute presentation script with roles, demo cues and Q&A
  prep.

## Branches

- `main` - primary path: Raspberry Pi OS + Nexmon (see TODO for the
  OS-image pinning question); also carries `scripts/setup_macos.sh` so
  Macs bootstrap the dev/demo install from the same branch.
- `kali-fallback` - Kali ARM bootstrap path (`scripts/setup_kali.sh`,
  `docs/kali-fallback.md`). Maintained by merging `main` in at each phase
  gate; divergence is limited to OS/bootstrap scripts (DECISIONS.md D003).

## Configuration

`configs/default.yaml` documents every key inline. Override by copying to
`configs/local.yaml` (gitignored) and exporting `SENTINEL_RF_CONFIG`, or by
passing a path to `load_config()`. Unknown keys and out-of-range values fail
with the full dotted key path. MQTT credentials come from the environment
(`SENTINEL_MQTT_USER` / `SENTINEL_MQTT_PASS`), never from files in the repo.

## Development

- `scripts/test.sh` - fast gate: ruff, `black --check`, pytest (~2-3 min).
- `scripts/test_full.sh` - full gate: + slow model/soak tests + per-package
  coverage floors ≥ 80 % (parse/features/detect/locate).
- `python3 scripts/run_experiments.py` - regenerates docs/results/.
- Config defaults live in the dataclasses and in the YAML; tests fail if
  they drift. Same for the watchlist.
- Decisions are logged in [DECISIONS.md](DECISIONS.md) (40 entries); open
  items in [TODO.md](TODO.md); phase history in [CHANGELOG.md](CHANGELOG.md).
- Git identity in the delivered history is a placeholder
  (`SENTINEL-RF Project <sentinel-dev@example.invalid>`); reset it if you
  care.

## License

MIT - pending faculty-guide confirmation (DECISIONS.md D004).

## Ethics & legality

Test only on your own devices and premises, or with the owners' written
consent. Passive, header-only capture; hashed identifiers; no publication of
captured data about other people's devices. Applicable law (including the IT
Act 2000 provisions on unauthorized access and interception) and university
rules apply; confirm field-trial scope with your guide first.
