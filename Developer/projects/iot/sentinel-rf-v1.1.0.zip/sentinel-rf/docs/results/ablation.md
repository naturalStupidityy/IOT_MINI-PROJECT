## Fusion ablation (28 labelled device windows)

```
variant                    n   tp   fp   fn   prec    rec     f1
----------------------------------------------------------------
full fusion               28    5    0    2  1.000  0.714  0.833
without priors            28    7    0    0  1.000  1.000  1.000
without traffic           28    0    0    7  0.000  0.000  0.000
without stimulus          28    5    0    2  1.000  0.714  0.833
without ble               28    5    0    2  1.000  0.714  0.833
rules only (no ML)        28    0    0    7  0.000  0.000  0.000
```
