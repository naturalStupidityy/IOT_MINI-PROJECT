# Architecture

SENTINEL-RF is a layered pipeline with one data model and hard boundaries.
Everything downstream of capture consumes `Observation` records only.

```
                        ┌────────────────────────────────────────────────┐
                        │                 capture layer                  │
  mon0 (UNVERIFIED) ───►│ TcpdumpWifiMonitor   pcap replay   simulator  │
  BlueZ (UNVERIFIED) ──►│ BleakBleScanner      fakes (laptop)            │
                        │ ChannelHopper (Scan) / LockChannel (Lock)      │
                        └───────────────┬────────────────────────────────┘
                                        │ bounded queue (drop-counted)
                        ┌───────────────▼────────────────┐
                        │          parse layer           │   radiotap → dot11 →
                        │ Observation + EphemeralWifi    │   BLE AD structures
                        └───────────────┬────────────────┘
                                        │ Observation stream
        ┌───────────────┬───────────────┼────────────────┬──────────────┐
        ▼               ▼               ▼                ▼              ▼
  features/       intel/          detect/          transport/      locate/
  DeviceTracker   IntelCache      Detector         SqliteStore     GridLocator
  3 windows       (memory-only)   stimulus         MQTT mesh       WLS
  23 features     OUI/SSID/BLE    fusion 0-100     ThingSpeak      survey
                                  + alerts         (aggregates     hot-cold
                                                   only)           LED
        └───────────────┴───────────────┴────────┬──────┴──────────────┘
                                                ▼
                                     ui/  (CLI + FastAPI)
                                     dashboard: scores, evidence,
                                     heatmap, stimulus controls
```

## Data model (frozen contract)

`Observation` (schema v1, `sentinel_rf/parse/observation.py`) is the only
shape any layer exchanges: timestamp, source, node, RSSI, salted address
hash, length, channel/frequency, role, 802.11 header bits, and the
whitelisted BLE advertisement fields. `raw_addr` is live-memory-only:
`to_dict()` never emits it and `from_dict()` refuses it - the store and
every export re-check each payload with `assert_no_raw_mac`.

## Key flows

- **Detection**: every `detect.interval_s` of *event time* (deterministic
  under any replay speed) the Detector scores each tracked device: priors
  (15) + traffic rules blended with the ML model (35) + stimulus
  correlation (40) + BLE corroboration (10), renormalized over available
  components. Bands: <30 ignore, 30-60 watch, >=60 likely.
- **Localization**: per-node median RSSI over the tracked window (or merged
  MQTT summaries in mesh mode) feeds the 0.25 m likelihood grid; WLS is the
  cross-check; a single node degrades to an honest distance ring.
- **Stimulus**: baseline -> marked on/off window -> per-second rate series
  per device -> lag-searched Pearson + permutation test (corrected for the
  lag search). No response = inconclusive, never exculpatory (HARD RULE 7).

## Failure philosophy

- Capture never blocks: the queue is bounded; overflow is *counted* and
  surfaced as `drop_pct` (budget < 2%).
- Parse errors are counted, never raised into the loop (fuzz-tested with
  ~15k hostile buffers).
- Store/transport failures decrement health counters; sensing continues.
- LED control always restores the original trigger (finally + signal
  handlers).
- Hardware absence degrades: no bleak -> BLE layer off; no model -> rules
  only; no iw -> doctor says UNVERIFIED, nothing pretends.

## Where the UNVERIFIED lines are

Every path that needs the physical Pi is behind an interface with a fake:
tcpdump subprocess, `iw` channel control, bleak scanning, the ACT LED,
SoC temperature. `sentinel doctor` reports each one honestly; until
docs/verification-log.md has pasted output, none of them is claimed to
work on the Pi (HARD RULE 5).
