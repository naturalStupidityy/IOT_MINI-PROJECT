# Experiments & results

All numbers below were produced by `scripts/run_experiments.py`
(deterministic seeds, salt recorded in `docs/results/summary.json`) on the
development laptop - **simulator data only**. Field re-validation on real
captures is future work (see REPORT.md, Limitations). Raw JSON lives in
`docs/results/`.

## E1 - ML traffic classifier (leave-one-device-out CV)

Dataset: 8 randomized simulator environments, 261 labelled device-windows
(52 camera-like / 209 other) from 31 distinct devices. Leave-one-device-
out means no device is ever in both train and test folds.

| metric | value |
|---|---|
| accuracy | 0.969 |
| precision | 1.000 |
| recall | 0.846 |
| F1 | 0.917 |
| ROC-AUC | 1.000 |

The missed positives are predominantly `camera_lowres` devices (quarter
bitrate) - deliberately the hardest positives in the cast.

## E2 - Fusion ablation

`docs/results/ablation.md` holds the full table (42 labelled windows).
Headline: ablating **traffic** collapses F1 hardest; ablating **stimulus**
is invisible in this experiment *because no stimulus ran* (it is
unavailable and its weight renormalizes away - exactly the designed
behaviour); **rules-only** (no ML) keeps most precision but loses the
margin on the low-res cameras.

## E3 - Localization accuracy (4 anchors, sigma = 3 dB shadowing)

| estimator | mean error | median | p90 | max |
|---|---|---|---|---|
| likelihood grid (0.25 m) | **0.48 m** | 0.45 m | 0.84 m | 1.29 m |
| robust WLS (cross-check) | 0.67 m | 0.59 m | - | - |

Mean grid-vs-WLS disagreement: 0.32 m (they agree; when they don't, treat
the measurement set with caution). Single-anchor mode reports a distance
ring with sigma >= distance/2 by design.

## E4 - Stimulus correlator

Six seeds; camera bitrate follows a 20 s on/off scene signal; the
protocol marks on/off through the API as an operator would.

| device class | outcome |
|---|---|
| cameras | **6/6 responsive** (mean abs r = 0.62, all p <= 0.001) |
| BLE watch | 6/6 inconclusive |
| video-call phone | 5/6 inconclusive, 1/6 weakly significant |

The stray "weak" on a video call is the honest face of a correlator: it
feeds evidence, it does not convict (and a person on a call genuinely can
move with the lights).

## E5 - End-to-end detection (model loaded, no stimulus)

Five randomized environments, threshold at fusion score >= 60:

| quantity | value |
|---|---|
| true positives / false positives | 7 / **0** |
| false negatives / true negatives | 2 / 31 |
| precision | **1.000** |
| recall | 0.778 |

Per-kind mean scores: camera 65.6 (all 'likely'), camera_lowres 59.8
(1/3 'likely' - they sit deliberately at the boundary), bulk-upload
laptop 12.7, browsing 2.0, AP 0.8. The two missed cameras were lowres
devices inside their watch band (58.5 and 59.5) - one stimulus test
would settle them, which is precisely the workflow the fusion weights
encode (stimulus 40/100).

## Operating budget (soak test)

`pytest -m slow tests/test_soak.py`: 60 s of simulated traffic at 8x
playback through the full pipeline - 0% drops, RSS well under 300 MB,
every observation accounted for; an unpaced flood variant proves drops
are counted, never silent. The on-Pi procedure is in
docs/DEPLOYMENT.md (UNVERIFIED until run).

## Reproducing

```bash
pip install -e ".[all,dev]"
scripts/test_full.sh          # lint + format + full tests + coverage floors
python3 scripts/run_experiments.py   # ~2 minutes; rewrites docs/results/
```
