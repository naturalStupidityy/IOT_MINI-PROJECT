# Calibration & survey guide

Localization is only as good as its two inputs: the room's path-loss
model and the anchor coordinates. Both are measured once per room with a
tape measure and about ten minutes of walking around.

## 1. Anchors (node positions)

For each sensor node, measure its position in the room frame (origin at a
corner, x along the long wall, y along the short one) and write it into
the room profile:

```yaml
# configs/rooms/lab.yaml
name: lab-demo
width_m: 5.0
height_m: 4.0
anchors:
  - {node_id: node-1, x: 0.3, y: 0.3}
  - {node_id: node-2, x: 4.7, y: 0.3}
```

Multi-node deployments want anchors spread over the room (corners are
ideal): localization quality collapses when all anchors sit in one spot.

## 2. Path-loss calibration (P0, n)

RSSI follows `RSSI(d) = P0 - 10*n*log10(d)`. Both parameters are room-
specific (walls, furniture, people).

1. Start the monitor and open the dashboard (or note the median RSSI the
   target device shows).
2. Hold a reference device (the phone you carry works) at **1 m** in
   front of the node, wait ~15 s, note the median RSSI. Repeat at
   **2 m, 4 m, 8 m** (a tape measure or floor tiles help).
3. Fit and store:

```bash
sentinel calibrate --measurements '1:-52.3,2:-59.1,4:-66.8,8:-73.9'
```

The command prints the fitted P0/n, a residual sigma and a sanity table;
implausible exponents are rejected. The room profile is updated in place.

Demo the flow without hardware: `sentinel calibrate --simulate`.

## 3. Waypoint survey (single-node triangulation-by-walking)

With one node you cannot multilaterate from one place - but you can from
several. The survey procedure (Phase 5 API/`locate` support):

1. Mark >= 4 waypoints around the room (corners of a 2x2 m grid work).
2. At each waypoint, stand still for 30-60 s with the monitor running
   (`locate.survey_sample_s` in the config).
3. The per-node medians over each waypoint merge into a measurement set;
   the grid estimator then produces a position and a credible radius.

On a laptop the same machinery runs against the simulator
(`tests/test_locate.py::TestSurvey`).

## 4. Hot-cold hunting (finding it with your feet)

When the score says "likely" but you want the exact shelf:

```bash
sentinel hotcold --target <addr_hash>            # console bar + ACT LED
```

Walk the room slowly. The ACT LED (and the console bar) encodes
proximity: solid = very close, fast blink = close, slow = far, faint
double-pulse = cold. The LED trigger is always restored on exit. On a
laptop, `sentinel hotcold --target x --simulate` walks a synthetic path.

## 5. Mesh mode

With >= 2 nodes reporting over MQTT, `sentinel collect` merges their
per-device medians and localizes continuously - no walking required.
Calibrate the path-loss model *once per room* (nodes share it); anchor
positions must be in the same room frame.
