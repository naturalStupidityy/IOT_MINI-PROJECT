# Hardware verification log - HARD RULE 5

Anything claimed to "work on the Pi" must be backed by an entry in this file:
date, exact command, trimmed pasted output, and the conclusion drawn from it.
Until an entry exists, every hardware-facing code path is **UNVERIFIED** and
must be labelled as such in code comments and docs.

How to add an entry: run the command on the Pi, paste the output into the
table (trim noise), and commit. Do not paraphrase outputs into "works" -
keep the actual numbers.

| Date | Item | Command | Result (pasted output) | Conclusion |
|---|---|---|---|---|
| - | - | - | No hardware runs yet. Phase 0 was laptop-only by design; first Pi session is Phase 2 (`sentinel doctor`). | Everything hardware-facing is UNVERIFIED. |
