# Deployment

Pick the platform by role; all three run the identical code base:

| Role | Platform | Bootstrap |
|---|---|---|
| Wi-Fi monitor-mode capture node | Kali ARM on the Pi 4B (kali-fallback branch) | `sudo bash scripts/setup_kali.sh` |
| Wi-Fi capture node (legacy path) | Raspberry Pi OS + Nexmon, kernel <= 5.15 (main) | `sudo bash scripts/setup_pi.sh` |
| Developer / presentation machine | macOS (main branch) | `bash scripts/setup_macos.sh` |
| BLE-only evidence node | any Mac (CoreBluetooth) or the Kali box | `sentinel monitor --no-wifi --ble --serve` |

Everything hardware-facing is **UNVERIFIED until a bring-up session is
recorded in docs/verification-log.md** (HARD RULE 5). macOS needs none of
this - see the README quick start (`sentinel demo`).

## 0. Choose the capture platform (decide first)

The Pi 4B's bcm43455c0 radio supports monitor mode only with Nexmon-
patched firmware, which exists for kernels up to ~5.15 (firmware
7.45.154/7.45.189 eras). Current Raspberry Pi OS images ship 6.x kernels.

```bash
uname -r
cat /etc/os-release
```

- **Kali ARM image for the Pi** (kali-fallback branch): ships nexmon-
  patched firmware for the built-in Wi-Fi, so monitor mode is expected to
  work out of the box. This is the recommended final-day capture path.
- Kernel <= 5.15 on Raspberry Pi OS: the Nexmon path may apply (see the
  Nexmon README for the bcm43455c0 table; patching is a manual,
  warranty-voiding step).
- Anything newer on Raspberry Pi OS: do NOT try to downgrade the system;
  flash a compatible image (Kali ARM, or a legacy Raspberry Pi OS with
  kernel <= 5.15) or choose **managed-mode scanning** (limited: no
  frame-level traffic profiles).
- A monitor-capable USB adapter (e.g. RTL8812AU class) on any Linux box
  also works with the same `scripts/monitor_up.sh` flow.
- Either way, `sentinel doctor` reports the facts; nothing is assumed.

## 0a. macOS machines (developer / presentation role)

```bash
bash scripts/setup_macos.sh            # venv + pip upgrade + install + doctor
sentinel serve --demo                  # dashboard on the simulator
sentinel monitor --no-wifi --ble --serve   # REAL BLE node via CoreBluetooth
sentinel replay <capture.pcap>         # walk a PCAP from the Kali node
```

Grant the terminal Bluetooth access (System Settings > Privacy & Security >
Bluetooth) before the BLE node can see advertisements. macOS cannot do
monitor-mode Wi-Fi capture; give that role to the Kali/Pi node and replay
captures on the Mac. The `scripts/*.sh` gates run on the stock bash 3.2.

## 1. Software bootstrap (capture nodes)

```bash
sudo bash scripts/setup_pi.sh            # packages, venv, config, units
# on Kali (kali-fallback branch):
sudo bash scripts/setup_kali.sh          # same flow, Kali packages
sentinel doctor                          # verify: everything OK/UNVERIFIED
```

Secrets go in `/etc/sentinel/sentinel.env` (mode 600), never in git.

## 2. Monitor interface

```bash
sudo bash scripts/monitor_up.sh          # creates mon0 (fails honestly on stock kernels)
iw dev mon0 info                         # paste into docs/verification-log.md
```

While mon0 is up the Pi's Wi-Fi cannot associate to any network -
**use Ethernet** for the dashboard and mesh backhaul.

## 3. Calibrate the room

See [CALIBRATION.md](CALIBRATION.md). Short version: hold a reference
device at 1/2/4/8 m from the node, read the median RSSI off the dashboard
(or `sentinel locate` output) at each distance, then:

```bash
sentinel calibrate --measurements '1:-52.3,2:-59.1,4:-66.8,8:-73.9'
```

## 4. Run

```bash
sudo systemctl start --no-block sentinel-monitor
# dashboard: http://<pi-ethernet-ip>:8000/
journalctl -u sentinel-monitor -f
```

The unit enforces the operating budget (CPUQuota=50%, MemoryMax=320M) and
restarts on failure. Observations persist to
`/var/lib/sentinel/sentinel.sqlite3` with a 7-day retention purge
(configurable).

## 5. Multi-node mesh (optional)

1. Broker on the collector host: install
   `configs/mosquitto/sentinel.conf` into `/etc/mosquitto/conf.d/`, create
   the sentinel user with `mosquitto_passwd`.
2. Each node: set `mqtt.enabled: true`, host, distinct `node_id`; anchors
   for every node in the room profile.
3. Collector: `sentinel collect --room configs/rooms/lab.yaml`.
4. Time matters for merging: run chrony on all nodes.

## 6. On-Pi soak procedure (budget verification)

Run for >= 30 minutes in the target room, then check the dashboard health
row (or `/api/status`):

- `capture.drop_pct` < 2%
- `resources.rss_mb` < 300
- SoC temperature stable (doctor reports it)

Record the numbers in docs/verification-log.md. The laptop equivalent is
`pytest -m slow tests/test_soak.py`.

## 7. Tear-down / troubleshooting

```bash
sudo systemctl stop sentinel-monitor
sudo bash scripts/monitor_down.sh        # Wi-Fi back to managed mode
```

- tcpdump exits immediately -> `iw dev mon0 info` still shows monitor?
  Check the interface exists and you are root.
- No BLE devices -> is BlueZ running (`systemctl status bluetooth`)?
  Install the `ble` extra. Passive mode still sees advertisements.
- LED never blinks in hot-cold -> check `/sys/class/leds/led0` exists
  (doctor); the console bar is the fallback.
