# Privacy & safety design

## The seven hard rules

1. **Passive only.** No injection, no deauthentication, no cracking, no
   joining networks. The only transmitted frames SENTINEL-RF ever causes
   are (optionally) BLE *scan requests* for names/TX-power, which the
   config can disable (`capture.ble.scan_mode: passive`). Nexmon's
   injection capability is deliberately not exposed anywhere in the code.
2. **Headers only.** Snaplen is hard-bounded to 64-256 bytes by config
   validation; the tcpdump command line enforces `-s <snaplen>`. Payload
   bytes are never buffered, stored or logged. The SSID (a payload field)
   is examined live in `EphemeralWifi` for priors and dropped; it never
   enters the Observation model.
3. **Privacy by design.** MACs are persisted only as HMAC-SHA256 hashes
   under a per-session salt (persistent salt is opt-in). Raw MACs exist
   only in live memory and on the local dashboard behind *two* switches
   (`privacy.allow_raw_mac_live` AND an in-UI toggle). The boundary is
   enforced in code (`assert_no_raw_mac`, recursive) and proven by tests:
   the Phase-6 acceptance test searches the database *file bytes* for raw
   MACs; the Phase-8 fuzz suite found and fixed a nested-structure gap.
4. **No new hardware.** One Pi 4B with its built-in radio is the whole
   sensor. Mesh nodes, LED, power bank are optional and degrade
   gracefully.
5. **Honesty about hardware.** Nothing is claimed to work on the Pi
   without pasted evidence in docs/verification-log.md.
6. **Scope.** SD-only, wired and cellular cameras are invisible to this
   system by design; traffic is never decrypted.
7. **Inconclusive, not innocent.** A missing stimulus response never
   counts as evidence *against* a device.

## What is stored, exactly

| artefact | contents | never contains |
|---|---|---|
| SQLite store | header fields + salted hashes + scores + reasons | raw MACs, payloads, SSIDs |
| MQTT messages | per-device hash, median RSSI, score, band | raw MACs, observations |
| ThingSpeak | alert count, top score, drop rate | any per-device data |
| pcap recordings (optional, tcpdump -s 128) | truncated headers | payload bytes |

## Ethics and legality

Use only on your own devices and premises, or with the owners' written
consent. Passive radio observation of unencrypted headers is the legal
basis the design assumes; applicable law (including, in India, the IT Act
2000 provisions on unauthorized access/interception) and university rules
apply - confirm the field-trial scope with your guide first. The system is
a **screening aid**: an alert is a reason to look closer, never a verdict
about a person or a device; and the absence of alerts is *not* evidence
that no cameras are present.

## Threat-model notes (what this design does not prevent)

- A salted hash prevents casual identifier harvesting but a determined
  adversary who can observe the same device and guesses the MAC can test
  membership (HMAC is deterministic per session). The per-session default
  salt means hashes cannot be correlated *across* sessions.
- Vendor names are coarse (20 bits of the original MAC). We store them
  for priors; if your threat model disallows even that, delete the
  IntelCache seeding and the priors component still works (score shifts
  only by its 15/100 weight).
