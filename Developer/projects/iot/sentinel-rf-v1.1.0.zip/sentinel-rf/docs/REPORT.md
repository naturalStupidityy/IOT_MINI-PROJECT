# SENTINEL-RF - Turning a Raspberry Pi into a passive RF sensor for hidden live-streaming cameras

*ETCS338 (Internet of Things) mini project - final report. All quantitative
results in this report were measured with `scripts/run_experiments.py`
(deterministic seeds; raw JSON in `docs/results/`). Everything ran on the
development laptop against the deterministic simulator: no claims about
real-hardware behaviour are made anywhere in this report.*

## Abstract

Hidden cameras that stream over Wi-Fi leave a radio fingerprint: an
uplink-dominant, QoS-marked, steadily-paced traffic profile whose bitrate
tracks the scene they see. SENTINEL-RF turns a stock Raspberry Pi 4B into
a passive sensor for that fingerprint - no packets transmitted, no
payload bytes ever stored, MAC addresses persisted only as per-session
salted hashes. The system fuses four evidence layers (vendor/SSID priors,
a traffic-profile classifier combining hand-written rules with a
RandomForest, a light on/off stimulus-response correlator, and BLE
watchlist corroboration) into one explainable 0-100 score with
plain-English reasons, and estimates device position from RSSI with a
0.25 m likelihood grid. On the simulator: leave-one-device-out CV
accuracy 0.969 / precision 1.000; end-to-end alert precision 1.000 with
recall 0.778 (the misses are deliberately-hard low-bitrate cameras
sitting in the 'watch' band); localization error 0.48 m mean with four
anchors; the stimulus correlator flags 6/6 cameras as responsive and 0/6
unrelated devices. The entire pipeline - capture, parsing, features,
detection, localization, storage, dashboard - runs identically on a
laptop via a deterministic RF simulator, which is how every number above
was obtained and how every claim can be re-verified.

## 1. Problem & scope

Rental rooms, hotel rooms and changing rooms increasingly contain small
Wi-Fi cameras that stream to a phone or cloud service. Commercial "sweep"
tools exist but are opaque; a course-grade answer should be cheap (one
Pi, no extra hardware), passive (transmitting nothing, joining nothing),
honest about uncertainty, and privacy-preserving for bystanders whose
devices are incidentally observed.

**In scope:** Wi-Fi/BLE devices whose *behaviour* resembles a streaming
camera. **Out of scope (invisible by design):** SD-card-only cameras,
wired cameras, cellular cameras, and any decryption of traffic. A
negative result is explicitly *not* proof of absence - the README,
dashboard and every report the tool generates repeat this.

## 2. Design constraints (the seven hard rules)

The rules that shaped every decision:

1. Passive only - no injection/deauth/cracking/joining (HARD RULE 1).
2. Headers only - snaplen bounded 64-256 B in code, not just docs (HR 2).
3. Privacy by design - salted HMAC hashes; raw MACs only in live memory
   behind two explicit switches (HR 3).
4. One Pi, built-in radio; everything optional degrades gracefully (HR 4).
5. Nothing is claimed to work on the Pi without pasted evidence
   (docs/verification-log.md) - all hardware paths are UNVERIFIED (HR 5).
6. Scope honesty (HR 6).
7. A missing stimulus response is inconclusive, never exculpatory (HR 7).

## 3. System architecture

Six layers around one frozen data model, `Observation` (24 header-only
fields; BLE advertisement fields whitelisted): capture (tcpdump
subprocess / bleak / replay / simulator behind one interface with
software fakes), parse (hand-rolled byte-level Radiotap/802.11/BLE-AD
parsers - no scapy, keeping the core at PyYAML+numpy), features
(three sliding windows; a 23-feature vocabulary), intel (offline OUI
database + SSID/BLE watchlists feeding priors), detection (fusion),
locate (grid + WLS + survey + hot-cold). Full details in
docs/ARCHITECTURE.md.

Two design choices worth defending:

- **Event-time detection ticks.** Detection fires on observation
  timestamps, not wall clock, with wall-clock fallback for quiet live
  rooms. A fast replay therefore scores identically to real time - the
  property that makes the whole evaluation pipeline trustworthy.
- **Fail-soft everywhere.** A bounded queue counts drops (budget < 2%);
  parse errors are counted, never raised (verified by ~15 k hostile
  buffers in the fuzz suite); store/transport failures decrement health
  counters; the hot-cold LED restores its trigger even on SIGINT.

## 4. Detection: four evidence layers, one explainable score

| layer | weight | evidence |
|---|---|---|
| priors | 15 | OUI vendor tiers, SSID watchlist, BLE names |
| traffic | 35 | rule fingerprint blended 50/50 with RandomForest probability |
| stimulus | 40 | lag-searched Pearson + permutation test vs the light on/off marks |
| BLE | 10 | watchlist corroboration when the device also advertises |

Weights renormalize over available components. The rule layer is written
to articulate *why* a bulk upload is not a camera (near-saturation rate
without QoS, MTU-filling frames - negative evidence), not merely to
reward high volume. Every point earned anywhere carries a plain-English
reason that ships with the alert ("MAC vendor is Espressif - weak prior
…", "Periodic traffic bursts consistent with video keyframes", "Frame
rate followed the on/off stimulus with r=+0.62 (p<=0.001, lag +1s)").

The ML half is deliberately conservative: trained on the simulator's
randomized environments, leave-one-device-out validated (no device in
both folds), persisted with a model card that records provenance,
hyperparameters and metrics and repeats that the data is synthetic.
LODO results: accuracy 0.969, precision 1.000, recall 0.846, ROC-AUC
1.000 over 261 windows / 31 devices.

**Stimulus protocol.** After a still-room baseline, the operator
alternates a strong scene stimulus (lights, or motion in front of each
suspect) while marking on/off in the dashboard. A streaming encoder's
bitrate follows what it sees; the correlator searches lags ±5 s and
corrects the permutation test for that 11-way search (shuffled-stimulus
null with the same max-over-lags statistic - plain circular shifts fail
because a periodic response realigns with shifted periodic stimuli).
Measured: 6/6 cameras responsive (mean |r| = 0.62, p <= 0.001);
6/6 BLE watches and 5/6 video-call phones inconclusive; the single
"weak" verdict on a video call is the honest cost of a correlator that
feeds evidence rather than verdicts.

## 5. Localization

RSSI(d) = P0 - 10·n·log10(d) with per-room calibration
(`sentinel calibrate`, linear fit with plausibility checks). The primary
estimator is a 0.25 m likelihood grid with Gaussian dB residuals - it
cannot diverge, handles outliers gracefully, and yields the dashboard's
heatmap; robust WLS (cauchy loss, 1/d weighting) is the cross-check.
Single-node deployments degrade to an honest distance ring (sigma >= d/2).
With four corner anchors at σ = 3 dB: mean error 0.48 m, median 0.45 m,
p90 0.84 m (n = 60 targets); grid and WLS agree to 0.32 m on average.
Multi-node meshes merge per-node medians over MQTT; a single node plus
walking (waypoint survey, or the ACT-LED hot-cold ladder) achieves the
same end.

## 6. Privacy engineering

The interesting claim is not "we hash MACs" but that the boundary is
*structural*: `Observation.to_dict()` cannot emit a raw address,
`from_dict()` refuses one, and every store/publish/telemetry call
re-checks payloads recursively with `assert_no_raw_mac`. The acceptance
tests search the SQLite **file bytes** for raw MACs (clean), and the
fuzz suite - which found a real bug (a MAC nested inside a list passed
the original top-level check) - keeps the boundary honest. Cloud
telemetry (ThingSpeak) is restricted to aggregates (counts, bands, drop
rate) precisely so a public channel cannot become a deanonymization
oracle.

## 7. Evaluation summary

| experiment | result |
|---|---|
| ML LODO CV (8 envs, 31 devices) | acc 0.969 / prec 1.000 / rec 0.846 / AUC 1.000 |
| End-to-end alerts (5 envs, threshold 60) | prec 1.000, rec 0.778, 0 false positives |
| Per-kind mean scores | camera 65.6, lowres camera 59.8, bulk upload 12.7, AP 0.8 |
| Stimulus (6 seeds) | cameras 6/6 responsive; unrelated 11/12 inconclusive |
| Localization (4 anchors, σ 3 dB) | 0.48 m mean / 0.84 m p90 |
| Soak (60 s @ 8x, full pipeline) | 0% drops, RSS < 300 MB, all frames accounted |
| Coverage floors | parse 94.1 / features 97.4 / detect 92.6 / locate 93.6 % |
| Test suite | 397 tests green (fast + slow), ruff + black clean |

The recall story is deliberate: the two missed cameras are low-bitrate
devices scoring 58-59 - inside the 'watch' band, one stimulus test away
from confirmation. Trading recall for precision at the alerting
threshold is the right trade for a screening tool whose next step is a
human looking at evidence.

## 8. Limitations (the honest list)

1. **Everything measured is simulated.** The simulator encodes plausible
   behaviour models, not measured firmware. Field re-validation is the
   first item of future work; the model card and REPORT both say so.
2. **Hardware path UNVERIFIED.** No Pi session has happened yet
   (docs/verification-log.md is empty by design). The Nexmon kernel
   constraint (bcm43455c0, kernels ≲5.15) may force the managed-mode or
   kali-fallback branches.
3. **Watchlists are heuristics.** SSID/BLE patterns are transcribed from
   public default-name documentation, unverified against live captures;
   the OUI database is a curated subset with an offline IEEE importer.
4. **Stimulus needs an operator and a cooperative room.** Lights must
   actually change the scene a camera sees; IR-only cameras respond
   differently.
5. **Wi-Fi-only cameras that pause between motion events** can fall
   below the 50-frame evidence threshold and are reported as
   insufficient, not clear.
6. **Video calls remain the hardest confound** for the traffic layer
   (one weak correlation in six) - the system's answer is the stimulus
   layer, not a bigger classifier.

## 9. What would come next

1. First Pi bring-up session: doctor output, monitor-mode evidence,
   calibration, one real room (all logged in verification-log.md).
2. Re-train the traffic model on labelled real captures; publish the
   delta vs the simulator numbers.
3. Blind trial: plant N devices (K streaming) in a room; measure
   operator time-to-find with and without the tool.
4. Adaptive dwell: spend more time on channels where suspects live.

## 10. Reproducing every number

```bash
pip install -e ".[all,dev]"
scripts/test_full.sh                 # lint + format + full suite + coverage floors
python3 scripts/run_experiments.py   # rewrites docs/results/ (~2 min)
sentinel demo --stimulus             # watch the full story live (laptop)
sentinel serve --demo                # the dashboard in a browser
```

Artifacts: source (`sentinel_rf/`), tests (`tests/`, 397), decision log
(DECISIONS.md, 40 entries), experiment data (docs/results/), dashboard
screenshots (docs/images/), deployment kit (scripts/, systemd/).
