# Documentation index

| document | what it covers |
|---|---|
| [REPORT.md](REPORT.md) | the course report: methods, measured results, limitations |
| [EXPERIMENTS.md](EXPERIMENTS.md) | experiment protocols + every number, reproducible via `scripts/run_experiments.py` |
| [results/](results/) | raw JSON of the experiment battery + model card + ablation table |
| [ARCHITECTURE.md](ARCHITECTURE.md) | layers, data model, failure philosophy |
| [PRIVACY_SAFETY.md](PRIVACY_SAFETY.md) | the seven hard rules in engineering terms; storage inventory; ethics |
| [DEPLOYMENT.md](DEPLOYMENT.md) | Pi bring-up (UNVERIFIED), the kernel question, systemd, mesh, soak |
| [CALIBRATION.md](CALIBRATION.md) | path-loss calibration, waypoint survey, hot-cold hunting |
| [kali-fallback.md](kali-fallback.md) | the Kali ARM branch: rationale, procedure, escalation ladder |
| [verification-log.md](verification-log.md) | HARD RULE 5 evidence log - empty until the first Pi session |
| [images/](images/) | dashboard screenshots (main, evidence panel, stimulus) |

Configuration is documented inline in
[../configs/default.yaml](../configs/default.yaml) (every key, every
default) and the watchlist in [../configs/watchlist.yaml](../configs/watchlist.yaml).
API surface: run the dashboard (`sentinel serve --demo`) and open
`/docs` (FastAPI's auto-generated reference), or read
`sentinel_rf/ui/api.py` - every endpoint is documented in its docstring.
