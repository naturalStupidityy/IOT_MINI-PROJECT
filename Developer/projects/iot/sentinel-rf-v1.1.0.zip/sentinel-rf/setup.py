"""Compatibility shim: make ``pip install -e .`` work with ANY pip version.

Why this file exists
--------------------

pip < 21.3 (notably the 21.2.4 bundled with macOS Monterey's system
Python 3.9) cannot do a PEP 660 editable install from a pyproject.toml
alone and aborts with::

    ERROR: File "setup.py" or "setup.cfg" not found. Directory cannot be
    installed in editable mode: ...

With this shim on disk, old pip falls back to the legacy
``setup.py develop`` code path instead of failing.

All metadata still lives in pyproject.toml; nothing is duplicated here.
The shim only makes sure the setuptools that executes it is able to read
the ``[project]`` table:

* setuptools >= 61 can read ``[project]``;
* setuptools >= 80 removed ``setup.py develop``, so the legacy path needs
  61 <= version < 80. Inside that window the shim does nothing.

When the venv's setuptools is too old (< 61, e.g. the 56.x shipped by
Python 3.9 venvs) the shim upgrades it in place once, so the user's
original one-liner just works. When it is too new (>= 80) the only cure is
a newer pip, and the shim says so.

In a PEP 517/660 build (modern pip, build isolation) setuptools is already
imported by the build backend before this file runs; in that case the shim
is completely inert.
"""

from __future__ import annotations

import subprocess
import sys

_MIN = (61, 0)
_MAX = (80, 0)
_UPGRADE_SPEC = "setuptools>=61,<80"

_LEGACY_HINT = (
    "    python3 -m pip install --upgrade pip setuptools wheel\n" '    pip install -e ".[all,dev]"'
)


def _installed_version() -> tuple:
    """Installed setuptools version, without importing it (keeps the
    in-place upgrade effective for the import below)."""
    try:
        from importlib.metadata import version

        raw = version("setuptools")
        return tuple(int(p) for p in raw.split(".")[:2] if p.isdigit())
    except Exception:  # not installed, or metadata unreadable
        return (0, 0)


def _upgrade_setuptools() -> None:
    print(
        "setup.py: this venv's setuptools cannot read pyproject.toml [project]; "
        f"upgrading it in place ({_UPGRADE_SPEC})..."
    )
    try:
        subprocess.check_call([sys.executable, "-m", "pip", "install", _UPGRADE_SPEC])
    except Exception:
        raise SystemExit(
            "Automatic upgrade failed (offline?). Run manually and retry:\n" + _LEGACY_HINT
        ) from None


def _ensure_legacy_compatible() -> None:
    v = _installed_version()
    if v >= _MAX:
        raise SystemExit(
            "This pip uses the legacy editable path, but setuptools >= 80 no longer "
            "supports 'setup.py develop'. Upgrade pip and retry:\n" + _LEGACY_HINT
        )
    if v < _MIN:
        _upgrade_setuptools()


# PEP 517/660 builds already have setuptools imported by the backend: inert.
if "setuptools" not in sys.modules:  # legacy `python setup.py ...` invocation
    _ensure_legacy_compatible()

import setuptools  # noqa: E402  (import must follow the possible upgrade)

setuptools.setup()
