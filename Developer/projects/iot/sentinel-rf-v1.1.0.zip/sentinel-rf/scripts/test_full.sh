#!/usr/bin/env bash
# =============================================================================
# SENTINEL-RF full CI gate (Phase 8).
#   1. ruff + black
#   2. full pytest run (fast + slow: model training, soak, fuzz)  [no coverage]
#   3. unit-scoped pytest run with coverage for the four correctness-critical
#      packages, enforcing the >=80% floors (scripts/check_coverage.py)
# Total wall time on a 2-core laptop: ~8-10 minutes. scripts/test.sh is the
# fast gate (~2-3 minutes).
# =============================================================================
set -euo pipefail
cd "$(dirname "$0")/.."

echo "== ruff (lint) =="
python3 -m ruff check .

echo "== black (format check) =="
python3 -m black --check .

echo "== pytest (full suite incl. slow model/soak tests) =="
python3 -m pytest -q -m ""

echo "== coverage floors (parse/features/detect/locate >= 80%) =="
python3 -m pytest -q -m "not slow" \
    tests/test_radiotap.py tests/test_dot11.py tests/test_ble_adv.py \
    tests/test_pcap.py tests/test_sim.py tests/test_features.py \
    tests/test_intel.py tests/test_detect.py tests/test_locate.py \
    tests/test_transport.py tests/test_capture.py tests/test_system.py \
    --cov=sentinel_rf.parse --cov=sentinel_rf.features \
    --cov=sentinel_rf.detect --cov=sentinel_rf.locate \
    --cov-report=term --cov-report=json:coverage.json >/dev/null
python3 scripts/check_coverage.py coverage.json

echo "ALL CHECKS PASSED"
