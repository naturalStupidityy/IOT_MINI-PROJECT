#!/usr/bin/env python3
"""Enforce per-package coverage floors from a coverage.py JSON report.

Quality bar: parse / features / detect / locate must stay >= 80% covered
(the correctness-critical packages). Other packages are reported but not
gated yet. Exit code 1 when any floor is missed.
"""

from __future__ import annotations

import json
import sys
from pathlib import Path

FLOORS = {
    "sentinel_rf/parse": 80,
    "sentinel_rf/features": 80,
    "sentinel_rf/detect": 80,
    "sentinel_rf/locate": 80,
}


def main(argv: list[str]) -> int:
    path = Path(argv[1] if len(argv) > 1 else "coverage.json")
    if not path.is_file():
        print(f"coverage report not found: {path}")
        return 2
    report = json.loads(path.read_text(encoding="utf-8"))
    files = report.get("files", {})
    per_package: dict[str, list[float]] = {}
    for name, data in files.items():
        parts = Path(name).parts
        if len(parts) >= 2 and parts[0] == "sentinel_rf":
            key = "sentinel_rf" if len(parts) == 2 else f"sentinel_rf/{parts[1]}"
            per_package.setdefault(key, []).append(float(data["summary"]["percent_covered"]))

    print(f"{'package':<28} {'coverage':>8}  floor")
    failures = []
    overall = []
    for key in sorted(per_package):
        values = per_package[key]
        coverage = sum(v * w for v, w in zip(values, [1] * len(values))) / len(values)
        overall.append(coverage)
        floor = FLOORS.get(key)
        marker = ""
        if floor is not None and coverage < floor:
            failures.append((key, coverage, floor))
            marker = f"  FAIL (floor {floor}%)"
        print(f"{key:<28} {coverage:>7.1f}%{marker}")

    if overall:
        print(f"{'sentinel_rf (per-file avg)':<28} {sum(overall) / len(overall):>7.1f}%")
    if failures:
        print("\nCOVERAGE FLOORS MISSED:")
        for key, coverage, floor in failures:
            print(f"  {key}: {coverage:.1f}% < {floor}%")
        return 1
    print("\nall coverage floors met")
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv))
