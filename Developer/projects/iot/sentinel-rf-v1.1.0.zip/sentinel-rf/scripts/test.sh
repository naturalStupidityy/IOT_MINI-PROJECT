#!/usr/bin/env bash
# SENTINEL-RF CI-style gate (Phase 0+): lint, format check, unit tests.
# Assumes an active virtualenv with the dev extras installed:
#   python3 -m venv .venv && source .venv/bin/activate
#   pip install -e ".[dev]"
set -euo pipefail
cd "$(dirname "$0")/.."

echo "== ruff (lint) =="
python3 -m ruff check .

echo "== black (format check) =="
python3 -m black --check .

echo "== pytest (unit tests, no network) =="
python3 -m pytest

echo "ALL CHECKS PASSED"
