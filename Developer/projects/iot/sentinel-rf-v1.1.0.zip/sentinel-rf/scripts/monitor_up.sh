#!/usr/bin/env bash
# =============================================================================
# Bring up the monitor interface for live capture (Phase 8) - UNVERIFIED.
#
# On a Pi 4B this only works with Nexmon-patched firmware for bcm43455c0
# (kernels <= 5.15; see TODO.md and docs/DEPLOYMENT.md). Stock Raspberry Pi
# OS kernels refuse monitor mode on the built-in Wi-Fi - that failure is
# EXPECTED and reported, never worked around here.
#
# NOTE: while mon0 is up, the Pi's Wi-Fi cannot associate to any network -
# use Ethernet for the dashboard/mesh (config already assumes this).
# =============================================================================
set -euo pipefail

BASE_IFACE="${1:-wlan0}"
MON_IFACE="${2:-mon0}"

echo "== creating ${MON_IFACE} (monitor mode) on ${BASE_IFACE} (UNVERIFIED) =="

if ! command -v iw >/dev/null; then
    echo "ERROR: iw not installed (sudo apt install iw)" >&2
    exit 1
fi

if iw dev | grep -q "Interface ${MON_IFACE}"; then
    echo "${MON_IFACE} already exists; leaving it alone"
else
    iw dev "${BASE_IFACE}" interface add "${MON_IFACE}" type monitor || {
        echo "ERROR: the driver refused monitor mode." >&2
        echo "On the Pi 4B this means the Nexmon firmware is not active" >&2
        echo "(stock kernels do not support monitor mode on bcm43455c0)." >&2
        echo "See docs/DEPLOYMENT.md and the kali-fallback branch." >&2
        exit 2
    }
fi

ip link set "${MON_IFACE}" up
echo "== ${MON_IFACE} is up =="
iw dev "${MON_IFACE}" info
echo
echo "Record the output above in docs/verification-log.md (HARD RULE 5)."
