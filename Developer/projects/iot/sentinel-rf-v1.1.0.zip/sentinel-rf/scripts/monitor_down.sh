#!/usr/bin/env bash
# Remove the monitor interface and restore managed Wi-Fi (Phase 8) - UNVERIFIED.
set -euo pipefail
MON_IFACE="${1:-mon0}"
ip link set "${MON_IFACE}" down 2>/dev/null || true
iw dev "${MON_IFACE}" del 2>/dev/null || true
echo "${MON_IFACE} removed (Wi-Fi back to managed mode)"
