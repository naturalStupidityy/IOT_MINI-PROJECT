#!/usr/bin/env bash
# =============================================================================
# SENTINEL-RF macOS bootstrap (developer / demo machines)
#
# macOS is a first-class DEMO and development platform (DECISIONS.md D042):
# the full pipeline, simulator, PCAP replay, ML training, localization,
# report kit, test suite and dashboard all run natively. BLE scanning works
# for real via CoreBluetooth (bleak, macOS 12+). Monitor-mode Wi-Fi capture
# does NOT exist on macOS (no public API) - capture on the Kali/Pi node and
# replay the PCAP here, or run a BLE-only node (`sentinel monitor --no-wifi
# --ble --serve`).
#
# Written for the bash 3.2 that ships with macOS (no bash-4 constructs).
#
# Usage:  bash scripts/setup_macos.sh [--test]
#   --test  also run the full unit test suite after install
# =============================================================================
set -euo pipefail

SRC_DIR="$(cd "$(dirname "$0")/.." && pwd)"
VENV_DIR="${SENTINEL_VENV:-${SRC_DIR}/.venv}"
PY="${SENTINEL_PYTHON:-python3}"

echo "== SENTINEL-RF macOS bootstrap =="

# --- 1. Python sanity ---------------------------------------------------------
if ! command -v "${PY}" >/dev/null; then
    echo "ERROR: python3 not found." >&2
    echo "  Install Apple's Command Line Tools:  xcode-select --install" >&2
    echo "  or Homebrew Python:                  brew install python" >&2
    exit 1
fi

if ! "${PY}" -c 'import sys; sys.exit(0 if sys.version_info >= (3, 9) else 1)'; then
    echo "ERROR: SENTINEL-RF needs Python >= 3.9 (found $("${PY}" --version 2>&1))." >&2
    echo "  brew install python   (or upgrade Xcode CLT)" >&2
    exit 1
fi
echo "-- using $("${PY}" --version 2>&1) at $(command -v "${PY}")"

# --- 2. Virtualenv ------------------------------------------------------------
if [ ! -x "${VENV_DIR}/bin/pip" ]; then
    echo "-- creating virtualenv at ${VENV_DIR}"
    "${PY}" -m venv "${VENV_DIR}"
fi
PIP="${VENV_DIR}/bin/pip"
SENTINEL="${VENV_DIR}/bin/sentinel"

# --- 3. THE macOS FIX: upgrade pip/setuptools BEFORE the editable install -----
# macOS system Python 3.9 venvs ship pip 21.2.4, which cannot install from a
# pyproject.toml-only project ("File 'setup.py' or 'setup.cfg' not found").
# Upgrading pip first avoids the whole class of problems. The repo also carries
# a setup.py compatibility shim, so even a forgotten upgrade self-heals.
echo "-- upgrading pip / setuptools / wheel (required once per venv on macOS)"
"${PIP}" install --upgrade pip "setuptools>=61,<80" wheel

# --- 4. Install ----------------------------------------------------------------
echo "-- installing sentinel-rf (editable, all extras + dev tools)"
"${PIP}" install -e "${SRC_DIR}[all,dev]"

# --- 5. Verify ------------------------------------------------------------------
echo
echo "-- environment check (sentinel doctor)"
"${SENTINEL}" doctor || true

# --- 6. Optional: full test suite ------------------------------------------------
if [ "${1:-}" = "--test" ]; then
    echo
    echo "-- running the unit test suite (2-3 min)"
    "${VENV_DIR}/bin/python" -m pytest -q
fi

# --- 7. What works here (the honest macOS reality) -------------------------------
cat <<EOF

Bootstrap done. On this Mac you can run, right now:

  ${SENTINEL} demo                          full pipeline on the simulator
  ${SENTINEL} demo --stimulus --seconds 150  ...including the light on/off protocol
  ${SENTINEL} serve --demo                   dashboard: http://127.0.0.1:8000
  ${SENTINEL} replay <capture.pcap>          parse a PCAP captured elsewhere
  ${SENTINEL} train                          train the ML model (LODO CV)
  ${SENTINEL} monitor --no-wifi --ble --serve  REAL BLE scanning via CoreBluetooth
                                             (grant your terminal Bluetooth access in
                                             System Settings > Privacy & Security)

Not possible on macOS (by OS design, not a bug):
  monitor-mode Wi-Fi capture, channel hopping, the ACT LED, /proc resource
  sampling. Capture on the Kali node (kali-fallback branch) and copy the PCAP
  here, or let this Mac contribute BLE evidence to the mesh over MQTT.

Team workflow:  scripts/test.sh  = ruff + black + pytest quality gate.
EOF
