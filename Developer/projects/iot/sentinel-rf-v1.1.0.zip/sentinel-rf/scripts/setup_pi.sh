#!/usr/bin/env bash
# =============================================================================
# SENTINEL-RF Raspberry Pi bootstrap (Phase 8) - UNVERIFIED ON HARDWARE
#
# Everything below is written for Raspberry Pi OS on a Pi 4B. Until a real
# bring-up session is recorded in docs/verification-log.md, treat this script
# as UNVERIFIED (HARD RULE 5). It makes NO attempt to patch kernels or
# firmware: the Nexmon monitor-mode question is a manual decision (TODO.md).
#
# Usage:  sudo bash scripts/setup_pi.sh [--install-dir /opt/sentinel]
# =============================================================================
set -euo pipefail

INSTALL_DIR="${2:-/opt/sentinel}"
SRC_DIR="$(cd "$(dirname "$0")/.." && pwd)"

echo "== SENTINEL-RF Pi bootstrap (UNVERIFIED until logged) =="

# --- 1. System packages ------------------------------------------------------
echo "-- installing system packages"
apt-get update -qq
apt-get install -y --no-install-recommends \
    python3 python3-venv python3-pip \
    tcpdump iw iproute2 \
    chrony \
    mosquitto mosquitto-clients || true   # chrony + mosquitto optional

# --- 2. Python environment ---------------------------------------------------
echo "-- creating virtualenv at ${INSTALL_DIR}/venv"
mkdir -p "${INSTALL_DIR}"
python3 -m venv "${INSTALL_DIR}/venv"
"${INSTALL_DIR}/venv/bin/pip" install --upgrade pip wheel
"${INSTALL_DIR}/venv/bin/pip" install -e "${SRC_DIR}[all]"

# --- 3. Data directories ------------------------------------------------------
mkdir -p /var/lib/sentinel
chmod 750 /var/lib/sentinel

# --- 4. Environment file for the services ------------------------------------
if [ ! -f /etc/sentinel/sentinel.env ]; then
  mkdir -p /etc/sentinel
  cat > /etc/sentinel/sentinel.env <<'EOF'
# SENTINEL-RF service environment (chmod 600; secrets live here, never in git)
# SENTINEL_MQTT_USER=
# SENTINEL_MQTT_PASS=
# SENTINEL_THINGSPEAK_KEY=
SENTINEL_RF_CONFIG=/etc/sentinel/default.yaml
EOF
  chmod 600 /etc/sentinel/sentinel.env
fi

# --- 5. Config ---------------------------------------------------------------
if [ ! -f /etc/sentinel/default.yaml ]; then
  cp "${SRC_DIR}/configs/default.yaml" /etc/sentinel/default.yaml
  echo "-- installed /etc/sentinel/default.yaml (edit capture.iface, room, mqtt there)"
fi

# --- 6. systemd units ---------------------------------------------------------
echo "-- installing systemd units"
cp "${SRC_DIR}/systemd/sentinel-monitor.service" /etc/systemd/system/ 2>/dev/null || \
    echo "   (unit file missing - Phase 8 ships it; skipping)" || true
systemctl daemon-reload || true

cat <<'EOF'

Bootstrap done (software side). NEXT STEPS (manual, in this order):

 1. Kernel check (decides the capture path):
      uname -r          # record this in docs/verification-log.md
    - <= 5.15 with Nexmon firmware for bcm43455c0 -> monitor mode possible
      (see docs/DEPLOYMENT.md; flash a legacy image if needed)
    - anything newer, no Nexmon: use managed-mode scanning or the
      kali-fallback branch (D003)
 2. Bring the monitor interface up:  sudo bash scripts/monitor_up.sh
 3. Verify:                         sentinel doctor
 4. Calibrate the room:             sentinel calibrate --measurements '...'
 5. Start the service:              systemctl start --no-block sentinel-monitor
 6. Dashboard:                      http://<pi-ip>:8000/

Remember: every hardware claim needs pasted output in docs/verification-log.md.
EOF
