#!/usr/bin/env python3
"""Run the Phase 9 experiment battery and write docs/results/*.

Every experiment is deterministic (fixed seeds) and reproducible with this
script. Outputs JSON + a Markdown summary; docs/REPORT.md cites these
numbers. Runtime on a 2-core laptop: ~5-8 minutes.

  E1  ML traffic classifier: leave-one-device-out CV over 8 environments
  E2  Fusion ablation (which evidence layer earns its weight)
  E3  Localization accuracy: grid vs WLS over 12 targets, 4 anchors
  E4  Stimulus correlator: cameras vs non-cameras over 6 seeds
  E5  End-to-end detection: per-kind score bands with the trained model
"""

from __future__ import annotations

import json
import math
import random
import statistics
import sys
import time
from pathlib import Path

RESULTS = Path("docs/results")
SALT = b"sentinel-experiments-v1"


def _write(name: str, payload: dict) -> None:
    RESULTS.mkdir(parents=True, exist_ok=True)
    (RESULTS / name).write_text(json.dumps(payload, indent=2, default=str), encoding="utf-8")
    print(f"  wrote {RESULTS / name}")


def e1_ml_lodo() -> dict:
    print("E1: ML leave-one-device-out CV (8 environments) ...")
    from sentinel_rf.detect.dataset import build_training_data, dataset_summary
    from sentinel_rf.detect.model import TrafficModel, lodo_cross_validate

    X, y, groups, meta = build_training_data(
        n_envs=8, base_seed=1000, duration_s=120.0, window_step_s=20.0, salt=SALT
    )
    summary = dataset_summary(meta, y)
    metrics = lodo_cross_validate(X, y, groups)
    model = TrafficModel.train(X, y, seed=42, dataset_info=summary)
    model.card.metrics = {"lodo_cv": metrics}
    model.save("models/traffic_rf.joblib", "models/model_card.yaml")
    RESULTS.mkdir(parents=True, exist_ok=True)
    (RESULTS / "model_card.yaml").write_text(
        Path("models/model_card.yaml").read_text(encoding="utf-8"), encoding="utf-8"
    )
    payload = {"dataset": summary, "lodo_cv": metrics}
    _write("ml_lodo.json", payload)
    return payload


def e2_ablation() -> dict:
    print("E2: fusion ablation ...")
    from sentinel_rf.config import load_config
    from sentinel_rf.detect.ablation import format_ablation_table, run_ablation
    from sentinel_rf.detect.engine import Detector
    from sentinel_rf.detect.model import TrafficModel
    from sentinel_rf.detect.rules import PriorsEngine
    from sentinel_rf.features import compute_features
    from sentinel_rf.features.windows import DeviceTracker
    from sentinel_rf.intel.ble_rules import BleRuleBook
    from sentinel_rf.intel.cache import IntelCache
    from sentinel_rf.intel.ssid_rules import SsidRuleBook
    from sentinel_rf.intel.watchlist import load_watchlist
    from sentinel_rf.sim.generator import RfSimulator

    config = load_config()
    watchlist = load_watchlist()
    model = TrafficModel.load("models/traffic_rf.joblib")
    detector = Detector(
        config,
        priors=PriorsEngine(SsidRuleBook(watchlist), BleRuleBook(watchlist)),
        model=model,
        ble_rules=BleRuleBook(watchlist),
        min_frames=50,
    )

    rows = []
    for env_seed in (2101, 2102, 2103):
        rng = random.Random(f"cast:{env_seed}")
        from sentinel_rf.sim.generator import varied_cast

        sim = RfSimulator(
            seed=env_seed, duration_s=110.0, salt=SALT, devices=varied_cast(rng, (5.0, 4.0))
        )
        tracker = DeviceTracker()
        intel = IntelCache()
        sim.seed_intel(intel)
        for obs in sim.observations():
            tracker.update(obs)
        labels = sim.labels()
        for addr_hash, window in tracker.snapshot(sim.t0 + 110.0).items():
            info = labels.get(addr_hash)
            if info and compute_features(window)["n_frames"] >= 50:
                rows.append(
                    {
                        "window": window,
                        "label": 1 if info["is_camera"] else 0,
                        "addr_hash": addr_hash,
                    }
                )
    table = run_ablation(config=config, detector=detector, windows=rows, intel=IntelCache())
    _write("ablation.json", {"n_windows": len(rows), "table": table})
    (RESULTS / "ablation.md").write_text(
        f"## Fusion ablation ({len(rows)} labelled device windows)\n\n```\n"
        + format_ablation_table(table)
        + "\n```\n",
        encoding="utf-8",
    )
    print(f"  wrote {RESULTS / 'ablation.md'}")
    return {"n": len(rows), "table": table}


def e3_localization() -> dict:
    print("E3: localization accuracy (grid vs WLS) ...")
    import numpy as np

    from sentinel_rf.locate.anchors import Anchor, AnchorSet, RoomProfile
    from sentinel_rf.locate.grid import GridLocator
    from sentinel_rf.locate.lsq import wls_estimate
    from sentinel_rf.locate.pathloss import PathLossModel

    profile = RoomProfile(
        width_m=5.0,
        height_m=4.0,
        pathloss=PathLossModel(p0_dbm=-40.0, n=2.5, sigma_db=3.0),
        anchors=AnchorSet.from_list(
            [
                Anchor("n1", 0.3, 0.3),
                Anchor("n2", 4.7, 0.3),
                Anchor("n3", 0.3, 3.7),
                Anchor("n4", 4.7, 3.7),
            ]
        ),
    )
    locator = GridLocator(profile, grid_resolution_m=0.25)
    rng = np.random.default_rng(314)
    grid_errors, wls_errors, gaps = [], [], []
    for _ in range(60):
        truth = (rng.uniform(0.4, 4.6), rng.uniform(0.4, 3.6))
        measurements = {
            a.node_id: profile.pathloss.p0_dbm
            - 10 * profile.pathloss.n * math.log10(a.distance_to(*truth))
            + rng.normal(0, 3.0)
            for a in profile.anchors
        }
        g = locator.estimate(measurements)
        w = wls_estimate(measurements, profile)
        grid_errors.append(math.hypot(g.x - truth[0], g.y - truth[1]))
        wls_errors.append(math.hypot(w.x - truth[0], w.y - truth[1]))
        gaps.append(math.hypot(g.x - w.x, g.y - w.y))
    grid_errors_s = sorted(grid_errors)
    payload = {
        "n_targets": len(grid_errors),
        "sigma_db": 3.0,
        "grid": {
            "mean_m": round(statistics.mean(grid_errors), 3),
            "median_m": round(statistics.median(grid_errors), 3),
            "p90_m": round(grid_errors_s[int(0.9 * len(grid_errors_s))], 3),
            "max_m": round(max(grid_errors), 3),
        },
        "wls": {
            "mean_m": round(statistics.mean(wls_errors), 3),
            "median_m": round(statistics.median(wls_errors), 3),
        },
        "estimator_gap_mean_m": round(statistics.mean(gaps), 3),
        "single_anchor_distance_error_mean_m": round(
            statistics.mean(
                abs(profile.pathloss.distance_from(-40.0 - 25.0 * math.log10(d)) - d)
                for d in (0.5, 1.0, 2.0, 4.0, 7.0)
            ),
            3,
        ),
    }
    _write("localization.json", payload)
    return payload


def e4_stimulus() -> dict:
    print("E4: stimulus correlator (6 seeds) ...")
    from sentinel_rf.config import load_config
    from sentinel_rf.detect.stimulus import StimulusSession, StimulusTracker
    from sentinel_rf.sim.generator import RfSimulator, square_wave

    config = load_config()
    camera_r, watch_verdicts, phone_verdicts = [], [], []
    for seed in (4001, 4002, 4003, 4004, 4005, 4006):
        sim = RfSimulator(
            seed=seed,
            duration_s=150.0,
            salt=SALT,
            stimulus_signal=lambda t: square_wave(t - 60.0, period=20.0),
        )
        labels = sim.labels()
        session = StimulusSession(config.detect.stimulus)
        tracker = StimulusTracker(session)
        session.start(sim.t0)
        for t_on in range(60, 141, 10):
            session.mark((t_on % 20) < 10, sim.t0 + t_on)
        # feed observations while the session is live, then close it
        for obs in sim.observations():
            tracker.update(obs)
        session.end()
        for kind, sink in (
            ("camera", camera_r),
            ("ble_watch", watch_verdicts),
            ("phone_video_call", phone_verdicts),
        ):
            addr_hash = next((h for h, v in labels.items() if v["kind"] == kind), None)
            if addr_hash is None:
                continue
            result = tracker.analyze(addr_hash)
            if kind == "camera":
                sink.append({"r": result.r, "p": result.p, "verdict": result.verdict})
            else:
                sink.append(result.verdict)
    payload = {
        "n_seeds": 6,
        "camera": {
            "responsive_rate": round(
                sum(1 for r in camera_r if r["verdict"] == "responsive") / len(camera_r), 3
            ),
            "mean_r": round(statistics.mean(abs(r["r"]) for r in camera_r), 3),
            "max_p": max(r["p"] for r in camera_r),
        },
        "ble_watch_inconclusive_rate": round(
            sum(1 for v in watch_verdicts if v in ("inconclusive", "insufficient"))
            / len(watch_verdicts),
            3,
        ),
        "video_call_inconclusive_rate": round(
            sum(1 for v in phone_verdicts if v in ("inconclusive", "insufficient"))
            / len(phone_verdicts),
            3,
        ),
    }
    _write("stimulus.json", payload)
    return payload


def e5_detection() -> dict:
    print("E5: end-to-end detection with the trained model (5 environments) ...")
    from sentinel_rf.config import load_config
    from sentinel_rf.detect.engine import Detector
    from sentinel_rf.detect.model import TrafficModel
    from sentinel_rf.detect.rules import PriorsEngine
    from sentinel_rf.features.windows import DeviceTracker
    from sentinel_rf.intel.ble_rules import BleRuleBook
    from sentinel_rf.intel.cache import IntelCache
    from sentinel_rf.intel.ssid_rules import SsidRuleBook
    from sentinel_rf.intel.watchlist import load_watchlist
    from sentinel_rf.sim.generator import RfSimulator, varied_cast

    config = load_config()
    watchlist = load_watchlist()
    model = TrafficModel.load("models/traffic_rf.joblib")
    detector = Detector(
        config,
        priors=PriorsEngine(SsidRuleBook(watchlist), BleRuleBook(watchlist)),
        model=model,
        ble_rules=BleRuleBook(watchlist),
        min_frames=50,
    )
    by_kind: dict = {}
    tp = fp = fn = tn = 0
    for env_seed in (5001, 5002, 5003, 5004, 5005):
        rng = random.Random(f"cast:{env_seed}")
        sim = RfSimulator(
            seed=env_seed, duration_s=120.0, salt=SALT, devices=varied_cast(rng, (5.0, 4.0))
        )
        tracker = DeviceTracker()
        intel = IntelCache()
        sim.seed_intel(intel)
        for obs in sim.observations():
            tracker.update(obs)
        labels = sim.labels()
        for addr_hash, window in tracker.snapshot(sim.t0 + 120.0).items():
            info = labels.get(addr_hash)
            if info is None or info["kind"].startswith("ble_"):
                continue
            score = detector.evaluate(addr_hash, tracker, intel, sim.t0 + 120.0, window=window)
            entry = by_kind.setdefault(info["kind"], {"scores": [], "likely": 0, "n": 0})
            entry["scores"].append(score.score)
            entry["n"] += 1
            entry["likely"] += score.band == "likely"
            alerted = score.band == "likely"
            if info["is_camera"] and alerted:
                tp += 1
            elif info["is_camera"]:
                fn += 1
            elif alerted:
                fp += 1
            else:
                tn += 1
    kinds = {
        kind: {
            "n": v["n"],
            "mean_score": round(statistics.mean(v["scores"]), 1),
            "min_score": round(min(v["scores"]), 1),
            "max_score": round(max(v["scores"]), 1),
            "likely_rate": round(v["likely"] / v["n"], 3),
        }
        for kind, v in sorted(by_kind.items())
    }
    payload = {
        "n_environments": 5,
        "confusion": {"tp": tp, "fp": fp, "fn": fn, "tn": tn},
        "precision": round(tp / (tp + fp), 3) if tp + fp else None,
        "recall": round(tp / (tp + fn), 3) if tp + fn else None,
        "by_kind": kinds,
        "note": "threshold: fusion score >= 60 with the ML model loaded; no stimulus layer",
    }
    _write("detection.json", payload)
    return payload


def main() -> int:
    started = time.time()
    print(f"SENTINEL-RF experiment battery - results into {RESULTS}/\n")
    results = {}
    for name, fn in (
        ("ml_lodo", e1_ml_lodo),
        ("ablation", e2_ablation),
        ("localization", e3_localization),
        ("stimulus", e4_stimulus),
        ("detection", e5_detection),
    ):
        t0 = time.time()
        results[name] = fn()
        print(f"  -> {time.time() - t0:.1f}s\n")
    summary = {
        "generated": time.strftime("%Y-%m-%d %H:%M:%S"),
        "runtime_s": round(time.time() - started, 1),
        "salt": SALT.hex()[:8] + "...",
        **results,
    }
    _write("summary.json", summary)
    print(f"done in {time.time() - started:.0f}s")
    return 0


if __name__ == "__main__":
    sys.exit(main())
