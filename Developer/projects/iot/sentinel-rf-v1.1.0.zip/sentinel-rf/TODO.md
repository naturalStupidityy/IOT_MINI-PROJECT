# TODO.md - open items

## Blocked / waiting on the user or the Pi

- [ ] **Confirm the Pi's OS image and kernel** (`cat /etc/os-release`, `uname -a`).
      Checked 2026-10-31 against the Nexmon README
      (https://github.com/seemoo-lab/nexmon): for the bcm43455c0 (Pi 3B+/4B),
      monitor mode + Radiotap are listed only for firmware 7.45.154
      (Raspbian kernels 4.9/4.14/4.19) and 7.45.189 (kernels 4.14/4.19/5.4);
      the project supports kernels up to 5.15 overall and nothing for 6.x.
      Current Raspberry Pi OS images ship firmware 7.45.206 on kernels 6.x -
      **no monitor mode in the table for that combination**. So: if the Pi
      runs a current Bookworm image, expect to either flash a legacy
      (Bullseye-era, kernel <= 5.15) image, switch to the `kali-fallback`
      branch, or drop to the managed-mode fallback. Decide in Phase 2 week 1
      and record the evidence in docs/verification-log.md.
- [ ] Faculty confirmation of the MIT license and of field-trial scope (D004).
- [ ] Confirm a real streaming camera is obtainable; otherwise a phone
      IP-camera app is the stand-in (documented limitation).
- [ ] Confirm the demo venue allows light toggling for the stimulus test.

## Phase checklist

- [x] Phase 0 - scaffold (tag v0.1.0)
- [x] Phase 1 - Radiotap/802.11 parsers, PCAP replay, deterministic simulator (v0.2.0)
- [x] Phase 2 - live capture + `sentinel doctor` (v0.3.0; laptop-side done,
      first Pi session still pending - see Blocked section)
- [x] Phase 3 - features + intel (v0.4.0; watchlist patterns still need live-capture
      verification - noted in-file and in TODO Blocked section)
- [x] Phase 4 - detection (v0.5.0; ML trained on simulator data only - field
      re-validation pending, see Blocked)
- [x] Phase 5 - localization (v0.6.0; mesh collector lands with Phase 6 transport)
- [x] Phase 6 - SQLite store + MQTT + collector (v0.7.0)
- [x] Phase 7 - CLI subcommands + dashboard (v0.8.0; screenshot pending Phase 9)
- [x] Phase 8 - hardening (v0.9.0; systemd watchdog via Restart=always + on-Pi soak
      procedure documented in docs/DEPLOYMENT.md)
- [x] Phase 9 - docs + report kit (v1.0.0: REPORT.md, EXPERIMENTS.md +
      docs/results/, ARCHITECTURE/PRIVACY/DEPLOYMENT/CALIBRATION guides,
      dashboard screenshots)

## Small / opportunistic

- [ ] configs/anchors.yaml schema for survey/mesh anchor coordinates (Phase 5)
- [ ] Consider `python3.9` CI job to actually exercise D013's compatibility claim
- [ ] Decide salt-file naming convention when `privacy.salt_file` is first used
